USE Parcial2_BBDD

GO

INSERT INTO Libros VALUES(64, 'En El Espacio Leemos El Tiempo', 2, 32, 89);
INSERT INTO Libros VALUES(117, 'Teor�a Organizacional, Dise�o Y Cambio En Las Organizaciones', 1, 59, 97);
INSERT INTO Libros VALUES(120, 'Aprendiendo Del Pop', 2, 60, 76);
INSERT INTO Libros VALUES(123, 'El Resplandor', 11, 666, 99);
INSERT INTO Libros VALUES(209, 'Marketing Internacional', 1, 105, 88);
INSERT INTO Libros VALUES(269, 'Beef Production and Management Decisions', 10, 135, 97);
INSERT INTO Libros VALUES(283, 'Principios de Econom�a', 5, 142, 88);
INSERT INTO Libros VALUES(335, 'El Conocimiento Secreto ', 9, 168, 75);
INSERT INTO Libros VALUES(339, 'La Arqueolog�a Del Saber', 2, 170, 92);
INSERT INTO Libros VALUES(389, 'Geomorfolog�a', 4, 195, 97);
INSERT INTO Libros VALUES(619, 'T�cnicas De An�lisis De Datos En Investigaci�n De Mercados', 1, 310, 87);
INSERT INTO Libros VALUES(636, 'Eric Fischl: The Krefeld-Project', 3, 318, 82);
INSERT INTO Libros VALUES(640, 'Estrategias de Marketing Internacional ', 1, 320, 97);
INSERT INTO Libros VALUES(703, 'The Great Gatsby ', 8, 352, 86);
INSERT INTO Libros VALUES(709, 'Arquitectura y Cr�tica', 2, 355, 76);
INSERT INTO Libros VALUES(764, 'Teor�a Y Dise�o Organizacional', 1, 382, 74);
INSERT INTO Libros VALUES(777, 'Dr�cula', 7, 899, 88);
INSERT INTO Libros VALUES(787, 'Clasificaci�n De Intervenciones De Enfermer�a', 6, 394, 83);
INSERT INTO Libros VALUES(980, 'Introducci�n A La Teor�a General De La Administraci�n', 1, 490, 88);
