USE Parcial2_BBDD

GO

INSERT INTO Categorias VALUES(1, 'Administraci�n');
INSERT INTO Categorias VALUES(2, 'Arquitectura Y Urbanismo');
INSERT INTO Categorias VALUES(3, 'Artes Visuales');
INSERT INTO Categorias VALUES(4, 'Ciencias Ambientales Y Evolutivas');
INSERT INTO Categorias VALUES(5, 'Econom�a');
INSERT INTO Categorias VALUES(6, 'Enfermer�a');
INSERT INTO Categorias VALUES(7, 'Fantas�a G�tica');
INSERT INTO Categorias VALUES(8, 'Ling��stica y Literatura');
INSERT INTO Categorias VALUES(9, 'Motivacionales');
INSERT INTO Categorias VALUES(10, 'Producci�n Animal');
INSERT INTO Categorias VALUES(11, 'Terror');
