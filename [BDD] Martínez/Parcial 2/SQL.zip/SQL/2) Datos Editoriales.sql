USE Parcial2_BBDD

GO

INSERT INTO Editoriales VALUES(76, 'GGILI');
INSERT INTO Editoriales VALUES(97, 'Pearson Educaci�n');
INSERT INTO Editoriales VALUES(99, 'DeBolsillo');
INSERT INTO Editoriales VALUES(88, 'Anto');
INSERT INTO Editoriales VALUES(82, 'Kerber�');
INSERT INTO Editoriales VALUES(74, 'CENGAGE');
INSERT INTO Editoriales VALUES(87, 'Ediciones Pir�mide');
INSERT INTO Editoriales VALUES(75, 'Destino');
INSERT INTO Editoriales VALUES(83, 'Elsevier-Mosby');
INSERT INTO Editoriales VALUES(92, 'Siglo XXI');
INSERT INTO Editoriales VALUES(89, 'Siruel');
INSERT INTO Editoriales VALUES(86, 'MacMillan');
