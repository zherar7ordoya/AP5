USE Parcial2_BBDD

GO

INSERT INTO Autores VALUES(355, 'Joseph ', 'Montaner');
INSERT INTO Autores VALUES(135, 'Thomas ', 'Field');
INSERT INTO Autores VALUES(666, 'Stephen ', 'King');
INSERT INTO Autores VALUES(899, 'Bram ', 'Stoker');
INSERT INTO Autores VALUES(318, 'Robert ', 'Rosenblum');
INSERT INTO Autores VALUES(59, 'Gareth ', 'Jones');
INSERT INTO Autores VALUES(382, 'Richard ', 'Daft');
INSERT INTO Autores VALUES(490, 'Idalberto ', 'Chiavenato');
INSERT INTO Autores VALUES(105, 'Philip ', 'Cateora');
INSERT INTO Autores VALUES(320, 'Svend ', 'Hollensen');
INSERT INTO Autores VALUES(310, 'Teodoro ', 'Martinez');
INSERT INTO Autores VALUES(195, 'Mateo ', 'Elorza');
INSERT INTO Autores VALUES(168, 'David ', 'Hockney');
INSERT INTO Autores VALUES(394, 'Joanne ', 'Dochterman');
INSERT INTO Autores VALUES(170, 'Michael ', 'Foucault');
INSERT INTO Autores VALUES(60, 'Denise ', 'Brown');
INSERT INTO Autores VALUES(32, 'Kar ', 'Schlogel');
INSERT INTO Autores VALUES(352, 'Scott ', 'Fitzgerald');
INSERT INTO Autores VALUES(142, 'Bradley ', 'Schiller');
