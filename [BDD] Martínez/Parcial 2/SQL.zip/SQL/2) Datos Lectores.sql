USE Parcial2_BBDD

GO

INSERT INTO Lectores VALUES(7461558, 'Emil ', 'Schmied');
INSERT INTO Lectores VALUES(8138106, 'Rodrigo ', 'Inostroza');
INSERT INTO Lectores VALUES(11456789, 'Pepe ', 'Ju�rez');
INSERT INTO Lectores VALUES(12000333, 'Sebasti�n ', 'Peralta');
INSERT INTO Lectores VALUES(13698283, 'Isabel ', 'Cavieres');
INSERT INTO Lectores VALUES(20818325, 'Carlos ', 'Reyes');
INSERT INTO Lectores VALUES(23999666, 'Pepa ', 'Rosas');
INSERT INTO Lectores VALUES(24590987, 'Jasper ', 'Moernaut');
INSERT INTO Lectores VALUES(24938546, 'Rodrigo ', 'Mura');
INSERT INTO Lectores VALUES(31304307, 'Ricardo ', 'Valenzuela');
INSERT INTO Lectores VALUES(31633572, 'Tirza ', 'Catal�n');
INSERT INTO Lectores VALUES(36100963, 'Alexia ', 'Guerra');
INSERT INTO Lectores VALUES(36982834, 'Beate ', 'Messing');
INSERT INTO Lectores VALUES(53825831, 'Rodrigo ', 'Vega');
INSERT INTO Lectores VALUES(60333444, 'Ivana ', 'Romox');
INSERT INTO Lectores VALUES(78333111, 'Mariano ', 'Rodr�guez');
INSERT INTO Lectores VALUES(87546357, 'Sergio ', 'Hoppe');
INSERT INTO Lectores VALUES(89555111, 'Catena ', 'Mart�nez');
INSERT INTO Lectores VALUES(99555666, 'Eduardo ', 'P�rez');
