# Mostrar varias veces y ver el resultado

MiSet = {"Pera","Uva","Manzana","Naranja","Melón"}
print(MiSet)

for x in MiSet:
    print(x)

MiSet.update(["Frutilla","Limón"])
print(MiSet)
for x in MiSet:
    print(x)
MiSet.discard("xx")