print("Hola Mundo !!!")
a=True
print(type(a))
z=3
print(type(ord("3")))
if 3>7:
    print("7 es mayor a 3")    
    print("3 es menor a 7")

z="*" * 3
print(z)

w = int("2")
