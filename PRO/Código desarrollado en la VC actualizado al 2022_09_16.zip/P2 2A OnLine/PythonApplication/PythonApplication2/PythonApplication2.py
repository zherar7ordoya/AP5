#split genera una lista de elementos
a="Hola, Mundo"
b=a.split(",")
print(b);

#largo de una lista

a=["a","b","c",1,2,3]
print(len(a))
print(a[-3])


