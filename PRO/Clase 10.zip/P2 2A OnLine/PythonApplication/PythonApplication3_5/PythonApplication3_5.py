l=[0,1,2,3]
l2= [n ** 2 for n in l]
print(l2)

l2=(n ** 2 for n in l)
print(l2)



