def mi_generador(n,m,s):
    while(n<=m):
        yield n
        n+=s

for n in mi_generador(0,5,1):
    print(n)

lista=list(mi_generador(0,5,1))
print(lista)
