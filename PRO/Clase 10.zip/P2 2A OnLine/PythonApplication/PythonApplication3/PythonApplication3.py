import numpy as np
import pip
import pygame

# Mostrar varias veces y ver el resultado

MiSet = {"Pera","Uva","Manzana","Naranja","Melón"}
print(MiSet)

for x in MiSet:
    print(x)

MiSet.update(["Frutilla","Limón"])
print(MiSet)
for x in MiSet:
    print(x)
MiSet.discard("Pera")
print("------")
for x in MiSet:
    print(x)

arr= np.array([[1,2,3,4,5],[6,7,8,9,10]])

print(arr[1,-1])
print(arr[-2,-1])



