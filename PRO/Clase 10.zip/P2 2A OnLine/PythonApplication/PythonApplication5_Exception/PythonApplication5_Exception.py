#exception basica con try y exception
#def division(a,b):
#    try:
#        return a/b
#    except ZeroDivisionError:
#        print("Error de división !!!")

#x=division(10,0)
#print(x)
#################################
#exception con dos tipos de excepciones (NameError y ValueError)
#try:
#    numeroEntero=int("3Z")
#    print("LLegamos a esta linea !!!")
#except(NameError,ValueError):
#    print("Error !!!")
#################################
# Excepción con else (se pasa por alli cuando no se da ninguna excepción)
#         y con finally (Siempre se pasa por el finally se haya dado a ono una excepción)  
#try:
#    numeroEntero=int("3S")
#    print("LLegamos a esta linea !!!")
#except(NameError,ValueError):
#    print("Error !!!")
#else:
#    print("No sa ha producido ningún error !!!")
#finally:
#    print("Siempre pasamos por aquí (finally) haya errores o no !!!")
#################################
# Construcción de una excdpción personalizada
class ValorMayor100(Exception):
    def __init__(self, valor):
            self.valor=valor
    def __str__(self):
        return "El error lo da " + str(self.valor)

try:
    if 120>100:
        raise ValorMayor100(120)
except ValorMayor100 as e:
    print(e)

