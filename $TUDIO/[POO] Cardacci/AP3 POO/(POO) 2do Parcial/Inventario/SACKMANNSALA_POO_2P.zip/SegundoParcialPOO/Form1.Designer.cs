﻿namespace SegundoParcialPOO
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Articulos1 = new System.Windows.Forms.DataGridView();
            this.AltaArticulo = new System.Windows.Forms.Button();
            this.tipoCosto = new System.Windows.Forms.ComboBox();
            this.BajaArticulo = new System.Windows.Forms.Button();
            this.ModificarArticulo = new System.Windows.Forms.Button();
            this.AumentarStock = new System.Windows.Forms.Button();
            this.DisminuirStock = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DIT = new System.Windows.Forms.Label();
            this.Articulos2 = new System.Windows.Forms.DataGridView();
            this.funcionA = new System.Windows.Forms.Button();
            this.funcionB = new System.Windows.Forms.Button();
            this.funcionC1 = new System.Windows.Forms.Button();
            this.funcionC2 = new System.Windows.Forms.Button();
            this.funcionD = new System.Windows.Forms.Button();
            this.funcionE = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Articulos1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Articulos2)).BeginInit();
            this.SuspendLayout();
            // 
            // Articulos1
            // 
            this.Articulos1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Articulos1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Articulos1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Articulos1.Location = new System.Drawing.Point(12, 12);
            this.Articulos1.Name = "Articulos1";
            this.Articulos1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Articulos1.Size = new System.Drawing.Size(1097, 171);
            this.Articulos1.TabIndex = 0;
            // 
            // AltaArticulo
            // 
            this.AltaArticulo.Location = new System.Drawing.Point(1131, 34);
            this.AltaArticulo.Name = "AltaArticulo";
            this.AltaArticulo.Size = new System.Drawing.Size(79, 34);
            this.AltaArticulo.TabIndex = 1;
            this.AltaArticulo.Text = "Alta";
            this.AltaArticulo.UseVisualStyleBackColor = true;
            this.AltaArticulo.Click += new System.EventHandler(this.AltaArticulo_Click);
            // 
            // tipoCosto
            // 
            this.tipoCosto.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tipoCosto.FormattingEnabled = true;
            this.tipoCosto.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tipoCosto.Items.AddRange(new object[] {
            "CPP",
            "CUE",
            "CP"});
            this.tipoCosto.Location = new System.Drawing.Point(1237, 39);
            this.tipoCosto.Name = "tipoCosto";
            this.tipoCosto.Size = new System.Drawing.Size(121, 21);
            this.tipoCosto.TabIndex = 2;
            this.tipoCosto.Text = "Tipo Calculo Costo";
            // 
            // BajaArticulo
            // 
            this.BajaArticulo.Location = new System.Drawing.Point(1243, 91);
            this.BajaArticulo.Name = "BajaArticulo";
            this.BajaArticulo.Size = new System.Drawing.Size(79, 34);
            this.BajaArticulo.TabIndex = 3;
            this.BajaArticulo.Text = "Baja";
            this.BajaArticulo.UseVisualStyleBackColor = true;
            this.BajaArticulo.Click += new System.EventHandler(this.BajaArticulo_Click);
            // 
            // ModificarArticulo
            // 
            this.ModificarArticulo.Location = new System.Drawing.Point(1131, 91);
            this.ModificarArticulo.Name = "ModificarArticulo";
            this.ModificarArticulo.Size = new System.Drawing.Size(79, 34);
            this.ModificarArticulo.TabIndex = 4;
            this.ModificarArticulo.Text = "Modificacion";
            this.ModificarArticulo.UseVisualStyleBackColor = true;
            this.ModificarArticulo.Click += new System.EventHandler(this.ModificarArticulo_Click);
            // 
            // AumentarStock
            // 
            this.AumentarStock.Location = new System.Drawing.Point(981, 190);
            this.AumentarStock.Name = "AumentarStock";
            this.AumentarStock.Size = new System.Drawing.Size(61, 34);
            this.AumentarStock.TabIndex = 5;
            this.AumentarStock.Text = "Aumentar";
            this.AumentarStock.UseVisualStyleBackColor = true;
            this.AumentarStock.Click += new System.EventHandler(this.AumentarStock_Click);
            // 
            // DisminuirStock
            // 
            this.DisminuirStock.Location = new System.Drawing.Point(1048, 189);
            this.DisminuirStock.Name = "DisminuirStock";
            this.DisminuirStock.Size = new System.Drawing.Size(61, 34);
            this.DisminuirStock.TabIndex = 6;
            this.DisminuirStock.Text = "Disminuir";
            this.DisminuirStock.UseVisualStyleBackColor = true;
            this.DisminuirStock.Click += new System.EventHandler(this.DisminuirStock_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(930, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Stock";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1223, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Artículos";
            // 
            // DIT
            // 
            this.DIT.AutoSize = true;
            this.DIT.Location = new System.Drawing.Point(777, 201);
            this.DIT.Name = "DIT";
            this.DIT.Size = new System.Drawing.Size(119, 13);
            this.DIT.TabIndex = 10;
            this.DIT.Text = "dinero inmovilizado total";
            // 
            // Articulos2
            // 
            this.Articulos2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Articulos2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Articulos2.Location = new System.Drawing.Point(13, 268);
            this.Articulos2.Name = "Articulos2";
            this.Articulos2.ReadOnly = true;
            this.Articulos2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Articulos2.Size = new System.Drawing.Size(1096, 179);
            this.Articulos2.TabIndex = 11;
            // 
            // funcionA
            // 
            this.funcionA.Location = new System.Drawing.Point(1132, 277);
            this.funcionA.Name = "funcionA";
            this.funcionA.Size = new System.Drawing.Size(91, 46);
            this.funcionA.TabIndex = 12;
            this.funcionA.Text = "Stock mayor a";
            this.funcionA.UseVisualStyleBackColor = true;
            this.funcionA.Click += new System.EventHandler(this.funcionA_Click);
            // 
            // funcionB
            // 
            this.funcionB.Location = new System.Drawing.Point(1259, 277);
            this.funcionB.Name = "funcionB";
            this.funcionB.Size = new System.Drawing.Size(92, 46);
            this.funcionB.TabIndex = 13;
            this.funcionB.Text = "Stock =0";
            this.funcionB.UseVisualStyleBackColor = true;
            this.funcionB.Click += new System.EventHandler(this.funcionB_Click);
            // 
            // funcionC1
            // 
            this.funcionC1.Location = new System.Drawing.Point(1156, 401);
            this.funcionC1.Name = "funcionC1";
            this.funcionC1.Size = new System.Drawing.Size(79, 46);
            this.funcionC1.TabIndex = 14;
            this.funcionC1.Text = "Forma Ascendente";
            this.funcionC1.UseVisualStyleBackColor = true;
            this.funcionC1.Click += new System.EventHandler(this.funcionC1_Click);
            // 
            // funcionC2
            // 
            this.funcionC2.Location = new System.Drawing.Point(1244, 401);
            this.funcionC2.Name = "funcionC2";
            this.funcionC2.Size = new System.Drawing.Size(79, 46);
            this.funcionC2.TabIndex = 15;
            this.funcionC2.Text = "Forma Descendente";
            this.funcionC2.UseVisualStyleBackColor = true;
            this.funcionC2.Click += new System.EventHandler(this.funcionC2_Click);
            // 
            // funcionD
            // 
            this.funcionD.Location = new System.Drawing.Point(1132, 329);
            this.funcionD.Name = "funcionD";
            this.funcionD.Size = new System.Drawing.Size(91, 46);
            this.funcionD.TabIndex = 16;
            this.funcionD.Text = "De baja";
            this.funcionD.UseVisualStyleBackColor = true;
            this.funcionD.Click += new System.EventHandler(this.funcionD_Click);
            // 
            // funcionE
            // 
            this.funcionE.Location = new System.Drawing.Point(1259, 329);
            this.funcionE.Name = "funcionE";
            this.funcionE.Size = new System.Drawing.Size(92, 46);
            this.funcionE.TabIndex = 17;
            this.funcionE.Text = "Stock entre";
            this.funcionE.UseVisualStyleBackColor = true;
            this.funcionE.Click += new System.EventHandler(this.funcionE_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1153, 378);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Ordenar por alfabético (descripción)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1195, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Seleccionar artículos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 480);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.funcionE);
            this.Controls.Add(this.funcionD);
            this.Controls.Add(this.funcionC2);
            this.Controls.Add(this.funcionC1);
            this.Controls.Add(this.funcionB);
            this.Controls.Add(this.funcionA);
            this.Controls.Add(this.Articulos2);
            this.Controls.Add(this.DIT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DisminuirStock);
            this.Controls.Add(this.AumentarStock);
            this.Controls.Add(this.ModificarArticulo);
            this.Controls.Add(this.BajaArticulo);
            this.Controls.Add(this.tipoCosto);
            this.Controls.Add(this.AltaArticulo);
            this.Controls.Add(this.Articulos1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Articulos1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Articulos2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Articulos1;
        private System.Windows.Forms.Button AltaArticulo;
        private System.Windows.Forms.ComboBox tipoCosto;
        private System.Windows.Forms.Button BajaArticulo;
        private System.Windows.Forms.Button ModificarArticulo;
        private System.Windows.Forms.Button AumentarStock;
        private System.Windows.Forms.Button DisminuirStock;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label DIT;
        private System.Windows.Forms.DataGridView Articulos2;
        private System.Windows.Forms.Button funcionA;
        private System.Windows.Forms.Button funcionB;
        private System.Windows.Forms.Button funcionC1;
        private System.Windows.Forms.Button funcionC2;
        private System.Windows.Forms.Button funcionD;
        private System.Windows.Forms.Button funcionE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

