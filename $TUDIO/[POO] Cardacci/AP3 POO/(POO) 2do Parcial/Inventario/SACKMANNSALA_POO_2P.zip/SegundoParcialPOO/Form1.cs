﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SegundoParcialPOO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Comercio comercio = new Comercio();

        private void Form1_Load(object sender, EventArgs e)//* Cargo el formulario con algunos casos de ejemplo.
        {
            Articulo articulo = new Articulo("A66612", "articuloa", DateTime.Today, default, new Articulo.CPP(), 0);
            Articulo articulo2 = new Articulo("B88854", "articulob", DateTime.Today, default, new Articulo.CUE(), 0);
            articulo.AumentarStock(80, 2); articulo2.AumentarStock(100, 43);
            articulo.StockCero += Mensaje_StockCero;
            articulo2.StockCero += Mensaje_StockCero;
            comercio.LA = new List<Articulo>() { articulo, articulo2 };
            Mostrar(Articulos1, comercio.vista());
            DIT.Text = comercio.DIT().ToString();
        }
        private void Mostrar(DataGridView DG, Object PO)//* Método para cargar grillas y mostrar datos
        {
            try
            {
                DG.DataSource = null; DG.DataSource = PO;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }
        public class Articulo : ICloneable
        {

            public Articulo() { }

            public Articulo(string pCodigo, string pDescripcion, DateTime pFechaAlta, DateTime pFechaBaja, Costo pcosto, uint pStock)
            {
                Codigo = pCodigo;
                Descripcion = pDescripcion;
                FechaAlta = pFechaAlta;
                FechaBaja = pFechaBaja;
                costo = pcosto;
                Stock = pStock;

            }
            string _c;
            public string Codigo { get { return _c; } set { if (FechaBaja == default) { _c = value; } } }

            string _d;
            public string Descripcion { get { return _d; } set { if (FechaBaja == default) { _d = value; } } }
            public DateTime FechaAlta { get; set; }
            public DateTime FechaBaja { get; set; }

            public Costo costo;

            uint _s;
            public uint Stock { get { return _s; } set { if (FechaBaja == default) { _s = value; } } }

            public event EventHandler<StockCeroEventArgs> StockCero;

            public void DisminuirStock(uint cedido)//*Disminución de stock con su evento programado StockCero cuando llega a 0.
            {
                if (FechaBaja == default)
                {
                    this.Stock -= cedido;
                    if (this.Stock == 0) { StockCero?.Invoke(this, new StockCeroEventArgs(this)); }
                }
            }

            public void AumentarStock(float precio, uint ingresado)//*Aumento de stock con el calculo del costo que se actualiza.
            {
                if (FechaBaja == default)
                {
                    this.costo.CalcularCosto(precio, this.Stock, ingresado);
                    this.Stock += ingresado;
                }
            }

            public abstract class Costo : ICloneable//* Clase abstracta costo que es parte de Artículo
            {
                public Costo() { }

                public abstract void CalcularCosto(float cua, uint sta, uint qa);

                public float costoactual;

                public string Id;

                public string Descripcion;
                public object Clone()
                {
                    return this.MemberwiseClone();
                }
            }

            public class CPP : Costo//* Clase hija costo con la toma de control sobre el metodo calcularcosto.
            {
                public CPP() : base()
                {
                    Id = "CPP";
                    Descripcion = "((CPP * STA) + (CUA * QA)) / (STA+QA)";
                }

                public override void CalcularCosto(float cua, uint sta, uint qa)
                {
                    cpp = ((cpp * sta) + (cua * qa)) / (sta + qa);
                    costoactual = cpp;
                }
                public float cpp { get; set; }
            }

            public class CUE : Costo//* Clase hija costo con la toma de control sobre el metodo calcularcosto.
            {

                public CUE() : base()
                {
                    Id = "CUE";
                    Descripcion = "Costo unitario del último lote de ingresado";
                }
                public override void CalcularCosto(float cua, uint sta, uint qa)
                {
                    if (cue == 0) { costoactual = cua; }
                    else { costoactual = cue; }
                    cue = cua;
                }
                public float cue { get; set; }
            }

            public class CP : Costo//* Clase hija costo con la toma de control sobre el metodo calcularcosto.
            {

                public CP() : base()
                {
                    Id = "CP";
                    Descripcion = "((CP + CA) / 2) * 1,1";
                }

                public override void CalcularCosto(float cua, uint sta, uint qa)
                {
                    cp = ((cp + qa) / 2) * (float)1.1;
                    costoactual = cp;
                }
                public float cp { get; set; }
            }

            public object Clone()//*Metodo para clonar artículo de forma superficial.
            {
                return this.MemberwiseClone();
            }

            public Articulo Clonar()//*Metodo para clonar artículo de forma profunda.
            {
                Articulo A = (Articulo)this.MemberwiseClone();
                if (A.costo != null) { A.costo = (Costo)this.costo.Clone(); }
                return A;
            }

            public class DescrAsc : IComparer<Articulo>//*Icomparer para ordenar por descripción de forma ascendente.
            {
                public int Compare(Articulo x, Articulo y)
                {
                    return String.Compare(x.Descripcion, y.Descripcion);
                }
            }

            public class DescrDesc : IComparer<Articulo>//*Icomparer para ordenar por descripción de forma descendente.
            {
                public int Compare(Articulo x, Articulo y)
                {
                    return String.Compare(x.Descripcion, y.Descripcion) * -1;
                }
            }
            public class MesesMayorMenor : IComparer<Articulo>//*Icomparer para ordenar por meses vigentes de forma descendente.
            {
                public int Compare(Articulo x, Articulo y)
                {
                    int rdo = 0;
                    int mvx, mvy;
                    if (x.FechaBaja != default && y.FechaBaja != default) 
                    { 
                        mvx = DiferenciaMeses(x.FechaBaja, x.FechaAlta);
                        mvy = DiferenciaMeses(y.FechaBaja, y.FechaAlta);
                        if (mvx < mvy) rdo = 1;
                        if (mvx == mvy) rdo = 0;
                        if (mvx > mvy) rdo = -1;
                    }
                    return rdo;
                }
            }

        }

        public class ArticuloVista//*Clase vista de artículo para mostrar en grilla.
        {
            public ArticuloVista(Articulo pArticulo)
            {
                Codigo = pArticulo.Codigo;
                Descripcion = pArticulo.Descripcion;
                FechaAlta = pArticulo.FechaAlta;
                FechaBaja = pArticulo.FechaBaja;
                Costo = pArticulo.costo.costoactual;
                DescripcionCosto = pArticulo.costo.Descripcion;
                Stock = pArticulo.Stock;
            }

            public string Codigo { get; set; }
            public string Descripcion { get; set; }
            public DateTime FechaAlta { get; set; }
            public DateTime FechaBaja { get; set; }

            public string MesesVigente { get
                {
                    string _ms = "";
                    if (FechaBaja == default) { _ms = "--"; }
                    else { _ms = DiferenciaMeses(FechaBaja, FechaAlta).ToString(); }
                    return _ms;
                }
            }

            public float Costo { get; set; }
            public string DescripcionCosto { get; set; }
            public uint Stock { get; set; }

        }

        public static int DiferenciaMeses(DateTime pfechabaja, DateTime pfechaalta)//*Método para calcular diferencia de meses entre FechaAlta y FechaBaja
        {
            int difmeses = 12 * (pfechabaja.Year - pfechaalta.Year) + pfechabaja.Month - pfechaalta.Month;
            return Math.Abs(difmeses);
        }

        public class ArticuloVista2//*Clase vista de artículo para mostrar solo descripción.
        {
            public ArticuloVista2() { }

            public string Descripcion { get; set; }

        }

        public class Comercio : ICloneable//* Clase que contiene lista de artículos y métodos para vistas.
        {
            public Comercio() { }

            public List<Articulo> LA { get; set; }

            public List<ArticuloVista> vista()
            {
                List<ArticuloVista> vistas = new List<ArticuloVista>();
                foreach (Articulo a in LA)
                {
                    vistas.Add(new ArticuloVista(a));
                }
                return vistas;
            }


            public List<ArticuloVista2> vista2(IEnumerable<string> descripciones)
            {
                List<ArticuloVista2> vistas2 = new List<ArticuloVista2>();
                foreach (string s in descripciones)
                {
                    ArticuloVista2 v = new ArticuloVista2();
                    v.Descripcion = s;
                    vistas2.Add(v);
                }
                return vistas2;
            }

            public object Clone()//*Clonación superficial
            {
                return this.MemberwiseClone();
            }

            public Comercio Clonar()//*Clonación profunda
            {
                Comercio C = (Comercio)this.MemberwiseClone();
                if (C.LA != null) 
                {
                    List<Articulo> articulos = new List<Articulo>();
                    foreach (Articulo a in LA)
                    {
                        Articulo art = a.Clonar();
                        articulos.Add(art);

                    }
                    C.LA = articulos;
                }
                return C;
            }
            public float DIT()//*Calculo de dinero inmovilizado total que tenemos en el stock (cantidad * costo de todos los artículos)
            {
                float dit = 0;
                foreach (Articulo a in LA)
                {
                    dit += a.costo.costoactual * a.Stock;
                }
                return dit;
            }

        }


        private void AltaArticulo_Click(object sender, EventArgs e)//*Evento click en botón da de alta artículo.
        {
            try
            {
                Articulo art = new Articulo();
                int i = tipoCosto.SelectedIndex;
                if (!(i> -1))//*Verifica que se haya seleccionada el tipo de costo del artículo.
                {
                    throw new Exception("Debe seleccionar el tipo de costo");
                }
                switch (i)//*Asigna el tipo de costo
                {
                    case 0:
                        art.costo = new Articulo.CPP();
                        break;
                    case 1:
                        art.costo = new Articulo.CUE();
                        break;
                    case 2:
                        art.costo  = new Articulo.CP();
                        break;
                }

                string codigo = Interaction.InputBox("Ingresar código del artículo");

                while (!UnCaracterCincoNumeros(codigo) || comercio.LA.Exists(a => a.Codigo == codigo))//*Valida que el ingreso sean números y que no exista el código entre los artículos existentes.
                {
                    if (!UnCaracterCincoNumeros(codigo)) { Interaction.MsgBox("Ingresar una letra mayúsculas y 5 dígitos (p.eP00001)"); }
                    else { Interaction.MsgBox("El artículo ya existe"); }
                    codigo = Interaction.InputBox("Ingresar código del artículo");
                }

                art.Codigo = codigo;

                string descripcion = Interaction.InputBox("Ingresar descripción del artículo");

                art.Descripcion = descripcion;

                art.FechaAlta = DateTime.Today;

                art.StockCero += Mensaje_StockCero;

                string pPrecio = Interaction.InputBox("Ingrese costo unitario de los artículos adquiridos que ingresan al stock");
                while (!float.TryParse(pPrecio, out _) || float.Parse(pPrecio) <= 0)//*Valida que el ingreso sea número y positivo.
                {
                    if (!float.TryParse(pPrecio, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("El precio no puede ser negativo o 0"); }
                    pPrecio = Interaction.InputBox("Ingrese costo unitario de los artículos adquiridos que ingresan al stock");
                }

                string pStock = Interaction.InputBox("Ingrese cantidad de artículos adquiridos.");
                while (!uint.TryParse(pStock, out _) || uint.Parse(pStock) <= 0)//*Valida que el ingreso sea número y positivo.
                {
                    if (!uint.TryParse(pStock, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("La cantidad no puede ser negativa ni nula"); }
                    pStock = Interaction.InputBox("Ingrese cantidad de artículos adquiridos.");
                }
                art.AumentarStock(float.Parse(pPrecio), uint.Parse(pStock));

                comercio.LA.Add(art);

                Mostrar(Articulos1, comercio.vista());
                DIT.Text = comercio.DIT().ToString();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private bool EsNumero(string pvalor)
        {
            int _temp = 0;
            return int.TryParse(pvalor, out _temp);
        }

        private bool UnCaracterCincoNumeros(string pvalor)//*Método de validación de código de artículo.
        {
            if (pvalor == "") { return false; }
            return !EsNumero(pvalor[0].ToString()) && char.IsUpper(pvalor[0]) && EsNumero(pvalor.Substring(1)) && pvalor.Length == 6;
        }

        private void BajaArticulo_Click(object sender, EventArgs e)//*Evento click en botón da de baja artículo.
        {
            try
            {
                if (Articulos1.SelectedCells[0].RowIndex == -1)//*Verifica que se haya seleccionado artículo a dar de baja.
                {
                    throw new Exception("Debe seleccionar el artículo en la grilla");
                }
                int i = Articulos1.SelectedCells[0].RowIndex;
                comercio.LA[i].FechaBaja = DateTime.Today;
                Mostrar(Articulos1, comercio.vista());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void ModificarArticulo_Click(object sender, EventArgs e)//*Evento click en botón modifica artículo
        {
            try
            {
                if (Articulos1.SelectedCells[0].RowIndex == -1)//*Verifica que se haya seleccionado artículo a modificar.
                {
                    throw new Exception("Debe seleccionar el artículo en la grilla");
                }
                int i = Articulos1.SelectedCells[0].RowIndex;

                if (comercio.LA[i].FechaBaja != default)//*Verifica que el artículo no haya sido dado de baja.
                {
                    throw new Exception("El artículo se ha dejado de comercializar\nNo se pueden realizar cambios en él ni en su stock.");
                }
                string pCodigo, pDescripcion, pFechaAlta, pFechaBaja;

                pCodigo = Interaction.InputBox($"Codigo: {comercio.LA[i].Codigo} - Codigo Nuevo:");
                while ((!UnCaracterCincoNumeros(pCodigo) || comercio.LA.Exists(a => a.Codigo == pCodigo)) && pCodigo != "")//*Valida que el ingreso sean números y que no exista el código entre los artículos existentes.
                {
                    if (!UnCaracterCincoNumeros(pCodigo)) { Interaction.MsgBox("Ingresar una letra mayúsculas y 5 dígitos (p.eP00001)"); }
                    else { Interaction.MsgBox("El código de artículo ya existe"); }
                    pCodigo = Interaction.InputBox("Ingresar código del artículo");
                }
                if (pCodigo != "") comercio.LA[i].Codigo = pCodigo;

                pDescripcion = Interaction.InputBox($"Descripcion: {comercio.LA[i].Descripcion} - Descripción Nueva:");
                if (pDescripcion != "") comercio.LA[i].Descripcion = pDescripcion;


                pFechaAlta = Interaction.InputBox($"Fecha Alta: {comercio.LA[i].FechaAlta} - Fecha Alta Nueva:");
                while ((!DateTime.TryParse(pFechaAlta, out _) || (DateTime.Parse(pFechaAlta) > comercio.LA[i].FechaBaja && comercio.LA[i].FechaBaja != default)) && pFechaAlta != "")
                //*Verifica que se haya ingresado una fecha y que la fecha de alta no sea posterior a la de baja.
                {
                    if (!DateTime.TryParse(pFechaAlta, out _)) { Interaction.MsgBox("Ingresar una fecha"); }
                    else { Interaction.MsgBox("La fecha de alta no puede ser posterior a la fecha de baja"); }
                    pFechaAlta = Interaction.InputBox($"Fecha Alta: {comercio.LA[i].FechaAlta} - Fecha Alta Nueva:");
                }
                if (pFechaAlta != "") comercio.LA[i].FechaAlta = DateTime.Parse(pFechaAlta);


                pFechaBaja = Interaction.InputBox($"Fecha Baja: {comercio.LA[i].FechaBaja} - Fecha Baja Nueva:");
                while ((!DateTime.TryParse(pFechaBaja, out _) || comercio.LA[i].FechaAlta > DateTime.Parse(pFechaBaja)) && pFechaBaja != "")
                //*Verifica que se haya ingresado una fecha y que la fecha de alta no sea posterior a la de baja.
                {
                    if (!DateTime.TryParse(pFechaBaja, out _)) { Interaction.MsgBox("Ingresar una fecha"); }
                    else { Interaction.MsgBox("La fecha de alta no puede ser posterior a la fecha de baja"); }
                    pFechaBaja = Interaction.InputBox($"Fecha Baja: {comercio.LA[i].FechaBaja} - Fecha Baja Nueva:");
                }
                if (pFechaBaja != "") comercio.LA[i].FechaBaja = DateTime.Parse(pFechaBaja);

                Mostrar(Articulos1, comercio.vista());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void AumentarStock_Click(object sender, EventArgs e)//*Evento click en botón aumenta stock.
        {
            try
            {
                if (Articulos1.SelectedCells[0].RowIndex == -1)//*Verifica que se haya seleccionado artículo.
                {
                    throw new Exception("Debe seleccionar el artículo en la grilla");
                }

                int i = Articulos1.SelectedCells[0].RowIndex;

                if (comercio.LA[i].FechaBaja != default)//*Verifica que el artículo no se haya dado de baja.
                {
                    throw new Exception("El artículo se ha dejado de comercializar\nNo se pueden realizar cambios en él ni en su stock.");
                }
                string pStock, pPrecio;

                pPrecio = Interaction.InputBox("Ingrese costo unitario de los artículos adquiridos que ingresan al stock");
                while (!float.TryParse(pPrecio, out _) || float.Parse(pPrecio) <= 0)
                {
                    if (!float.TryParse(pPrecio, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("El precio no puede ser negativo o 0"); }
                    pPrecio = Interaction.InputBox("Ingrese costo unitario de los artículos adquiridos que ingresan al stock");
                }

                pStock = Interaction.InputBox("Ingrese cantidad de artículos adquiridos.");
                while (!uint.TryParse(pStock, out _) || uint.Parse(pStock) <= 0)
                {
                    if (!uint.TryParse(pStock, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("La cantidad no puede ser negativa ni nula"); }
                    pStock = Interaction.InputBox("Ingrese cantidad de artículos adquiridos.");
                }
                comercio.LA[i].AumentarStock(float.Parse(pPrecio), uint.Parse(pStock));
                Mostrar(Articulos1, comercio.vista());
                DIT.Text = comercio.DIT().ToString();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void DisminuirStock_Click(object sender, EventArgs e)//*Evento click en botón disminuye stock.
        {
            try
            {
                if (Articulos1.SelectedCells[0].RowIndex == -1)//*Verifica que se haya seleccionado artículo.
                {
                    throw new Exception("Debe seleccionar el artículo en la grilla");
                }

                int i = Articulos1.SelectedCells[0].RowIndex;

                if (comercio.LA[i].FechaBaja != default)//*Verifica que el artículo no se haya dado de baja.
                {
                    throw new Exception("El artículo se ha dejado de comercializar\nNo se pueden realizar cambios en él ni en su stock.");
                }
                string pStock;

                pStock = Interaction.InputBox("Ingrese cantidad de artículos cedidos.");
                while ((!uint.TryParse(pStock, out _) || uint.Parse(pStock) > comercio.LA[i].Stock) && pStock != "")
                {
                    if (!uint.TryParse(pStock, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("Cantidad excede el stock actual."); }
                    pStock = Interaction.InputBox("Ingrese cantidad de artículos cedidos.");
                }
                if (pStock != "") comercio.LA[i].DisminuirStock(uint.Parse(pStock));
                Mostrar(Articulos1, comercio.vista());
                DIT.Text = comercio.DIT().ToString();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public class StockCeroEventArgs : EventArgs//*Argumentos Evento StockCero
        {
            public StockCeroEventArgs(Articulo pArticulo) { articulo = pArticulo; }
            public Articulo articulo { get; set; }
        }

        private void Mensaje_StockCero(object sender, StockCeroEventArgs e)//*Método disparado por evento StockCero
        {
            try
            {
                MessageBox.Show("El stock del artículo " + e.articulo.Codigo + " " + e.articulo.Descripcion + " llegó a cero");
            }
            catch (Exception) { }
        }

        delegate bool del(uint s);
        delegate bool del2(DateTime f);

        private void funcionA_Click(object sender, EventArgs e)//*Proyecta todos los artículos cuyo stock sea superior al valor ingresado por el usuario
        {
            try
            {

                Comercio C = comercio.Clonar();

                string pStock = Interaction.InputBox("Stock mayor a:");
                while (!uint.TryParse(pStock, out _) || uint.Parse(pStock) < 0)
                {
                    if (!uint.TryParse(pStock, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("La cantidad no puede ser negativa"); }
                    pStock = Interaction.InputBox("Stock mayor a:");
                }
                del miDelegado = s => s> uint.Parse(pStock);
            C.LA = (from a in C.LA where miDelegado(a.Stock) select a).ToList();
            Mostrar(Articulos2, C.vista());
        }
            catch (Exception) { }
}

        private void funcionB_Click(object sender, EventArgs e)//*Proyecta la descripción de todos los artículos dónde el stock sea igual a cero.
        {
            try
            {
                IEnumerable<string> qb;
                qb = (from a in comercio.LA
                      where a.Stock == 0
                      select a.Descripcion);

                List<ArticuloVista2> vista2 = comercio.vista2(qb.ToList());
                Mostrar(Articulos2, vista2);
            }
            catch (Exception) { }
        }

        private void funcionC1_Click(object sender, EventArgs e)//*Muestra todos los artículos ordenados alfabéticamente por descripción de manera ascendente.
        {
            try
            {

                Comercio c = comercio.Clonar();
                c.LA.Sort(new Articulo.DescrAsc());
                Mostrar(Articulos2, c.vista());
            }
            catch (Exception) { }
        }

        private void funcionC2_Click(object sender, EventArgs e)//*Muestra todos los artículos ordenados alfabéticamente por descripción de manera descendente.
        {
            try
            {

                Comercio c = comercio.Clonar();
                c.LA.Sort(new Articulo.DescrDesc());
                Mostrar(Articulos2, c.vista());
            }
            catch (Exception) { }
        }

        private void funcionD_Click(object sender, EventArgs e)//*Proyecta todos los artículos que poseen fecha de baja ordenados de mayor a menor por la cantidad de meses vigente.
        {
            try
            {

                Comercio C = comercio.Clonar();
                del2 miDelegado = f => f != default;
                C.LA = (from a in C.LA where miDelegado(a.FechaBaja) select a).ToList();
                C.LA.Sort(new Articulo.MesesMayorMenor());
                Mostrar(Articulos2, C.vista());
            }
            catch (Exception) { }
        }

        private void funcionE_Click(object sender, EventArgs e)//*Muestra todos los artículos cuyo Stock se encuentre por sobre el valor pStockInf ingresado por el usuario y por debajo del valor pStockSup también ingresado por el usuario.
        {
            try
            {

                Comercio C = comercio.Clonar();

                string pStockInf = Interaction.InputBox("Stock entre (límite inferior):");
                while (!uint.TryParse(pStockInf, out _) || uint.Parse(pStockInf) < 0)
                {
                    if (!uint.TryParse(pStockInf, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("La cantidad no puede ser negativa"); }
                    pStockInf = Interaction.InputBox("Stock entre (límite inferior):");
                }

                string pStockSup = Interaction.InputBox("Stock entre (límite superior):");
                while (!uint.TryParse(pStockSup, out _) || uint.Parse(pStockSup) < 0)
                {
                    if (!uint.TryParse(pStockSup, out _)) { Interaction.MsgBox("Ingresar solo números"); }
                    else { Interaction.MsgBox("La cantidad no puede ser negativa"); }
                    pStockSup = Interaction.InputBox("Stock entre (límite superior):");
                }

                if (uint.Parse(pStockSup)< uint.Parse(pStockInf))
                {
                    throw new Exception("El límite superior no puede ser menor al inferior.");
                }

                del miDelegado = s => s < uint.Parse(pStockSup) && s > uint.Parse(pStockInf);
                C.LA = (from a in C.LA where miDelegado(a.Stock) select a).ToList();
                Mostrar(Articulos2, C.vista());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
