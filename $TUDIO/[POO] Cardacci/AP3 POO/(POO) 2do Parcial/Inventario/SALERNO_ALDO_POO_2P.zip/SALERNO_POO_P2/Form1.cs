﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;


namespace SALERNO_POO_P2
{
    public partial class btnLinQ5 : Form
    {
        public btnLinQ5()
        {
            InitializeComponent();
        }
        #region Inicializaciones Iniciales
            public enum TipoCosto { CPP, CUE, CP };

            public TipoCosto Tc;
            int Stk1 = 0;
            int Stk2 = 0;
            string FechaBaja;
            Boolean EstadoStock;
            Double Total;

            Operacion Op = new Operacion();
            Stock VistaStock = new Stock();
            List<Articulo> _La = new List<Articulo>();
            List<Articulo> _Lb = new List<Articulo>();
        #endregion


        private void Form1_Load(object sender, EventArgs e)
        {
            Tc = TipoCosto.CPP;
            cbxCombo1.Items.Add(TipoCosto.CPP);
            cbxCombo1.Items.Add(TipoCosto.CUE);
            cbxCombo1.Items.Add(TipoCosto.CP);
            cbxCombo1.SelectedIndex = 0;

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            txtCodigo.Text = "";
            txtDescripcion.Text = "";
            txtCostoUnitario.Text = "0";
            txtCantidad.Text = "0";
            txtCantidad.TextAlign = HorizontalAlignment.Right;
            txtCostoUnitario.TextAlign = HorizontalAlignment.Right;


            //SUBSCRIPCION AL EVENTO 
            Op.StockCero += FuncionStockCero;

        }


        //ALTA DE ARTICULOS
        private void btnAlta_Click(object sender, EventArgs e)
        {
            if ((txtCodigo.Text == String.Empty || txtDescripcion.Text == String.Empty))
            {
                MessageBox.Show("INGRESE LOS VALORES SOLICITADOS");
            }
            else
            {
                //alta del articulo
                try
                {
                    Articulo _art = new Articulo();

                    // cargo el valor básico ingresado por pantalla para verificar si existe el articulo
                    _art.Codigo = txtCodigo.Text.ToUpper();

                    if (!Op.ArticuloExiste(_art))
                    {
                        _art.Descripcion = txtDescripcion.Text;
                        _art.FechaAlta = DateTime.Today;
                        _art.Stock = 0;
                        _art.TipoCosto = cbxCombo1.Text;
                        _art.MesesVigentes = "--";
                    }
                    else
                    {
                        throw new Exception("Artículo Existente");
                    }

                    Op.AgregaArticulo(_art);
                    MostrarEnGrilla(dataGridView1, Op.DevuelveListaArticulos());
                    cbxCombo2.Items.Add(txtCodigo.Text.ToUpper());
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //MOSTRAR EN LA GRILLA LOS VALORES CORRESPONDIENTES
        private void MostrarEnGrilla(DataGridView p_dataD, Object Valor)
        {
            p_dataD.DataSource = null;
            p_dataD.DataSource = Valor;

            if (((DataGridView)p_dataD).Name == "dataGridView1" && (((DataGridView)p_dataD).Rows.Count > 0))
                dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

            if (((DataGridView)p_dataD).Name == "dataGridView2" && (((DataGridView)p_dataD).Rows.Count > 0))
                dataGridView2.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

            if (((DataGridView)p_dataD).Name == "dataGridView3" && (((DataGridView)p_dataD).Rows.Count > 0))
                dataGridView3.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
        }


        //INGRESAR STOCK
        private void btnAumentaStock_Click(object sender, EventArgs e)
        {
            txtStkCero.Text = "";
            if ((cbxCombo2.Text == String.Empty || txtCantidad.Text == String.Empty || txtCostoUnitario.Text == String.Empty))
            {
                MessageBox.Show("INGRESE LOS VALORES SOLICITADOS");
            }
            else
            {
                //alta del stock del articulo
                try
                {
                    string TipoCosto;
                    Stock _stk = new Stock();

                    _stk.Codigo = cbxCombo2.Text;
                    _stk.Cantidad = int.Parse(txtCantidad.Text);
                    _stk.CostoUnitario = double.Parse(txtCostoUnitario.Text);

                    Op.AgregaMovimientoStock(_stk);
                    MostrarEnGrilla(dataGridView2, Op.DevuelveListaStock());

                    TipoCosto = Op.BuscoArticuloTipoCosto(_stk.Codigo);

                    switch (TipoCosto)
                    {
                        case "CPP":
                            CostoCPP Mcpp = new CostoCPP();
                            //a desarrollar
                            break;

                        case "CUE":
                            CostoCUE Mcue = new CostoCUE();
                            Mcue.ValorCue = _stk.CostoUnitario;
                            Mcue.ValorStock = _stk.Cantidad;
                            MostrarEnGrilla(dataGridView1, Op.AumentaStockEnArticulos(_stk.Codigo, Mcue.ValorCue, TipoCosto, Mcue.ValorStock));
                            break;

                        case "CP":
                            CostoCP Mcp = new CostoCP();
                            //a desarrollar
                            break;
                    }
                    Total = Op.TotalDinero();
                    textBox1.Text = Total.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        //STOCK CON CANTIDAD EN CERO
        private void BtnLinQ2_Click(object sender, EventArgs e)
        {
            {
                _La = Op.DevuelveListaArticulos();
                _Lb.Clear();

                IEnumerable<Articulo> T = from Art in _La where Art.Stock == 0 select Art;
                foreach (Articulo A in T.ToList<Articulo>())
                {
                    _Lb.Add(A);
                }
                MostrarEnGrilla(dataGridView3, _Lb);
            }
        }


        //STOCK CON CANTIDAD ENTRE DOS VALORES
        private void BtnLinQ5_Clic(object sender, EventArgs e)
        {
            _La = Op.DevuelveListaArticulos();
            _Lb.Clear();

            Stk1 = int.Parse(txtStock1.Text);
            Stk2 = int.Parse(txtStock2.Text);


            IEnumerable<Articulo> T = from Art in _La where (Art.Stock > Stk1 && Art.Stock < Stk2) select Art;
            foreach (Articulo A in T.ToList<Articulo>())
            {
                _Lb.Add(A);
            }
            MostrarEnGrilla(dataGridView3, _Lb);
        }


        //STOCK MAYOR A UNA CANTIDAD
        private void btnLinQ1_Click_1(object sender, EventArgs e)
        {
            _La = Op.DevuelveListaArticulos();
            _Lb.Clear();
            Stk1 = int.Parse(txtStock.Text);

            IEnumerable<Articulo> T = from Art in _La where Art.Stock > Stk1 select Art;
            foreach (Articulo A in T.ToList<Articulo>())
            {
                _Lb.Add(A);
            }
            MostrarEnGrilla(dataGridView3, _Lb);
        }


        //BAJA DE ARTICULOS
        private void btnBaja_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count <= 0)
            {
                return;
            }

            int CantMeses;
            int CantAnios;
            Articulo _LineaArticulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
            if (!(_LineaArticulo is null)) // si es un articulo válido
            {
                FechaBaja = Interaction.InputBox("Fecha", "Ingrese la Fecha Baja", FechaBaja);

                try
                {
                    DateTime.Parse(FechaBaja);


                    if (_LineaArticulo.FechaAlta > DateTime.Parse(FechaBaja))
                    {
                        MessageBox.Show("La Fecha de Alta no puede ser mayor a la Fecha de Baja");
                    }
                    else
                    {
                        CantAnios = DateTime.Parse(FechaBaja).Year - _LineaArticulo.FechaAlta.Year;
                        if (CantAnios == 0)
                        {
                            CantMeses = (DateTime.Parse(FechaBaja).Month - _LineaArticulo.FechaAlta.Month);
                        }
                        else
                        {
                            CantMeses = ((DateTime.Parse(FechaBaja).Month - _LineaArticulo.FechaAlta.Month) + 12) * CantAnios;
                        }
                        _LineaArticulo.FechaBaja = DateTime.Parse(FechaBaja);
                        _LineaArticulo.MesesVigentes = CantMeses.ToString();
                    }

                    MostrarEnGrilla(dataGridView1, Op.DevuelveListaArticulos());
                }
                catch
                {
                    MessageBox.Show("La Fecha es Incorrecta");
                }

            }
        }


        //DISMINUCION DE STOCK
        private void btnBajaStock_Click(object sender, EventArgs e)
        {
            txtStkCero.Text = "";
            if ((cbxCombo2.Text == String.Empty || txtCantidad.Text == "0"))
            {
                MessageBox.Show("INGRESE LOS VALORES SOLICITADOS");
            }
            else
            {
                //Baja del stock del articulo
                try
                {
                    EstadoStock = (Op.VerificaStockNegativo(cbxCombo2.Text, int.Parse(txtCantidad.Text)));

                    if (EstadoStock)
                    {
                        MessageBox.Show("Este Movimiento de Stock dejaria el Stock en Negativo");
                    }
                    else
                    {

                        EstadoStock = Op.VerificaStockCero(cbxCombo2.Text, int.Parse(txtCantidad.Text));

                        Stock _stk = new Stock();

                        _stk.Codigo = cbxCombo2.Text;
                        _stk.Cantidad = int.Parse(txtCantidad.Text) * -1;

                        Op.AgregaMovimientoStock(_stk);
                        MostrarEnGrilla(dataGridView2, Op.DevuelveListaStock());
                        MostrarEnGrilla(dataGridView1, Op.DisminuyeStockEnArticulos(_stk.Codigo, _stk.Cantidad * -1));
                    }
                    Total = Op.TotalDinero();
                    textBox1.Text = Total.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        // ORDENAR ARTICULOS POR DESCRIPCION ASCENDENTE
        private void btnLinQ3_Click(object sender, EventArgs e)
        { 
            _Lb.Clear();
            _La = Op.DevuelveListaArticulos();
            _La.Sort(new DescripcionAsc());
            foreach (var A in _La)
            {
                _Lb.Add(A);
            }
            MostrarEnGrilla(dataGridView3, _Lb);

        }


        //ORDENAR ARTICULOS POR DESCRIPCION DESCENDENTE
        private void btnLinQ6_Click(object sender, EventArgs e)
        {
            _Lb.Clear();
            _La = Op.DevuelveListaArticulos();
            _La.Sort(new DescripcionDesc());
            foreach (var A in _La)
            {
                _Lb.Add(A);
            }
            MostrarEnGrilla(dataGridView3, _Lb);


        }


        //FUNCION STOCK CERO
        private void FuncionStockCero(Object sender, EventArgs e)
        {
           txtStkCero.Text = "STOCK CERO";
        }
    }
}
