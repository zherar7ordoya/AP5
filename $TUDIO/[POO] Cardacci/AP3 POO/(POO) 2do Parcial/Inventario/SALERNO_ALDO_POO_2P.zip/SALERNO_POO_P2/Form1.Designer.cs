﻿namespace SALERNO_POO_P2
{
    partial class btnLinQ5
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxCombo1 = new System.Windows.Forms.ComboBox();
            this.btnAlta = new System.Windows.Forms.Button();
            this.btnBaja = new System.Windows.Forms.Button();
            this.btnModificacion = new System.Windows.Forms.Button();
            this.lblArticulo = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.txtCostoUnitario = new System.Windows.Forms.TextBox();
            this.LblCostoUnitario = new System.Windows.Forms.Label();
            this.btnBajaStock = new System.Windows.Forms.Button();
            this.btnAumentaStock = new System.Windows.Forms.Button();
            this.Articulos = new System.Windows.Forms.Label();
            this.lblStock = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.cbxCombo2 = new System.Windows.Forms.ComboBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.lblConsultas = new System.Windows.Forms.Label();
            this.btnLinQ1 = new System.Windows.Forms.Button();
            this.txtStock = new System.Windows.Forms.TextBox();
            this.BtnLinQ2 = new System.Windows.Forms.Button();
            this.btnLinQ3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.txtStock1 = new System.Windows.Forms.TextBox();
            this.txtStock2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLinQ6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtStkCero = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 32);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(845, 157);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 218);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(404, 74);
            this.dataGridView2.TabIndex = 1;
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigo.Location = new System.Drawing.Point(891, 44);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(46, 13);
            this.lblCodigo.TabIndex = 4;
            this.lblCodigo.Text = "Código";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescripcion.Location = new System.Drawing.Point(863, 64);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(74, 13);
            this.lblDescripcion.TabIndex = 5;
            this.lblDescripcion.Text = "Descripcion";
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(942, 61);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(99, 20);
            this.txtDescripcion.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(869, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Tipo Costo";
            // 
            // cbxCombo1
            // 
            this.cbxCombo1.FormattingEnabled = true;
            this.cbxCombo1.Location = new System.Drawing.Point(942, 85);
            this.cbxCombo1.Name = "cbxCombo1";
            this.cbxCombo1.Size = new System.Drawing.Size(99, 21);
            this.cbxCombo1.TabIndex = 11;
            // 
            // btnAlta
            // 
            this.btnAlta.Location = new System.Drawing.Point(942, 117);
            this.btnAlta.Name = "btnAlta";
            this.btnAlta.Size = new System.Drawing.Size(99, 21);
            this.btnAlta.TabIndex = 12;
            this.btnAlta.Text = "Alta";
            this.btnAlta.UseVisualStyleBackColor = true;
            this.btnAlta.Click += new System.EventHandler(this.btnAlta_Click);
            // 
            // btnBaja
            // 
            this.btnBaja.Location = new System.Drawing.Point(942, 143);
            this.btnBaja.Name = "btnBaja";
            this.btnBaja.Size = new System.Drawing.Size(99, 21);
            this.btnBaja.TabIndex = 13;
            this.btnBaja.Text = "Baja";
            this.btnBaja.UseVisualStyleBackColor = true;
            this.btnBaja.Click += new System.EventHandler(this.btnBaja_Click);
            // 
            // btnModificacion
            // 
            this.btnModificacion.Location = new System.Drawing.Point(942, 168);
            this.btnModificacion.Name = "btnModificacion";
            this.btnModificacion.Size = new System.Drawing.Size(99, 21);
            this.btnModificacion.TabIndex = 14;
            this.btnModificacion.Text = "Modificación";
            this.btnModificacion.UseVisualStyleBackColor = true;
            // 
            // lblArticulo
            // 
            this.lblArticulo.AutoSize = true;
            this.lblArticulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArticulo.Location = new System.Drawing.Point(457, 221);
            this.lblArticulo.Name = "lblArticulo";
            this.lblArticulo.Size = new System.Drawing.Size(52, 13);
            this.lblArticulo.TabIndex = 16;
            this.lblArticulo.Text = "Artículo";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidad.Location = new System.Drawing.Point(452, 249);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(57, 13);
            this.lblCantidad.TabIndex = 17;
            this.lblCantidad.Text = "Cantidad";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(512, 246);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(99, 20);
            this.txtCantidad.TabIndex = 18;
            this.txtCantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCostoUnitario
            // 
            this.txtCostoUnitario.Location = new System.Drawing.Point(512, 284);
            this.txtCostoUnitario.Name = "txtCostoUnitario";
            this.txtCostoUnitario.Size = new System.Drawing.Size(99, 20);
            this.txtCostoUnitario.TabIndex = 19;
            this.txtCostoUnitario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblCostoUnitario
            // 
            this.LblCostoUnitario.AutoSize = true;
            this.LblCostoUnitario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCostoUnitario.Location = new System.Drawing.Point(422, 287);
            this.LblCostoUnitario.Name = "LblCostoUnitario";
            this.LblCostoUnitario.Size = new System.Drawing.Size(87, 13);
            this.LblCostoUnitario.TabIndex = 20;
            this.LblCostoUnitario.Text = "Costo Unitario";
            // 
            // btnBajaStock
            // 
            this.btnBajaStock.Location = new System.Drawing.Point(643, 243);
            this.btnBajaStock.Name = "btnBajaStock";
            this.btnBajaStock.Size = new System.Drawing.Size(99, 23);
            this.btnBajaStock.TabIndex = 22;
            this.btnBajaStock.Text = "Disminuir Stock";
            this.btnBajaStock.UseVisualStyleBackColor = true;
            this.btnBajaStock.Click += new System.EventHandler(this.btnBajaStock_Click);
            // 
            // btnAumentaStock
            // 
            this.btnAumentaStock.Location = new System.Drawing.Point(643, 220);
            this.btnAumentaStock.Name = "btnAumentaStock";
            this.btnAumentaStock.Size = new System.Drawing.Size(99, 23);
            this.btnAumentaStock.TabIndex = 21;
            this.btnAumentaStock.Text = "Aumentar Stock";
            this.btnAumentaStock.UseVisualStyleBackColor = true;
            this.btnAumentaStock.Click += new System.EventHandler(this.btnAumentaStock_Click);
            // 
            // Articulos
            // 
            this.Articulos.AutoSize = true;
            this.Articulos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Articulos.Location = new System.Drawing.Point(13, 17);
            this.Articulos.Name = "Articulos";
            this.Articulos.Size = new System.Drawing.Size(69, 13);
            this.Articulos.TabIndex = 24;
            this.Articulos.Text = "ARTICULO";
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStock.Location = new System.Drawing.Point(12, 203);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(48, 13);
            this.lblStock.TabIndex = 25;
            this.lblStock.Text = "STOCK";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(942, 37);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(99, 20);
            this.txtCodigo.TabIndex = 26;
            // 
            // cbxCombo2
            // 
            this.cbxCombo2.FormattingEnabled = true;
            this.cbxCombo2.Location = new System.Drawing.Point(512, 219);
            this.cbxCombo2.Name = "cbxCombo2";
            this.cbxCombo2.Size = new System.Drawing.Size(99, 21);
            this.cbxCombo2.TabIndex = 15;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(16, 338);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(844, 125);
            this.dataGridView3.TabIndex = 27;
            // 
            // lblConsultas
            // 
            this.lblConsultas.AutoSize = true;
            this.lblConsultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsultas.Location = new System.Drawing.Point(12, 322);
            this.lblConsultas.Name = "lblConsultas";
            this.lblConsultas.Size = new System.Drawing.Size(81, 13);
            this.lblConsultas.TabIndex = 28;
            this.lblConsultas.Text = "CONSULTAS";
            // 
            // btnLinQ1
            // 
            this.btnLinQ1.Location = new System.Drawing.Point(12, 482);
            this.btnLinQ1.Name = "btnLinQ1";
            this.btnLinQ1.Size = new System.Drawing.Size(127, 21);
            this.btnLinQ1.TabIndex = 29;
            this.btnLinQ1.Text = "Articulos con stock > a:";
            this.btnLinQ1.UseVisualStyleBackColor = true;
            this.btnLinQ1.Click += new System.EventHandler(this.btnLinQ1_Click_1);
            // 
            // txtStock
            // 
            this.txtStock.Location = new System.Drawing.Point(141, 483);
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(52, 20);
            this.txtStock.TabIndex = 30;
            this.txtStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnLinQ2
            // 
            this.BtnLinQ2.Location = new System.Drawing.Point(210, 483);
            this.BtnLinQ2.Name = "BtnLinQ2";
            this.BtnLinQ2.Size = new System.Drawing.Size(128, 21);
            this.BtnLinQ2.TabIndex = 31;
            this.BtnLinQ2.Text = "Artículos con stock = 0";
            this.BtnLinQ2.UseVisualStyleBackColor = true;
            this.BtnLinQ2.Click += new System.EventHandler(this.BtnLinQ2_Click);
            // 
            // btnLinQ3
            // 
            this.btnLinQ3.Location = new System.Drawing.Point(355, 483);
            this.btnLinQ3.Name = "btnLinQ3";
            this.btnLinQ3.Size = new System.Drawing.Size(243, 21);
            this.btnLinQ3.TabIndex = 32;
            this.btnLinQ3.Text = "Artículos ordenados x Descripcion  Ascendente";
            this.btnLinQ3.UseVisualStyleBackColor = true;
            this.btnLinQ3.Click += new System.EventHandler(this.btnLinQ3_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(15, 516);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(150, 21);
            this.button5.TabIndex = 34;
            this.button5.Text = "Artículos con Stock entre";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.BtnLinQ5_Clic);
            // 
            // txtStock1
            // 
            this.txtStock1.Location = new System.Drawing.Point(171, 516);
            this.txtStock1.Name = "txtStock1";
            this.txtStock1.Size = new System.Drawing.Size(74, 20);
            this.txtStock1.TabIndex = 35;
            this.txtStock1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtStock2
            // 
            this.txtStock2.Location = new System.Drawing.Point(264, 516);
            this.txtStock2.Name = "txtStock2";
            this.txtStock2.Size = new System.Drawing.Size(74, 20);
            this.txtStock2.TabIndex = 36;
            this.txtStock2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(250, 520);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "y";
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(643, 284);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 35);
            this.label3.TabIndex = 38;
            this.label3.Text = "Ingrese Costo Unitario solo cuando Aumente Stock";
            // 
            // btnLinQ6
            // 
            this.btnLinQ6.Location = new System.Drawing.Point(608, 483);
            this.btnLinQ6.Name = "btnLinQ6";
            this.btnLinQ6.Size = new System.Drawing.Size(247, 21);
            this.btnLinQ6.TabIndex = 39;
            this.btnLinQ6.Text = "Artículos ordenados x Descripcion  Descendente";
            this.btnLinQ6.UseVisualStyleBackColor = true;
            this.btnLinQ6.Click += new System.EventHandler(this.btnLinQ6_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(749, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 40;
            // 
            // txtStkCero
            // 
            this.txtStkCero.BackColor = System.Drawing.SystemColors.Control;
            this.txtStkCero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtStkCero.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStkCero.ForeColor = System.Drawing.Color.OrangeRed;
            this.txtStkCero.Location = new System.Drawing.Point(753, 248);
            this.txtStkCero.Name = "txtStkCero";
            this.txtStkCero.ReadOnly = true;
            this.txtStkCero.Size = new System.Drawing.Size(99, 13);
            this.txtStkCero.TabIndex = 41;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(894, 322);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(129, 26);
            this.textBox1.TabIndex = 42;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(891, 274);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 45);
            this.label5.TabIndex = 43;
            this.label5.Text = "Total Dinero Inmovilizado";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLinQ5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1053, 548);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtStkCero);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnLinQ6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtStock2);
            this.Controls.Add(this.txtStock1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnLinQ3);
            this.Controls.Add(this.BtnLinQ2);
            this.Controls.Add(this.txtStock);
            this.Controls.Add(this.btnLinQ1);
            this.Controls.Add(this.lblConsultas);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.lblStock);
            this.Controls.Add(this.Articulos);
            this.Controls.Add(this.btnBajaStock);
            this.Controls.Add(this.btnAumentaStock);
            this.Controls.Add(this.LblCostoUnitario);
            this.Controls.Add(this.txtCostoUnitario);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.lblArticulo);
            this.Controls.Add(this.cbxCombo2);
            this.Controls.Add(this.btnModificacion);
            this.Controls.Add(this.btnBaja);
            this.Controls.Add(this.btnAlta);
            this.Controls.Add(this.cbxCombo1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.lblCodigo);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "btnLinQ5";
            this.Text = "ABM Articulos y Stock";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxCombo1;
        private System.Windows.Forms.Button btnAlta;
        private System.Windows.Forms.Button btnBaja;
        private System.Windows.Forms.Button btnModificacion;
        private System.Windows.Forms.Label lblArticulo;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.TextBox txtCostoUnitario;
        private System.Windows.Forms.Label LblCostoUnitario;
        private System.Windows.Forms.Button btnBajaStock;
        private System.Windows.Forms.Button btnAumentaStock;
        private System.Windows.Forms.Label Articulos;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.ComboBox cbxCombo2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label lblConsultas;
        private System.Windows.Forms.Button btnLinQ1;
        private System.Windows.Forms.TextBox txtStock;
        private System.Windows.Forms.Button BtnLinQ2;
        private System.Windows.Forms.Button btnLinQ3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtStock1;
        private System.Windows.Forms.TextBox txtStock2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLinQ6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtStkCero;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
    }
}

