﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SALERNO_POO_P2
{
    class Operacion
    {
        public event EventHandler StockCero;

        #region Inicializacion
            private List<Articulo> _lArticulos;
            private List<Stock> _lStock;
            bool valor;
            int TotStk;
            double TotValor;
        #endregion

        #region Constructor
            public Operacion()
            {
                _lArticulos = new List<Articulo>();
                _lStock = new List<Stock>();
            }
        #endregion

        //agrega articulo
        public void AgregaArticulo(Articulo pArticulo)
        {
            try
            {
                if (!ArticuloExiste(pArticulo))
                {
                    _lArticulos.Add(pArticulo);
                }
                else { throw new Exception("Articulo Existente"); }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //control de existencia de articulo
        public bool ArticuloExiste(Articulo pArticulo)
        {
            return _lArticulos.Exists(x => x.Codigo == pArticulo.Codigo);
        }

        //devuelve lista de articulos
        public List<Articulo> DevuelveListaArticulos()
        {
            return _lArticulos;
        }

        //devuelve lista de stock
        public List<Stock> DevuelveListaStock()
        {
            return _lStock;
        }

        //Agrego lineas al stock
        public void AgregaMovimientoStock(Stock pStock)
        {
            try
            {
                _lStock.Add(pStock);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //Busca un articulo y devuelvo tipo de costo
        public string BuscoArticuloTipoCosto(string A)
        {
            Articulo _A = new Articulo();
            _A = _lArticulos.Find(x => x.Codigo == A);
            return _A.TipoCosto;
        }

        //Busca un articulo y devuelvo tipo de costo
        public string BuscoArticulo(string A)
        {
            Articulo _A = new Articulo();
            _A = _lArticulos.Find(x => x.Codigo == A);
            MessageBox.Show(_A.Codigo + ' ' + _A.TipoCosto);
            return _A.TipoCosto;
        }

        //Actualizo stock y costo de ARTICULOS
        public List<Articulo> AumentaStockEnArticulos(string Id, Double C, String T, int S)
        {
            List<Articulo> _lArticuloNew = new List<Articulo>();

            foreach (Articulo A in _lArticulos)
            {
                if (A.TipoCosto == T && A.Codigo==Id)
                {
                    A.Costo = C;
                    A.Stock += S;
                }
                _lArticuloNew.Add(A);

            }
           
            return _lArticuloNew;
        }

        //Disminuyo stock en ARTICULOS
        public List<Articulo>DisminuyeStockEnArticulos(string Id, int S)
            {
                List<Articulo> _lArticuloNew = new List<Articulo>();

                foreach (Articulo A in _lArticulos)
                {
                    if ( A.Codigo == Id)
                    {
                        A.Stock -= S;
                    }
                    _lArticuloNew.Add(A);
                }

                return _lArticuloNew;
            }

        //Verifico Stock en Negativo
        public Boolean VerificaStockNegativo(string Id, int S)
        {
            List<Articulo> _lArticuloNew = new List<Articulo>();
            
            valor = false;
            foreach (Articulo A in _lArticulos)
            {
                if (A.Codigo == Id)
                {
                    if (A.Stock - S < 0)
                    {
                        valor = true;
                    }
                }
            }
            return valor;
        }

        //Verifico Stock en Cero
        public Boolean VerificaStockCero(string Id, int S)
        {
            valor = false;
            foreach (Articulo A in _lArticulos)
            {
                if (A.Codigo == Id)
                {
                    if (A.Stock - S == 0)
                    {
                        valor = true;
                        StockCero(this, null);
                    }
                }
            }
            return valor;
        }

        //Totalizo Dinero en Stock
        public double TotalDinero()
        {
            List<Articulo> _lArticuloNew = new List<Articulo>();
            TotStk = 0;
            TotValor = 0;
            foreach (Articulo A in _lArticulos)
            {
                TotStk += A.Stock;
                TotValor += A.Costo;
                
            }
            return TotStk * TotValor;
        }

    }

}
            


