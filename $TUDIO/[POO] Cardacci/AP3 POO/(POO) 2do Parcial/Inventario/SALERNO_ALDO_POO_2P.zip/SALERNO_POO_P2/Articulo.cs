﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SALERNO_POO_P2
{

    #region CLASE ARTICULO
        public class Articulo
        {
            #region CONSTRUCTORES
                public Articulo() {}

                public Articulo(string codigo, string descripcion, DateTime fechaAlta, int stock, string tipoCosto)
                {
                    Codigo = codigo;
                    Descripcion = descripcion;
                    FechaAlta = fechaAlta;
                    Stock = stock;
                    TipoCosto = tipoCosto;
                }
            #endregion

            #region PROPIEDADES
                public string Codigo { get; set; }
                public string Descripcion { get; set; }
                public DateTime FechaAlta { get; set; }
                public DateTime FechaBaja { get; set; }
                public String MesesVigentes { get; set; }
                public double Costo { get; set; }
                public string TipoCosto { get; set; }
                public int Stock { get; set; }
            #endregion
        }
    #endregion

    #region CLASES ORDENACION
        public class DescripcionAsc : IComparer<Articulo>
        {
            public int Compare(Articulo x, Articulo y)
            {
                return string.Compare(x.Descripcion, y.Descripcion);
            }
        }

        public class DescripcionDesc : IComparer<Articulo>
        {
            public int Compare(Articulo x, Articulo y)
            {
                return string.Compare(x.Descripcion, y.Descripcion) * -1;
            }
        }
    #endregion

    #region CLASE STOCK
      public class Stock
    {
        private List<Stock> ListaStock;
        public string Codigo { get; set; }
        public int Cantidad { get; set; }
        public double CostoUnitario { get; set; }

        public Stock()
        {
            ListaStock = new List<Stock>();
        }
       
        public Stock(string pCodigo, int pCantidad, double pCostoUnitario)
        {
            Codigo = pCodigo;
            Cantidad = pCantidad;
            CostoUnitario = pCostoUnitario;
        }
    }
    #endregion

    #region CLASES COSTO
        public abstract class Costo
        {
            public char Codigo { get; set; }
            public abstract void TipoCosto();
        }

        public class CostoCPP : Costo 
        {
            public override void TipoCosto()
            { 
             // a desarrollar
            }
        }

        public class CostoCUE : Costo
        {
            public override void TipoCosto()
            {
              // a desarrollar
            }

            public double ValorCue { get; set; }
            public int ValorStock { get; set; }


        }

        public class CostoCP : Costo
        {
            public override void TipoCosto()
            {
                // a desarrollar
            }
        }

    #endregion

}
