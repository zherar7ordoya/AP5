﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PROVENZANO_POO_P2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Empresa miEmpresa;
        VistaArticulo VA;
        VistaArticulo VAconsultas;  // para no dejar sin lista vista al dgv1 tengo otro objeto "VistaArticulo"

        private void Form1_Load(object sender, EventArgs e)
        {
            ConfigurarDGV(dgv);
            ConfigurarDGV(dgv2);

            cmbCosto.SelectedIndex = 0;

            miEmpresa = new Empresa();
            VA = new VistaArticulo();
            VAconsultas = new VistaArticulo();
        }

        #region ABM
        private void BtnAlta_Click(object sender, EventArgs e)
        {
            try
            {
                // verifico que hayan datos ingresados
                if (txtCodigo.Text != "" && txtDesc.Text != "")
                {
                    Articulo A = new Articulo(txtCodigo.Text, txtDesc.Text, cmbCosto.SelectedIndex);
                    miEmpresa.Alta(A);
                    
                    // suscripcion al evento
                    A.StockZero += Articulo_StockZero;

                    Mostrar(dgv, miEmpresa.DevuelveLista(), VA);
                }
                else
                    throw new Exception("Llenar todos los campos correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BtnBaja_Click(object sender, EventArgs e)
        {
            try
            {
                VistaArticulo seleccionado = null;
                try
                {
                    seleccionado = (VistaArticulo)dgv.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos para borrar.");
                }

                // la baja hace una simulacion del paso del tiempo, el usuario selecciona una fecha
                // y se considera que el articulo ya no se esta comercializando mas
                // en ese momento se le asigna la fecha de baja que el usuario selecciono
                miEmpresa.Baja(seleccionado, dateTimePicker1.Value);
                txtTotal.Text = miEmpresa.CalcularTotalStock();
                Mostrar(dgv, miEmpresa.DevuelveLista(), VA);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                VistaArticulo seleccionado = null;
                try
                {
                    seleccionado = (VistaArticulo)dgv.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos para modificar.");
                }

                if (txtDesc.Text != "")
                {
                    seleccionado.Descripcion = txtDesc.Text;

                    miEmpresa.Modificar(seleccionado);
                    Mostrar(dgv, miEmpresa.DevuelveLista(), VA);
                }
                else
                    throw new Exception("Llenar los campos correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion ABM

        #region METODOS STOCK
        private void BtnAgregarStock_Click(object sender, EventArgs e)
        {
            try
            {
                // primero reviso que haya un articulo seleccionado
                VistaArticulo seleccionado = null;
                try
                {
                    seleccionado = (VistaArticulo)dgv.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos para seleccionar.");
                }

                // pido datos al usuario
                decimal costo = decimal.Parse(Interaction.InputBox("Costo unitario de los articulos:"));
                int cantidad = int.Parse(Interaction.InputBox("Cantidad:"));

                // si los datos son correctos llamo al metodo de miEmpresa para que aumente el stock
                if (costo > 0 && cantidad > 0)
                    miEmpresa.AgregarStock(seleccionado, costo, cantidad);
                else
                    throw new Exception("Los valores introducidos deben ser mayores a 0.");

                txtTotal.Text = miEmpresa.CalcularTotalStock();
                Mostrar(dgv, miEmpresa.DevuelveLista(), VA);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void BtnDisminuirStock_Click(object sender, EventArgs e)
        {
            try
            {
                VistaArticulo seleccionado = null;
                try
                {
                    seleccionado = (VistaArticulo)dgv.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos para seleccionar.");
                }

                int cantidad = int.Parse(Interaction.InputBox("Cantidad:"));

                if (cantidad > 0)
                    miEmpresa.DisminuirStock(seleccionado, cantidad);
                else
                    throw new Exception("Los valores introducidos deben ser mayores a 0.");

                txtTotal.Text = miEmpresa.CalcularTotalStock();
                Mostrar(dgv, miEmpresa.DevuelveLista(), VA);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // evento que se ejecuta cuando se desencadena el evento StockZero
        private void Articulo_StockZero(object sender, StockZeroEventArgs e)
        {
            MessageBox.Show($"El stock del articulo {e.Codigo}, {e.Descripcion}, ha llegado a 0.");
        }
        #endregion METODOS STOCK

        #region METODOS CONSULTAS
        private void BtnA_Click(object sender, EventArgs e)
        {
            try
            {
                int valor = int.Parse(Interaction.InputBox("Ingrese un valor:"));

                if (valor >= 0)
                {
                    // a Mostrar() le paso la lista que me devuelve la consulta linQ
                    // esa lista va a pasar por la clase vista y se va a mostrar en el dgv2
                    Mostrar(dgv2, miEmpresa.ProductosMayorAValor(valor), VAconsultas);
                }
                else
                    throw new Exception("El valor no puede ser menor a 0.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnB_Click(object sender, EventArgs e)
        {
            try
            {
                // paso el resultado de la consulta a una clase vista especial que solo muestra la descripcion
                VistaArticuloStockCero VAstock = new VistaArticuloStockCero();
                dgv2.DataSource = null;
                dgv2.DataSource = VAstock.DevuelveListaVista(miEmpresa.StockCero());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCasc_Click(object sender, EventArgs e)
        {
            try
            {
                Mostrar(dgv2, miEmpresa.DescripcionAscendente(), VAconsultas);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BtnCdesc_Click(object sender, EventArgs e)
        {
            try
            {
                Mostrar(dgv2, miEmpresa.DescripcionDescendente(), VAconsultas);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BtnD_Click(object sender, EventArgs e)
        {
            try
            {
                Mostrar(dgv2, miEmpresa.OrdenMeses(), VAconsultas);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnE_Click(object sender, EventArgs e)
        {
            try
            {
                // pido los valores y los valido
                int n1 = int.Parse(Interaction.InputBox("Ingrese un valor:"));
                int n2 = int.Parse(Interaction.InputBox("Ingrese un valor:"));

                if (n1 >= 0 && n2 >= 0 && n2 > n1)
                {
                    Mostrar(dgv2, miEmpresa.StockEntreValores(n1, n2), VAconsultas);
                }
                else
                    throw new Exception("El primer valor no debe ser mayor al segundo y ningún valor puede ser " +
                        "menor a 0");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion METODOS CONSULTAS

        #region METODOS VARIOS
        private void ConfigurarDGV(DataGridView DGV)
        {
            DGV.MultiSelect = false;
            DGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGV.DataSource = null;
            DGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells; // celdas autoajustables
        }

        private void Mostrar(DataGridView DGV, List<Articulo> lista, VistaArticulo vista)
        {
            DGV.DataSource = null;
            DGV.DataSource = vista.DevuelveListaVista(lista);

            txtCodigo.Text = "";
            txtDesc.Text = "";
            cmbCosto.SelectedIndex = 0;
        }

        private void Dgv_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                VistaArticulo seleccionado = (VistaArticulo)dgv.SelectedRows[0].DataBoundItem;

                txtCodigo.Text = seleccionado.Codigo;
                txtDesc.Text = seleccionado.Descripcion;
            }
            catch (Exception) { }
        }
        #endregion METODOS VARIOS
    }
}
