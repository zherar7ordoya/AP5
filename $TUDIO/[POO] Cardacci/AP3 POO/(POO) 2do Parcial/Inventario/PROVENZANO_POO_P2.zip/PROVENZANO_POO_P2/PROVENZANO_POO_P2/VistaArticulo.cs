﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    class VistaArticulo
    {
        List<VistaArticulo> listaVista;
        public VistaArticulo()
        {
            listaVista = new List<VistaArticulo>();
        }
        public VistaArticulo(string cod, string desc, DateTime alta, string baja, string vig, 
            string metodo, string costo, int stock)
        {
            Codigo = cod;
            Descripcion = desc;
            FechaAlta = alta.ToShortDateString();
            FechaBaja = baja;
            MesesVigentes = vig;
            MetodoCosto = metodo;
            Costo = costo;
            Stock = stock;
        }

        #region PROPIEDADES
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string FechaAlta { get; set; }
        public string FechaBaja { get; set; }
        public string MesesVigentes { get; set; }
        public string Costo { get; set; }   // se guarda en string para poder darle el formato deseado de salida
        public string MetodoCosto { get; set; }
        public int Stock { get; set; }
        #endregion PROPIEDADES

        public List<VistaArticulo> DevuelveListaVista(List<Articulo> lista)
        {
            listaVista.Clear();

            foreach(Articulo A in lista)
            {
                listaVista.Add(new VistaArticulo(A.Codigo, A.Descripcion, A.FechaAlta, A.FechaBaja,
                        A.MesesVigencia, A.Calculo.Descripcion, string.Format("{0:0.00}",A.Costo), A.Stock));
            }

            return listaVista;
        }
    }
}
