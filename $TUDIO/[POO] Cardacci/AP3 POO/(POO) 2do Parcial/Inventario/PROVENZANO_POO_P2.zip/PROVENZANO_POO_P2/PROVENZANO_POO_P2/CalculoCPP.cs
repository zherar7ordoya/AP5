﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    class CalculoCPP : CalculoCosto
    {
        decimal CPP;  // guarda el CPP actual  
        public CalculoCPP()
        {
            ID = 1;
            Descripcion = "Costo Promedio Ponderado";

            CPP = 0; // primero esta en 0 porque no se hicieron movimientos de stock
        }

        // CPP: costo promedio ponderado actual
        // STA: stock actual del articulo
        // CUA: costo unitario de los articulos que ingresan al stock
        // QA: cantidad de articulos adquiridos
        public override decimal CalcularCosto(int STA, decimal CUA, int QA)
        {
            CPP = ((CPP * STA) + (CUA * QA)) / (STA + QA);

            return CPP;
        }
    }
}
