﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    // clase empresa que maneja los ABM de los articulos
    class Empresa
    {
        List<Articulo> articulos;
        List<Articulo> aux; // lista auxiliar para las consultas
        decimal total;

        public Empresa()
        {
            articulos = new List<Articulo>();
            aux = new List<Articulo>();
        }

        #region ABM
        public void Alta(Articulo A)
        {
            // reviso que el articulo no exista
            if (!(articulos.Exists(x => x.Codigo == A.Codigo)))
            {
                articulos.Add(A);
            }
            else
                throw new Exception("El articulo ya existe.");
        }

        public void Baja(VistaArticulo A, DateTime fecha)
        {
            Articulo aux = articulos.Find(x => x.Codigo == A.Codigo);

            // si esta vigente le asigno la fecha de baja y le pongo la vigencia en falso
            if (aux.Vigente)
            {
                if (fecha > aux.FechaAlta)
                {
                    // asigno la fecha de baja
                    aux.FechaBaja = fecha.ToShortDateString();

                    // calculo la vigencia
                    // obtengo la diferencia en años y lo multiplico por 12 para que me de el total de meses
                    int dif = (fecha.Year - aux.FechaAlta.Year) * 12;
                    // obtengo la diferencia de meses y se la sumo a la diferencia de años
                    aux.MesesVigencia = (dif + (fecha.Month - aux.FechaAlta.Month)).ToString();

                    aux.Vigente = false;
                }
                else
                    throw new Exception("La fecha de baja debe ser mayor a la fecha de alta");
            }
            else    // si no esta vigente, lo elimino
            {
                articulos.Remove(aux);
            }
        }

        public void Modificar(VistaArticulo A)
        {
            Articulo aux = articulos.Find(x => x.Codigo == A.Codigo);

            // verifico si esta vigente, si no lo esta no se puede modificar
            if (aux.Vigente)
            {
                aux.Descripcion = A.Descripcion;
            }
            else
                throw new NoVigenteException(aux.Codigo);
        }
        #endregion ABM

        #region METODOS STOCK
        public void AgregarStock(VistaArticulo A, decimal costoUnitario, int cantidad)
        {
            // primero busco el objeto original con el Find
            Articulo aux = articulos.Find(x => x.Codigo == A.Codigo);

            if (aux.Vigente)
            {
                // primero llamo al metodo que calcula el costo
                aux.Costo = aux.Calculo.CalcularCosto(aux.Stock, costoUnitario, cantidad);
                aux.Stock += cantidad;
            }
            else
                throw new NoVigenteException(aux.Codigo);
        }

        public void DisminuirStock(VistaArticulo A, int cantidad)
        {
            // primero busco el objeto original con el Find
            Articulo aux = articulos.Find(x => x.Codigo == A.Codigo);

            if (aux.Vigente)
            {
                if (aux.Stock > 0)
                    aux.Stock -= cantidad;
                else
                    throw new Exception("Stock en 0, no es posible completar la operación.");
            }
            else
                throw new NoVigenteException(aux.Codigo);
        }

        public string CalcularTotalStock()  // lo devuelvo como string para darle formato
        {
            total = 0;  // porque se pueden realizar varias llamadas al metodo

            foreach (Articulo a in articulos)
            {
                total += a.Costo * a.Stock;
            }

            return string.Format("{0:0.00}", total);
        }
        #endregion METODOS STOCK

        #region METODOS CONSULTAS
        // punto A: retorna lista de articulos de stock superior a valor ingresado
        public List<Articulo> ProductosMayorAValor(int valor)
        {
            var consulta = from a in articulos      // para cada articulo de la lista
                           where a.Stock > valor    // busco los que tienen stock mayor al valor ingresado
                           select a;                // y los proyecto para afuera

            return ConsumirConsulta(consulta);      // mando a consumir la consulta y devuelvo la lista que me da
        }

        // punto B: retorna lista de articulos con stock 0
        public List<Articulo> StockCero()
        {
            var consulta = from a in articulos
                           where a.Stock == 0
                           select a;

            return ConsumirConsulta(consulta);
        }

        // punto C: ordena alfabeticamente por descripcion de forma ascendente
        public List<Articulo> DescripcionAscendente()
        {
            // clono la lista, asi la lista original mantiene su orden
            ClonarLista();

            aux.Sort(new Articulo.ComparadorAsc());

            return aux;
        }

        // punto C: ordena alfabeticamente por descripcion de forma descendente
        public List<Articulo> DescripcionDescendente()
        {
            ClonarLista();

            aux.Sort(new Articulo.ComparadorDesc());

            return aux;
        }

        // punto D: mostrar los articulos con fecha de baja, ordenados de mayor a menor por meses de vigencia
        public List<Articulo> OrdenMeses()
        {
            // selecciono los articulos que tienen fecha de baja
            var consulta = from a in articulos
                           where a.FechaBaja != "--"
                           select a;

            // luego de consumir la consulta, la ordeno y la devuelvo
            aux = ConsumirConsulta(consulta);
            aux.Sort(new Articulo.ComparadorMeses());
            return aux;
        }

        // punto E: articulos con stock entre los valores n1 y n2 ingresados por el usuario
        public List<Articulo> StockEntreValores(int n1, int n2)
        {
            // recorre articulos y busca los que tienen el stock entre los numeros indicados
            var consulta = articulos.Where(x => x.Stock > n1 && x.Stock < n2);

            return ConsumirConsulta(consulta);
        }

        private List<Articulo> ConsumirConsulta(IEnumerable<Articulo> consulta)
        {
            aux.Clear();    // limpio la lista porque se pueden hacer muchos llamados al metodo

            foreach (Articulo A in consulta)    // consumo la consulta
            {
                // devuelvo el articulo clonado sin tocar el original
                aux.Add((Articulo)A.Clone());
            }

            // verifico que la lista no este vacia, la excepcion burbujea para el form
            if (aux.Count == 0)
                throw new Exception("No hay ningun articulo que cumpla con lo requerido.");

            return aux;
        }

        private void ClonarLista()
        {
            aux.Clear();

            foreach (Articulo A in articulos)
            {
                aux.Add((Articulo)A.Clone());
            }
        }
        #endregion METODOS CONSULTAS

        public List<Articulo> DevuelveLista()
        {
            return articulos;
        }
    }
}
