﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    class Articulo : ICloneable
    {
        string codigo;
        int stock;
        CalculoCosto calculo;

        // declaracion de evento para cuando un articulo se queda sin stock
        public event EventHandler<StockZeroEventArgs> StockZero;

        public Articulo(string cod, string desc, int metodoCalculo)
        {
            Codigo = cod;
            Descripcion = desc;
            Costo = 0;
            stock = 0;
            FechaAlta = DateTime.Today;
            FechaBaja = "--";
            MesesVigencia = "--";
            Vigente = true;

            // la forma de calculo es parte del articulo, se crea cuando el objeto se instancia
            switch(metodoCalculo)
            {
                case 0: // CPP
                    calculo = new CalculoCPP();
                    break;
                case 1: // CUE
                    calculo = new CalculoCUE();
                    break;
                case 2: // CP
                    calculo = new CalculoCP();
                    break;
            }
        }

        #region PROPIEDADES
        public string Codigo // 1 letra mayuscula y 5 digitos
        {
            get { return codigo; }
            set
            {
                // esta expresion significa que desde el comienzo hasta el final, el string debe poseer
                // una letra mayuscula que puede ir de la A a la Z, y 5 numeros que pueden ir del 0 al 9
                string expresion = @"\A[A-Z][0-9]{5}\Z";

                // si el valor es igual a la expresion regular, el formato esta bien
                if (Regex.IsMatch(value, expresion))    
                {
                    codigo = value;
                }
                else
                    throw new Exception("Formato de codigo incorrecto.");
            }
        }
        public string Descripcion { get; set; }
        public decimal Costo { get; set; }
        public int Stock
        {
            get { return stock; }
            set
            {
                stock = value;

                if(stock <= 0)
                {
                    // para que no quede un stock negativo
                    stock = 0;
                    // desencadenamiento
                    StockZero?.Invoke(this, new StockZeroEventArgs(this.codigo, this.Descripcion)); 
                }
            }
        }
        public DateTime FechaAlta { get; set; }
        public string FechaBaja { get; set; }   // es string porque si no hay fecha de baja va un "--"
        public string MesesVigencia { get; set; }   // lo mismo que FechaBaja
        public bool Vigente { get; set; }   // para verificar si se dejo de comercializar o no
        public CalculoCosto Calculo
        {
            get { return calculo; }
            set { calculo = value; }
        }
        #endregion PROPIEDADES

        // metodo de ICloneable
        public object Clone()
        {
            return this.MemberwiseClone();
        }

        #region ICOMPARER
        // comparadores anidados en Articulo que tienen diferentes criterios para comparar un Articulo con otro
        public class ComparadorAsc : IComparer<Articulo>
        {
            public int Compare(Articulo x, Articulo y)
            {
                return x.Descripcion.CompareTo(y.Descripcion);
            }
        }
        public class ComparadorDesc : IComparer<Articulo>
        {
            public int Compare(Articulo x, Articulo y)
            {
                return (x.Descripcion.CompareTo(y.Descripcion)) * -1;
            }
        }
        public class ComparadorMeses : IComparer<Articulo>
        {
            public int Compare(Articulo x, Articulo y)
            {
                return int.Parse(y.MesesVigencia) - int.Parse(x.MesesVigencia);
            }
        }
        #endregion ICOMPARER
    }
}
