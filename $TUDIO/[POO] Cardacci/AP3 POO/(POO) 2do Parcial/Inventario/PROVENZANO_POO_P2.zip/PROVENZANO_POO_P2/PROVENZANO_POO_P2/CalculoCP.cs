﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    class CalculoCP : CalculoCosto
    {
        decimal CP; // guarda el CP actual 

        public CalculoCP()
        {
            ID = 2;
            Descripcion = "Costo Personalizado";
            CP = 0; // primero esta en 0 porque no se hicieron movimientos de stock
        }

        // CP = Costo personalizado actual del artículo.
        // CA = Costo del artículo adquirido que ingresa al stock.
        public override decimal CalcularCosto(int stock, decimal CA, int cantidad)
        {
            CP = ((CP + CA) / 2m) * 1.1m;
            return CP;
        }
    }
}
