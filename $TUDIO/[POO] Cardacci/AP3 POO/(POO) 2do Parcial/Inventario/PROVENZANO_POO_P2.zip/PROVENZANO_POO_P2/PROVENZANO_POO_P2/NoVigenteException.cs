﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    // excepcion personalizada para cuando un articulo ya no se encuentra vigente
    class NoVigenteException : Exception
    {
        // recibe el codigo del articulo que causo la excepcion
        public NoVigenteException(string cod)
        {
            Codigo = cod;
        }

        public string Codigo { get; set; }

        public override string Message => $"El producto {Codigo} no se encuentra vigente actualmente";
    }
}
