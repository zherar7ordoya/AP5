﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    // clase abstracta de la que heredan los tipos de calculo
    abstract class CalculoCosto
    {
        public int ID { get; set; }
        public string Descripcion { get; set; }
        
        // metodo abstracto para sobreescribir con cada tipo de calculo, asi cualquier articulo puede acceder
        // a el y hacer lo que necesita mediante polimorfismo
        public abstract decimal CalcularCosto(int stock, decimal costoUnitario, int cantidad);
    }
}
