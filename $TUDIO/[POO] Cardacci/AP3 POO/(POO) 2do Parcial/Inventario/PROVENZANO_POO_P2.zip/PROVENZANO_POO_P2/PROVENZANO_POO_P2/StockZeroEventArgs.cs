﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    // clase EventArgs para el evento, tiene la informacion que necesita el evento
    public class StockZeroEventArgs : EventArgs
    {
        public StockZeroEventArgs(string cod, string desc)
        {
            Codigo = cod;
            Descripcion = desc;
        }

        public string Codigo { get; set; }
        public string Descripcion { get; set; }
    }
}
