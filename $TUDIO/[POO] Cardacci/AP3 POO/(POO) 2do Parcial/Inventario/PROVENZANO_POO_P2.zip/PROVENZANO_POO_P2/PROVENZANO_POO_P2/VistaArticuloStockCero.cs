﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    // clase vista especial para mostrar solo la descripcion de los articulos
    class VistaArticuloStockCero
    {
        List<VistaArticuloStockCero> listaVista;

        public VistaArticuloStockCero()
        {
            listaVista = new List<VistaArticuloStockCero>();
        }
        public VistaArticuloStockCero(string desc)
        {
            Descripcion = desc;
        }

        public string Descripcion { get; set; }

        // devuelvo la lista vista solo con la descripcion del articulo, segun pide el enunciado
        public List<VistaArticuloStockCero> DevuelveListaVista(List<Articulo> lista)
        {
            listaVista.Clear();

            foreach(Articulo A in lista)
            {
                listaVista.Add(new VistaArticuloStockCero(A.Descripcion));
            }

            return listaVista;
        }
    }
}
