﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROVENZANO_POO_P2
{
    class CalculoCUE : CalculoCosto
    {
        public CalculoCUE()
        {
            ID = 3;
            Descripcion = "Costo Ultimo Entrado";
        }
        public override decimal CalcularCosto(int stock, decimal costoUnitario, int cantidad)
        {
            return costoUnitario;
        }
    }
}
