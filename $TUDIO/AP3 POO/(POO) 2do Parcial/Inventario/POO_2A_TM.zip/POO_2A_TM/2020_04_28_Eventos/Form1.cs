﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    // El formulario es el SUSCRIPTORA
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Caldera _c;
        private void Form1_Load(object sender, EventArgs e)
        {
            _c = new Caldera();
            // Suscripciones
            _c.TemperaturaElevada += new EventHandler<TemperaturaEventArgs>(Peligro);
            _c.TemperaturaAdecuada += new EventHandler(Normal);
        }
        //Se establece que se hace cuando se desencadena el evento TemperaturaElevada
        private void Peligro(object sender, TemperaturaEventArgs e)
        {
            
            textBox1.BackColor = Color.Red;
            textBox1.Text = e.TemperaturaActual.ToString();
        }
        //Se establece que se hace cuando se desencadena el evento TemperaturaNormal
        private void Normal(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.Green;
            textBox1.Text = hScrollBar1.Value.ToString();
        }
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            _c.Temperatura = hScrollBar1.Value;
        }
    }
   
    // La clase Caldera es la PUBLICADORA del evento TemperaturaElevada
    public class Caldera
    {    
        // Definición del evento TemperaturaElevada
        // Usamos el manejador de eventos estandar EventHandler
        public event EventHandler<TemperaturaEventArgs> TemperaturaElevada ;
        public event EventHandler TemperaturaAdecuada;
        private int _temperatura;

        public int Temperatura
        {
            get { return _temperatura; }
            set
            { 
                _temperatura = value;
                // Se establece cuándo se va a desencadenar el evento.
                // Si la evaluación es true, se procese al desencadenamiento.
                // Tabién nos aseguramos de solo desencadenar el evento si posee suscriptoresif (!(TemperaturaElevada is null))
                //--> if (Temperatura > 100) { if (!(TemperaturaElevada is null)) { TemperaturaElevada(this,new EventArgs()); }  }
                if (Temperatura > 100)
                { TemperaturaElevada?.Invoke(this, new TemperaturaEventArgs(Temperatura)); }
                else
                { TemperaturaAdecuada?.Invoke(this, new EventArgs()); }
            }
        }

    }

    // Esta clase es la que utilizamos para construir el ARGUMENTO DE EVENTO PERSONALIZADO
    public class TemperaturaEventArgs : EventArgs
    { 
        private int _temperatura;
        public TemperaturaEventArgs(int pTemperatura) { _temperatura = pTemperatura; }
        public int TemperaturaActual { get { return _temperatura; } }
    }

   

}
