﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2020_06_09_IComparable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Genero una lista
            List<Persona> _p = new List<Persona>() {new Persona("Juan","Perez",24),
                             new Persona("Ana","Martinez",22),
                             new Persona("Maria","Fernandez",29)};

            // Clono la lista
            List<Persona> _pAux = new List<Persona>();
            foreach (Persona _xp in _p) { _pAux.Add(new Persona(_xp.Nombre,_xp.Apellido,_xp.Edad)); }
            
            // Muestro la lista clonada sin ordenar
            dataGridView1.DataSource = null;dataGridView1.DataSource = _pAux;
            // Ordeno la lista
            _p.Sort();
            // Muestro la lista ordenada
            dataGridView2.DataSource = null; dataGridView2.DataSource = _p;
        }
    }

    public class Persona :  IComparable<Persona>
    {
        public Persona(string pNombre,string pApellido,int pEdad) {Nombre=pNombre;Apellido=pApellido;Edad=pEdad; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }

        public int CompareTo(Persona other)
        {
            // return String.Compare(this.Apellido,other.Apellido);
            return this.Edad < other.Edad ? -1 : (this.Edad == other.Edad ? 0 : 1);
        }
    }


}
