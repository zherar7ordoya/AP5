﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2020_04_21_ContructoresDestructores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { }
        private void Mostrar(Persona.Alumno pA)
        { 
          MessageBox.Show($"El objeto A1 tiene:\n\nLegajo: {pA.Legajo.ToString()}\nNombre: {pA.Nombre}\nApellido: {pA.Apellido}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Instancias de Profesor
            Profesor P1 = new Profesor(1);
            Profesor P2 = new Profesor(2);
            Profesor P3 = new Profesor(3);

            //Se cambia la propiedad Valor que es una propiedad de clase (static, ver la clase Profesor).
            //Es por ello que se hace desde el nombre de la clase y no desde la variable que apunta al objeto.
            Profesor.Valor = 200;

            MessageBox.Show($"En P1 valor= {Profesor.Valor}\n" +
                            $"En P2 valor= {Profesor.Valor}\n" +
                            $"En P3 valor= {Profesor.Valor}\n");

            //Se apuntan las variables a null para que los objetos queden como basura en la memoria
            //Esto causará que se ejecuten los destructores cuando el Garbage Collector recolecte la
            //basura para liberar memoria
            P1 = null;P2 = null;P3 = null;
            //Se fuerza la recolección de basura para que se ejecuten los destructores
            GC.Collect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Distintas instancias de Alumno que utilizan distintos constructores (sobrecarga de constructores en)
            //la clase Alumno
            Persona.Alumno A1 = new Persona.Alumno();
            Persona.Alumno A2 = new Persona.Alumno(Interaction.InputBox("Nombre: "));
            Persona.Alumno A3 = new Persona.Alumno(Interaction.InputBox("Nombre: "), Interaction.InputBox("Apellido: "));
            Mostrar(A1); Mostrar(A2); Mostrar(A3);
        }
    }

    public abstract class Persona
    {
        //Constructor de Persona
        public Persona(int pLegajo) => Legajo = pLegajo;
        //Propiedad de la clase Persona
        public int Legajo { get; set; }
        // Alumno y profesor son clases anidadas
        public class Alumno : Persona
        {
            // Constructor de la clase Alumno que como buena práctica llama con ´base´ al constructor de
            // la super clase Persona.
            public Alumno() : base(int.Parse(Interaction.InputBox("Legajo: ")))
            {
                MessageBox.Show("Se ejecutó el constructor de Alumno");
            }
            //Constructor de la clase alumno que constituye por un lado la sobrecarga del mismo y por buena
            //práctica de programación llama al constructor de la clase base o superclase.
            public Alumno(string pNombre) : base(int.Parse(Interaction.InputBox("Legajo: ")))
            {
                Nombre = pNombre;
            }
            //Constructor de la clase alumno que constituye por un lado la sobrecarga del mismo y por buena
            //práctica de programación llama al constructor con la firma Alumno(string pNombre) para reutilizar
            //el código de asignación del Nombre a la propiedad correspondiente.
            public Alumno(string pNombre, string pApellido) : this(pNombre)
            {
                Apellido = pApellido;                
            }
            //Propiedades Nombre y Apellido
            public string Nombre { get; set; }
            public string Apellido { get; set; }
        }
      
    }
    public class Profesor
    {
   
        //Propiedad de Clase
        public static int Valor { get; set; }
        //Propiedad de Instancia
        public int Legajo { get; set; }
        //Constructor de Clase
        static Profesor()
        {
            MessageBox.Show("Se ejecutó el constructor estático de Profesor");
            Valor = 100;
        }
        //Constructor de Instancia
        public Profesor(int pLegajo) 
        {
            Legajo = pLegajo;
            MessageBox.Show($"Se ejecutó el constructor de instancia de Profesor\n\n" +
                            $"La propiedad valor es igual a: {Valor}\n\n");
        }
        //Destructor de la clase Profesor
        ~Profesor() { MessageBox.Show($"Se ejecutó el destructor de Profesor: P{this.Legajo.ToString()}"); }
    }
}
