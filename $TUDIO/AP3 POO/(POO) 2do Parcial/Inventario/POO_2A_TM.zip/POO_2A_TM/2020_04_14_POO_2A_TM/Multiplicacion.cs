﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2020_04_14_POO_2A_TM
{
    public class Multiplicacion : Operacion
    {
        public override decimal Ejecutar()
        {
            return Numero1 * Numero2;
        }

    }
}
