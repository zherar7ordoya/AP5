﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2020_04_14_POO_2A_TM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Suma S;
        Resta R;
        Multiplicacion M;
        private void Form1_Load(object sender, EventArgs e)
        {
            S = new Suma();
            R = new Resta();
            M = new Multiplicacion();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {SolicitarNumeros(S); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }

        private void SolicitarNumeros(Operacion O)
        {
            O.Numero1 = decimal.Parse(Interaction.InputBox("Ingrese el primer número:"));
            O.Numero2 = decimal.Parse(Interaction.InputBox("Ingrese el segundo número:"));
            FuncionEjecutar(O);
        }

        private void FuncionEjecutar(Operacion O)
        {
            MessageBox.Show(O.Ejecutar().ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try {SolicitarNumeros(R);}
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try { SolicitarNumeros(M); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
      
    }

    public abstract class Operacion
    {
        public decimal Numero1 { get; set; }
        public decimal Numero2 { get; set; }

        public abstract decimal Ejecutar();
       
       
    }

    public class Suma : Operacion
    {
        public override decimal Ejecutar()
        {
            
            return Numero1 + Numero2;
        }
    }

    public class Resta : Operacion
    {
        public override decimal Ejecutar()
        {
            return Numero1 - Numero2;
        }
    }
}
