﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2020_06_01_TRY__CATCH
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int _temperatura = 0;
            try
            {
                _temperatura = int.Parse(Interaction.InputBox("Ingrese la Temperatura"));
                if (_temperatura < 0)
                { throw new TemperaturaMenorACeroException(_temperatura); }
                if (_temperatura >= 100)
                { throw new TemperaturaMayorOIgualACienException(_temperatura); }
                MessageBox.Show("Se aplicó la temperatura al calentador");
            }
            catch (TemperaturaMenorACeroException ex)
            { MessageBox.Show(ex.Message); }
            catch (TemperaturaMayorOIgualACienException ex)
            { MessageBox.Show(ex.Message); }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            finally
            { MessageBox.Show("Siempre paso por aquí independientemente a que ocurra una ´exception´"); }
        }
    }
    public class TemperaturaMenorACeroException :Exception
    { 
        int _temperatura;
        public TemperaturaMenorACeroException(int pTemperatura) { _temperatura = pTemperatura; }
        public override string Message => $"La tempratura es menor a cero: {_temperatura.ToString()} grados centígrados";
    }
    public class TemperaturaMayorOIgualACienException : Exception
    {
        int _temperatura;
        public TemperaturaMayorOIgualACienException(int pTemperatura) { _temperatura = pTemperatura; }
        public override string Message => $"La tempratura asciende a: {_temperatura.ToString()} grados centígrados";
    }
}
