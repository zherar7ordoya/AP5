﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2020_06_23_IABMC
{
    public partial class Form1 : Form
    {
        Suma _s;
        Resta _r;
        Producto _p;
        public Form1()
        {
            InitializeComponent();
            _s = new Suma();  _r = new Resta(); _p = new Producto();     
        }
        private void CalculaPolimorfico(ICalculo pC)
        {
            textBox3.Text = pC.Ejecutar(decimal.Parse(textBox1.Text), decimal.Parse(textBox2.Text)).ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            CalculaPolimorfico(_s);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            CalculaPolimorfico(_r);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            CalculaPolimorfico(_p);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            CalculaPolimorfico(_s);
        }
    }
    public class Suma : ICalculo
    {
        public decimal Ejecutar(decimal n1, decimal n2)
        {
            return n1+n2;
        }
    }
    public class Resta : ICalculo
    {
        public decimal Ejecutar(decimal n1, decimal n2)
        {
            return n1-n2;
        }
    }
    public class Producto : ICalculo
    {
        public  decimal Ejecutar(decimal n1, decimal n2)
        {
            return n1*n2;
        }
    }
    interface ICalculo
    {
         decimal Ejecutar(decimal n1, decimal n2) ;        
    }
    public class Auto : Iabmc<string, int>
    {
        public int Alta(string pA)
        {
            throw new NotImplementedException();
        }

        public int Baja(string pB)
        {
            throw new NotImplementedException();
        }

        public int Consulta(string pC)
        {
            throw new NotImplementedException();
        }

        public int Modificacion(string pM)
        {
            throw new NotImplementedException();
        }
    }
    interface Iabmc<T,V> 
    {
        V Alta(T pA);
        V Baja(T pB);
        V Modificacion(T pM);
        V Consulta(T pC);

    }
}
