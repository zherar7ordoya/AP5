﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2020_06_16_ICloneable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Empleado E3 = new Empleado("Maria", "Fernandez", null);
            Empleado E1 = new Empleado("Juan", "Garcia", E3);
            textBox1.Text += $"Estado de E1{Constants.vbCrLf}";
            textBox1.Text += $"Nombre: {E1.Nombre}{Constants.vbCrLf}Apellido: {E1.Apellido}{Constants.vbCrLf}Jefe: {E1.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            Empleado E2 = E1;
            textBox1.Text += $"Estado de E2{Constants.vbCrLf}";
            textBox1.Text += $"Nombre: {E2.Nombre}{Constants.vbCrLf}Apellido: {E2.Apellido}{Constants.vbCrLf}Jefe: {E2.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            E2.Nombre = "Ana";
            E2.Jefe.Nombre = "Sol";
            textBox1.Text += $"Cambio de estado en E2{Constants.vbCrLf}";
            textBox1.Text += $"El nombre es Ana{Constants.vbCrLf}El nombre del Jefe es Sol{Constants.vbCrLf}{Constants.vbCrLf}**************{Constants.vbCrLf}";
            textBox1.Text += $"Estado de E2{Constants.vbCrLf}";
            textBox1.Text += $"Nombre: {E2.Nombre}{Constants.vbCrLf}Apellido: {E2.Apellido}{Constants.vbCrLf}Jefe: {E2.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            textBox1.Text += $"Estado de E1{Constants.vbCrLf}";
            textBox1.Text += $"Nombre: {E1.Nombre}{Constants.vbCrLf}Apellido: {E1.Apellido}{Constants.vbCrLf}Jefe: {E1.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Empleado E3 = new Empleado("Maria", "Fernandez", null);
            Empleado E1 = new Empleado("Juan", "Garcia", E3);
            textBox2.Text += $"Estado de E1{Constants.vbCrLf}";
            textBox2.Text += $"Nombre: {E1.Nombre}{Constants.vbCrLf}Apellido: {E1.Apellido}{Constants.vbCrLf}Jefe: {E1.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            Empleado E2 = E1.CloneEmpleado();
            textBox2.Text += $"Estado de E2{Constants.vbCrLf}";
            textBox2.Text += $"Nombre: {E2.Nombre}{Constants.vbCrLf}Apellido: {E2.Apellido}{Constants.vbCrLf}Jefe: {E2.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            E2.Nombre = "Ana";
            E2.Jefe.Nombre = "Sol";
            textBox2.Text += $"Cambio de estado en E2{Constants.vbCrLf}";
            textBox2.Text += $"El nombre es Ana{Constants.vbCrLf}El nombre del Jefe es Sol{Constants.vbCrLf}{Constants.vbCrLf}**************{Constants.vbCrLf}";
            textBox2.Text += $"Estado de E2{Constants.vbCrLf}";
            textBox2.Text += $"Nombre: {E2.Nombre}{Constants.vbCrLf}Apellido: {E2.Apellido}{Constants.vbCrLf}Jefe: {E2.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            textBox2.Text += $"Estado de E1{Constants.vbCrLf}";
            textBox2.Text += $"Nombre: {E1.Nombre}{Constants.vbCrLf}Apellido: {E1.Apellido}{Constants.vbCrLf}Jefe: {E1.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Empleado E3 = new Empleado("Maria", "Fernandez", null);
            Empleado E1 = new Empleado("Juan", "Garcia", E3);
            textBox3.Text += $"Estado de E1{Constants.vbCrLf}";
            textBox3.Text += $"Nombre: {E1.Nombre}{Constants.vbCrLf}Apellido: {E1.Apellido}{Constants.vbCrLf}Jefe: {E1.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            Empleado E2 = E1.CloneDeepEmpleado();
            textBox3.Text += $"Estado de E2{Constants.vbCrLf}";
            textBox3.Text += $"Nombre: {E2.Nombre}{Constants.vbCrLf}Apellido: {E2.Apellido}{Constants.vbCrLf}Jefe: {E2.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            E2.Nombre = "Ana";
            E2.Jefe.Nombre = "Sol";
            textBox3.Text += $"Cambio de estado en E2{Constants.vbCrLf}";
            textBox3.Text += $"El nombre es Ana{Constants.vbCrLf}El nombre del Jefe es Sol{Constants.vbCrLf}{Constants.vbCrLf}**************{Constants.vbCrLf}";
            textBox3.Text += $"Estado de E2{Constants.vbCrLf}";
            textBox3.Text += $"Nombre: {E2.Nombre}{Constants.vbCrLf}Apellido: {E2.Apellido}{Constants.vbCrLf}Jefe: {E2.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
            textBox3.Text += $"Estado de E1{Constants.vbCrLf}";
            textBox3.Text += $"Nombre: {E1.Nombre}{Constants.vbCrLf}Apellido: {E1.Apellido}{Constants.vbCrLf}Jefe: {E1.ToString()}{Constants.vbCrLf}**************{Constants.vbCrLf}{Constants.vbCrLf}";
        }
    }
    public class Empleado : ICloneable
    {
        public Empleado() { }
        public Empleado(string pNombre, string pApellido, Empleado pJefe) { Nombre = pNombre; Apellido = pApellido; Jefe = pJefe; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public Empleado Jefe { get; set; }
        public Empleado CloneDeepEmpleado()
        {

            return CloneDeepEmpleadoRecu(this);
        }
        private Empleado CloneDeepEmpleadoRecu(Empleado pEmpleado)
        {
            Empleado _aux = pEmpleado.CloneEmpleado();
            if (_aux.Jefe != null) { _aux.Jefe = CloneDeepEmpleadoRecu(_aux.Jefe); }
            return _aux;
            List<Empleado> L = new List<Empleado>();
        }
        public Empleado CloneEmpleado()
        {
            return (Empleado)Clone();
        }
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        public override string ToString()
        {
            string _s = "";
            try
            {
                _s = $"{Jefe.Nombre} {Jefe.Apellido}";
            }
            catch (Exception)
            {

                throw;
            }
            return _s;
        }
    }
}
