﻿namespace _2020_06_16_ICloneable
{
    internal interface Icloneable
    {
    }
}