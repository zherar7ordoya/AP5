﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2020_05_05_TPR_03
{
    public partial class Form1 : Form
    {
        private Empresa _empresa;
        public Form1()
        {
            InitializeComponent();

        }
        #region "Funciones suscriptas a eventos"
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Se configuran las grilla
                ConfiguraGrilla(new List<DataGridView>() { dataGridView1, dataGridView2, dataGridView3, dataGridView4 }) ;
                VisibilidadBotones(0, dataGridView1); VisibilidadBotones(0, dataGridView2);
                // Se instancia una empresa
                _empresa = new Empresa();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Se obtiene crea una persona y se le coloca el DNI
                Persona _auxPersona = new Persona(Interaction.InputBox("DNI: "), "", "");
                // Se verifica si el DNI existe en la lista de persobas de la empresa
                if (!_empresa.PersonaExiste(_auxPersona))
                {
                    // Se ingresan los Datos de la persona
                    IngresaDatosPersona(_auxPersona);
                }
                else
                // Exception por DNI repetido
                { throw new Exception("El DNI ingresado ya existe !!!!"); }
                // Se agrega la persona a la lista de personas de la empresa
                _empresa.AgregarPersona(_auxPersona);
                // Se refresca la grilla 1
                Mostrar(dataGridView1, _empresa.RetornaListaPersonas());
                // Se refresca la grilla 3
                dataGridView1_RowEnter(null,null);
                VisibilidadBotones(_empresa.RetornaListaPersonas().Count, dataGridView1);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Se selecciona la persona seleccionada en la grilla 1
                if (dataGridView1.Rows.Count > 0)
                {
                    Persona _auxPersona = (Persona)dataGridView1.SelectedRows[0].DataBoundItem;
                    // Se evalúa si la persona posee autos
                    if (_auxPersona.CantidadDeAutos() > 0)
                    {
                        // A cada auto que posee la persona se le coloca el dueño a null
                        foreach (Auto _a in _auxPersona.ListaDeAutos())
                        {
                            _a.AsignaDuexo(null);
                        }
                    }
                    // Se borra la persona de la lista de personas de la empresa
                    _empresa.BorrarPersona(_auxPersona);
                    // Se refresca la grilla 1
                    Mostrar(dataGridView1, _empresa.RetornaListaPersonas());
                    // Se refresca la grilla 3
                    dataGridView1_RowEnter(null, null);
                    // Se refresca la grilla 4
                    dataGridView2_RowEnter(null, null);
                    VisibilidadBotones(_empresa.RetornaListaPersonas().Count, dataGridView1);
                }
                else { throw new Exception("Intenta borrar algo inexistente !!!!!"); }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Se obtiene la perona seleccionada en la grilla 1
                Persona _auxPersona = ((Persona)dataGridView1.SelectedRows[0].DataBoundItem);
                // Si existe una perona seleccionada se procede al ingreso de datos para modificar los existentes
                if (!(_auxPersona is null))
                {
                    IngresaDatosPersona(_auxPersona);
                }
                // Se refresca la grilla 1
                Mostrar(dataGridView1, _empresa.RetornaListaPersonas());
                // Se refresca la grilla 4
                dataGridView2_RowEnter(null,null) ;
                VisibilidadBotones(_empresa.RetornaListaPersonas().Count, dataGridView1);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                // Se crea un auto con su patente
                Auto _auxAuto = new Auto(Interaction.InputBox("Patente: "), "", "", "", 0);
                // Se verifica que la patente del auto no exista
                if (!_empresa.AutoExiste(_auxAuto))
                {
                    // Se ingresan los datos del auto
                    IngresaDatosAuto(_auxAuto);               
                }
                else
                // Error por patente existente
                { throw new Exception("La paternte ingresada ya existe !!!!"); }
                // Si no hay error se agrega el auto a la lista e autos de la empresa
                _empresa.AgregarAuto(_auxAuto);
                // Se refresca la grilla 2
                Mostrar(dataGridView2, _empresa.RetornaListaAutos());
                // Se refresca la grilla 4
                dataGridView2_RowEnter(null, null);
                // Se refresca la grilla 3
                dataGridView1_RowEnter(null, null);
                VisibilidadBotones(_empresa.RetornaListaAutos().Count, dataGridView2);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                // Se toma el auto seleccionado en la grilla 2
                Auto _auto = (Auto)dataGridView2.SelectedRows[0].DataBoundItem;
                // Si el auto tiene dueño, se remueve el auto de la lista de autos del dueªno del auto actulmente seleccionado en la grilla 2
                if (!(_auto.Duexo() is null)) { _auto.Duexo().ListaDeAutos().Remove(_auto); }
                // Se borra el auto de la lista de autos de la empresa
                _empresa.BorrarAuto(_auto);
                // Se refresca la grilla 2
                Mostrar(dataGridView2, _empresa.RetornaListaAutos());
                // Se refresca la grilla 4
                dataGridView2_RowEnter(null, null);
                // Se refresca la grilla 3
                dataGridView1_RowEnter(null, null);
                VisibilidadBotones(_empresa.RetornaListaAutos().Count, dataGridView2);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Auto _auxAuto = (Auto)dataGridView2.SelectedRows[0].DataBoundItem;
                //Se evalúa si existe un auto seleccionado en la grilla 2
                if (!(_auxAuto is null))
                {
                    IngresaDatosAuto(_auxAuto);
                }
                //Refresca la grilla 2
                Mostrar(dataGridView2, _empresa.RetornaListaAutos());
                //Refresca la grilla 3
                dataGridView1_RowEnter(null, null);
                //Refresca la grilla 4
                dataGridView2_RowEnter(null, null);
                VisibilidadBotones(_empresa.RetornaListaAutos().Count, dataGridView2);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }


        }      
        private void button7_Click(object sender, EventArgs e)
        {
            try 
            {
                // Tomamos la persona seleccionada en la grilla 1
                if (dataGridView1.Rows.Count > 0 && dataGridView2.Rows.Count > 0)
                {
                    Persona _auxPersona;
                    Auto _auxAuto;
                    _auxPersona = (Persona)dataGridView1.SelectedRows[0].DataBoundItem;
                    _auxAuto = (Auto)dataGridView2.SelectedRows[0].DataBoundItem;
                    // Se evalúa que el auto no posea dueño
                    if (_auxAuto.Duexo() is null)
                    {
                        // Agregamos el auto seleccionado en la grilla 2 a la persona selecionada en la grilla 1
                        _auxPersona.AgregaAuto(_auxAuto);
                        // Le agregamos al auto su dueño
                        _auxAuto.AsignaDuexo(_auxPersona);
                        dataGridView1_RowEnter(null, null);
                        dataGridView2_RowEnter(null, null);
                    }
                    else throw new Exception("El auto ya posee un dueño !!!!");
                }
                else throw new Exception("Alguna de las grillas no posee elementos !!!!");
            }
            
            catch (Exception ex) { MessageBox.Show(ex.Message); }

   

        }
        private void button8_Click(object sender, EventArgs e)
        {
            try 
            {
                // Se obtiene la persona seleccionada en la grilla 1
                Persona _auxPersona = (Persona)dataGridView1.SelectedRows[0].DataBoundItem;
                // Se obtiene la patente del auto seleccionado en la grilla 3
                string _patente = dataGridView3.SelectedRows[0].Cells[0].Value.ToString();
                // Se obtiene el auto de la lista de autos de la persona seleccionada en la grilla 1
                Auto _auto =_auxPersona.ListaDeAutos().Find(x => x.Patente==_patente);
                // Se borra el auto de la lista de autos de la persona seleccionada en la grilla 1
                _auxPersona.ListaDeAutos().Remove(_auto);
                // Se borra en el auto al dueño desasignado 
                _auto.AsignaDuexo(null);
                dataGridView1_RowEnter(null,null);
                dataGridView2_RowEnter(null, null);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(dataGridView1.Rows.Count>0)
                {
                    // Se obtiene la lista de autos de la persona seleccionada en la grilla 1
                    List<Auto> _listaDeAutos= ((Persona)dataGridView1.SelectedRows[0].DataBoundItem).ListaDeAutos();
                    // Refresca la grrilla 3 con los autos  de la persona seleccionada en la grilla 1
                    Mostrar(dataGridView3,_listaDeAutos.ToList<Auto>());
                    // Muestra el Valor del total de los autos de la  de la persona seleccionada en la grilla 1
                    label1.Text = $"Valor autos: {_listaDeAutos.Sum<Auto>(x => x.Precio).ToString()}";
                }
            }
            catch (Exception) { }
        }
        private void dataGridView2_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            // Se instancia un AutoVista
            AutoVista _av = new AutoVista();
            try
            {
                if (dataGridView2.Rows.Count > 0)
                {
                    // Se refrescan los datos de la Grilla 4
                    Mostrar(dataGridView4, _av.RetornaListaAutoVista(_empresa.RetornaListaAutos()));
                }
            }
            catch (Exception) { }

        }

        #endregion

        #region "Funciones Privadas de servicio"
        // Función para ingresar los datos de la persona
        private void IngresaDatosPersona(Persona _auxPersona)
        {
            _auxPersona.Nombre = Interaction.InputBox("Nombre: ", "", _auxPersona.Nombre);
            _auxPersona.Apellido = Interaction.InputBox("Apellido: ", "", _auxPersona.Apellido);
        }
        // Función para ingresar los datos del auto
        private void IngresaDatosAuto(Auto _auxAuto)
        {
            try
            {
                _auxAuto.Marca = Interaction.InputBox("Marca: ", "", _auxAuto.Marca);
                _auxAuto.Modelo = Interaction.InputBox("Modelo: ", "", _auxAuto.Modelo);
                _auxAuto.Axo = Interaction.InputBox("Año: ", "", _auxAuto.Axo);
                _auxAuto.Precio = decimal.Parse(Interaction.InputBox("Precio: ", "", _auxAuto.Precio.ToString()));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        // Función para mostrar contenidos en las grillas 
        private void Mostrar(DataGridView pDGV, object pQueMuestro)
        {
            pDGV.DataSource = null; pDGV.DataSource = pQueMuestro;
            if (((DataGridView)pDGV).Name == "dataGridView1" && (((DataGridView)pDGV).Rows.Count > 0))
                dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        // Función para mostrar / ocultar botones
        private void VisibilidadBotones(int pCantidad, DataGridView pGrilla)
        {
            if (pGrilla.Name == "dataGridView1" && pCantidad == 0) { button2.Visible = false; button3.Visible = false; }
            if (pGrilla.Name == "dataGridView1" && pCantidad > 0) { button2.Visible = true; button3.Visible = true; }
            if (pGrilla.Name == "dataGridView2" && pCantidad == 0) { button5.Visible = false; button6.Visible = false; }
            if (pGrilla.Name == "dataGridView2" && pCantidad > 0) { button5.Visible = true; button6.Visible = true; }


        }
        // Función para configurar las grillas
        private void ConfiguraGrilla(List<DataGridView> _pLDGV)
        {
            foreach (DataGridView _dataGridView in _pLDGV)
            {
                _dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                _dataGridView.MultiSelect = false;
                _dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue;
                _dataGridView.EnableHeadersVisualStyles = false;
                _dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkSlateBlue;
                _dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                _dataGridView.RowHeadersDefaultCellStyle.BackColor = Color.DarkSlateBlue;
                _dataGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.DarkSlateBlue;
                _dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                _dataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }


        #endregion
      
    }
}

    #region "Clase de Vista"
        // Clase para formatear los datos a visualizar en la grilla 4
        public class AutoVista
        {
            List<AutoVista> _listaAutoVista;
            public AutoVista() { _listaAutoVista = new List<AutoVista>(); }
            AutoVista(string pMarca, string pModelo, string pAxo, string pPatente, string pDNI, string pApellido_Nombre)
            {
                Patente = pPatente; Marca = pMarca; Modelo = pModelo; Axo = pAxo; Patente = pPatente; DNI = pDNI; Apellido_Nombre = pApellido_Nombre;
                _listaAutoVista = new List<AutoVista>();
            }
            public string Marca { get; set; }
            public string Modelo { get; set; }
            public string Axo { get; set; }
            public string Patente { get; set; }
            public string DNI { get; set; }
            public string Apellido_Nombre { get; set; }
            // Función que recibe una lista de Autos y retorna una lista de AutosVista
            public List<AutoVista> RetornaListaAutoVista(List<Auto> pListaAuto)
            {
                _listaAutoVista.Clear();
                try
                {
                    foreach (Auto _a in pListaAuto)
                    {
                        _listaAutoVista.Add(new AutoVista(_a.Marca, _a.Modelo, _a.Axo, _a.Patente, (_a.Duexo() is null ? "" : _a.Duexo().DNI), (_a.Duexo() is null ? "" : $"{_a.Duexo().Apellido}, {_a.Duexo().Nombre}")));
                    }
                }
                catch (Exception ex) { throw new Exception(ex.Message); }
                return _listaAutoVista;
            }

        }
    #endregion

    public class Empresa
    {
        #region "Campos"
        private List<Persona> _lPersonas;
        private List<Auto> _lAutos;
        #endregion
        #region "Contructores"
        public Empresa() { _lPersonas = new List<Persona>(); _lAutos = new List<Auto>(); }
        #endregion
        #region "Propiedades"
        #endregion
        #region "Métodos"
        public List<Persona> RetornaListaPersonas() { return _lPersonas; }
        public List<Auto> RetornaListaAutos() { return _lAutos; }

        // True= Existe DNI -- False= No existe DNI
        public bool PersonaExiste(Persona pPersona)
        { return _lPersonas.Exists(x => x.DNI == pPersona.DNI); }
        public void AgregarPersona(Persona pPersona)
        {
            try
            {
                if (!PersonaExiste(pPersona)) { _lPersonas.Add(pPersona); }
                else { throw new Exception("El DNI ingresado ya existe !!!!"); }
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }
        public void BorrarPersona(Persona pPersona)
        {
            try
            { _lPersonas.Remove(pPersona); }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }

        // True= Existe Patente -- False= No existe Patente
        public bool AutoExiste(Auto pAuto)
        {
            return _lAutos.Exists(x => x.Patente == pAuto.Patente);
        }
        public void AgregarAuto(Auto pAuto)
        {
            try
            {
                if (!AutoExiste(pAuto)) { _lAutos.Add(pAuto); }
                else { throw new Exception("La patente ingresada ya existe !!!!"); }
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }
        public void BorrarAuto(Auto pAuto)
        {
            try
            { _lAutos.Remove(pAuto); }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }

        #endregion
        #region "Destructor"
        #endregion
    }
    public class Persona
    {
        #region "Campos"
        private List<Auto> _lAutos;
        #endregion
        #region "Contructores"
        public Persona() { _lAutos = new List<Auto>(); }
        public Persona(string pDNI, string pNombre, string pApellido) : this()
        { DNI = pDNI; Nombre = pNombre; Apellido = pApellido; }
        #endregion
        #region "Propiedades"
        public string DNI { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        #endregion
        #region "Métodos"
        public List<Auto> ListaDeAutos()
        { return _lAutos; }
        public int CantidadDeAutos()
        { return _lAutos.Count; ; }
        public void AgregaAuto(Auto pAuto)
        {
        _lAutos.Add(pAuto);
        }
        #endregion
        #region "Destructor"
        ~Persona() { _lAutos = null; MessageBox.Show($"El DNI de la persona es: {DNI}"); }

        #endregion
    }
    public class Auto
    {
        #region "Campos"
        Persona _duexo;
        #endregion
        #region "Contructores"
        public Auto() { _duexo = null; }
        public Auto(string pPatente, string pMarca, string pModelo, string pAxo, decimal pPrecio) : this()
        { Patente = pPatente; Marca = pMarca; Modelo = pModelo; Axo = pAxo; Precio = pPrecio; }
        #endregion
        #region "Propiedades"
        public string Patente { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Axo { get; set; }
        public decimal Precio { get; set; }
        #endregion
        #region "Métodos"
        public Persona Duexo() { return _duexo; }
        public void AsignaDuexo(Persona pDuexo) { _duexo = pDuexo; }
        #endregion
        #region "Destructor"
        ~Auto() { MessageBox.Show($"La patente del auto es: {this.Patente}"); }
        #endregion



    }




