﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2020_06_16_IComparer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Persona> _p;   List<Persona> _pAux;
        private void Form1_Load(object sender, EventArgs e)
        {
            // Genero una lista
            _p = new List<Persona>() {new Persona("Juan","Perez",24),
                             new Persona("Ana","Martinez",22),
                             new Persona("Maria","Fernandez",29)};

            // Clono la lista
            _pAux = new List<Persona>();
            foreach (Persona _xp in _p) { _pAux.Add(new Persona(_xp.Nombre, _xp.Apellido, _xp.Edad)); }
            radioButton1_CheckedChanged(null, null); Mostar();
        }

        private void Mostar()
        {
            // Muestro la lista clonada sin ordenar
            dataGridView1.DataSource = null; dataGridView1.DataSource = _pAux;      
            // Muestro la lista ordenada
            dataGridView2.DataSource = null; dataGridView2.DataSource = _p;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            // Ordeno la lista
            _p.Sort(Persona.Orden<Persona.NombreAsc>()); Mostar();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            // Ordeno la lista
            _p.Sort(Persona.Orden<Persona.NombreDesc>()); Mostar();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // Ordeno la lista
            _p.Sort(Persona.Orden<Persona.ApellidoAsc>()); Mostar();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            // Ordeno la lista
            _p.Sort(Persona.Orden<Persona.ApellidoDesc>()); Mostar();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            // Ordeno la lista
            _p.Sort(Persona.Orden<Persona.EdadAsc>()); Mostar();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            // Ordeno la lista
            _p.Sort(Persona.Orden<Persona.EdadDesc>()); Mostar();
        }
    }
    public class Persona 
    {
        public Persona(string pNombre, string pApellido, int pEdad) { Nombre = pNombre; Apellido = pApellido; Edad = pEdad; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }

        public static IComparer<Persona> Orden<T>() where T : IComparer<Persona>, new()
        {
            return new T();
        }
        public class NombreAsc : IComparer<Persona>
        {
            public int Compare(Persona x, Persona y)
            {
                return String.Compare(x.Nombre, y.Nombre);
            }
        }
        public class NombreDesc : IComparer<Persona>
        {
            public int Compare(Persona x, Persona y)
            {
                return (String.Compare(x.Nombre, y.Nombre)*-1);
            }
        }
        public class ApellidoAsc : IComparer<Persona>
        {
            public int Compare(Persona x, Persona y)
            {
                return String.Compare(x.Apellido, y.Apellido);
            }
        }
        public class ApellidoDesc : IComparer<Persona>
        {
            public int Compare(Persona x, Persona y)
            {
                return (String.Compare(x.Apellido, y.Apellido)* -1);
            }
        }
        public class EdadAsc : IComparer<Persona>
        { 
            public int Compare(Persona x, Persona y)
            {
                return x.Edad < y.Edad ? -1 : (x.Edad == y.Edad ? 0 : 1); 
            }
        }
        public class EdadDesc : IComparer<Persona>
        {
            public int Compare(Persona x, Persona y)
            {
                return y.Edad < x.Edad ? -1 : (y.Edad == x.Edad ? 0 : 1);
            }
        }
    }

}
