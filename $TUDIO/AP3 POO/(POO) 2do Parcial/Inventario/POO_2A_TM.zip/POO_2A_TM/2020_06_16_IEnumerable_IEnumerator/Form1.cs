﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2020_06_16_IEnumerable_IEnumerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] _leyendas = {"País: ","Empresa: ","Producto: ","DV: "};
            int _contador = 0;
            Producto _p = new Producto(98,"Cafiaspirina", "7793640000778");
            _p.Reset();
            textBox1.Text += $"Datos del Producto{Constants.vbCrLf}{Constants.vbCrLf}";
            textBox1.Text += $"Id: {_p.Id}{Constants.vbCrLf}";
            textBox1.Text += $"Descripción: {_p.Descripcion}{Constants.vbCrLf}{Constants.vbCrLf}";
            textBox1.Text += $"Datos del EAN-13:{Constants.vbCrLf}{Constants.vbCrLf}";
            foreach(string _s in _p)
            {
                textBox1.Text += $"{_leyendas[_contador]}{_s}{Constants.vbCrLf}"; _contador++;
            }
        }
    }

    public class Producto : IEnumerable, IEnumerator<string>
    {
        // EAN-13
        // PIP IPIP IPIPI
        // 779 3640 00077 8
        // Pares= 29
        // Impares= 21 * 3= 63
        // Sumamos 29 + 63 = 92
        // Buscamos el múltiplo de 10  que supera el resultado obtenido en el paso anterior
        // 100
        // 100-92 = 8

        public Producto(int pId,string pDescripcion,string pEAN13) { Id = pId;Descripcion = pDescripcion;EAN13 = pEAN13; }
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public string EAN13 { get; set; }

        #region "IEnumerator"

        //IEnumerator
        public string Current { get; set; }

        object IEnumerator.Current
        {
            get { return Current; }
        }

        public void Dispose()
        {
            
        }

        int _contador = 0;
        int _desde = 0;
        // 0123456789012
        // 7793640800077
        int[] _tamano = {3,4,5,1};

        public bool MoveNext()
        {
            bool _rta = false;
            if (EAN13 == "" || _contador>3)
                _rta = false;
            else 
            {
                Current = EAN13.Substring(_desde, _tamano[_contador]);
                _rta = true;
                _desde += _tamano[_contador];
                _contador++;
            }
            return _rta;
        }
        public void Reset()
        {
            _contador = 0;
            _desde = 0 ;
        }
        #endregion
        #region "IEnumerable"
        // IEnumerable
        public IEnumerator GetEnumerator()
        {
            return this;
        }
        #endregion
    }


}
