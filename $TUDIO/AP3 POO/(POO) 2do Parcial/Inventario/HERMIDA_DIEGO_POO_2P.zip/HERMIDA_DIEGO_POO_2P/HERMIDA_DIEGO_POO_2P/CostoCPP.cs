﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class CostoCPP : Costo
    {

        #region "Constructores"
        public CostoCPP(string pID, string pDesc) { ID = pID; Desc = pDesc; }
        #endregion

        public override decimal CalcularCosto (decimal pCPP, int pSTA, decimal pCUA, int pQA)
        {
            return Math.Round((((pCPP * pSTA) + (pCUA * pQA)) / (pSTA + pQA)),2);
        }

    }
}
