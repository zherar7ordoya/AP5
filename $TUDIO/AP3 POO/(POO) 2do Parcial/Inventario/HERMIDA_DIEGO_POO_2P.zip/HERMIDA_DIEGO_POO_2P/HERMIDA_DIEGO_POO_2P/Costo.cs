﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public abstract class Costo
    {

        #region "Constructores"
        public Costo() { }
        public Costo(string pID, string pDesc) { ID = pID; Desc = pDesc; }
        #endregion
        #region "Propiedades"

        public string ID { get; set; }
        public string Desc { get; set; }

        #endregion
        #region "Metodos"
        public abstract decimal CalcularCosto(decimal pCPP, int pSTA, decimal pCUA, int pQA);
        #endregion

    }
}
