﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class GrillaVista
    {
        private List<GrillaVista> ListaVista;
        public GrillaVistaDesc _d;
        private List<GrillaVista> auxListaVista = new List<GrillaVista>();

        List<Articulo> A = new List<Articulo>(); 
        List<GrillaVistaDesc> _D = new List<GrillaVistaDesc>();
        

        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaAlta { get; set; }
        public string FechaBaja { get; set; }
        public string MesesVigente { get; set; }
        public decimal Costo { get; set; }
        public string CostoDesc{ get; set; }
        public int Stock { get; set; }

        public GrillaVista() { ListaVista = new List<GrillaVista>(); }

        public GrillaVista(string pCodigo, string pDescripcion, DateTime pFechaAlta, string pFechaBaja, string pMesesVigente, decimal pCosto, string pCostoDesc, int pStock)
        {
            Codigo          = pCodigo;
            Descripcion     = pDescripcion;
            FechaAlta       = pFechaAlta;
            FechaBaja       = pFechaBaja;
            MesesVigente    = pMesesVigente;
            Costo           = pCosto;
            CostoDesc       = pCostoDesc;
            Stock           = pStock;
        }

        //Visualización Meses vigencia
        private decimal MonthDifference(DateTime FechaFin, DateTime FechaInicio)
        {
            return Math.Abs((FechaFin.Month - FechaInicio.Month) + 12 * (FechaFin.Year - FechaInicio.Year));
        }

        public List<GrillaVista> RetornaGrillaVista (List<Articulo> pA)
        {
            string AuxFechaBaja = null;
            string AuxMes = null;

            ListaVista.Clear();
            foreach (Articulo Ar in pA)
            {
                //Visualización Fecha Baja, si esta vacia se muestra "--"
                if (Ar.FechaBaja.Year == 1) {AuxFechaBaja = AuxMes = "--";}
                else 
                { 
                    AuxFechaBaja = Ar.FechaBaja.ToShortDateString();
                    try
                    {//Calcular diferencia de meses
                        decimal auxDifMes = MonthDifference(Ar.FechaBaja, Ar.FechaAlta);
                        if (auxDifMes > 0) { AuxMes = Convert.ToString(auxDifMes); }
                    }
                    catch (Exception) { throw new Exception("Error calculo meses de vigencia"); }
                }
                ListaVista.Add(new GrillaVista(Ar.Codigo, Ar.Descripcion, Ar.FechaAlta, AuxFechaBaja, AuxMes, Ar.Costo, Ar.RetornarTipoCostoDesc(), Ar.Stock));
            }
            return ListaVista;
        }

        public List<GrillaVista> RetornaListaStockSuperior (List<GrillaVista> pGV, int pStock)
        {
            auxListaVista.Clear();
            var B = from Articulo in pGV where Articulo.Stock > pStock select Articulo;
            foreach (GrillaVista Z in B.ToList<GrillaVista>())
            {
                auxListaVista.Add(Z);
            }
            return auxListaVista;
        }

        public List<GrillaVistaDesc> RetornaListaStockCero (List<GrillaVista> pGV)
        {
            _D.Clear();
            var B = from Articulo in pGV where Articulo.Stock == 0 select Articulo;
            foreach (GrillaVista Z in B.ToList<GrillaVista>())
            {
                _d = new GrillaVistaDesc(Z.Descripcion);
                _D.Add(_d);
            }
            return _D;
        }

        public List<GrillaVista> RetornaListaBajaMeses(List<GrillaVista> pGV)
        {
            auxListaVista.Clear();
            var B = from Articulo in pGV where Articulo.FechaBaja != "--" select Articulo;
            foreach (GrillaVista Z in B.ToList<GrillaVista>())
            {
                auxListaVista.Add(Z);
            }

            auxListaVista.Sort(new MesesDES());
            return auxListaVista;
        }

        public List<GrillaVista> RetornaListaStockDesdeHasta(List<GrillaVista> pGV, int pStockDesde, int pStockHasta)
        {
            auxListaVista.Clear();

            List<GrillaVista> _aux = pGV.FindAll(x => x.Stock >= pStockDesde && x.Stock <= pStockHasta);

            foreach (GrillaVista Z in _aux)
            {
                auxListaVista.Add(Z);
            }
            return auxListaVista;
        }

    }

    public class ArticuloASD : IComparer<GrillaVista>

    {
        public int Compare(GrillaVista x, GrillaVista y)
        {
            return string.Compare(x.Descripcion, y.Descripcion);
        }
    }

    public class ArticuloDES : IComparer<GrillaVista>

    {
        public int Compare(GrillaVista x, GrillaVista y)
        {
            return string.Compare(x.Descripcion, y.Descripcion)*-1;
        }
    }

    public class MesesDES : IComparer<GrillaVista>

    {
        public int Compare(GrillaVista x, GrillaVista y)
        {
            return decimal.Compare(Convert.ToDecimal(x.MesesVigente), Convert.ToDecimal(y.MesesVigente)) * -1;
        }
    }

}
