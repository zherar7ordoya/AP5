﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class GrillaVistaDesc //Se utiliza para la grilla filtrada por Descripción
    {
        public GrillaVistaDesc(string pDesc) { Descripcion = pDesc; }
        public string Descripcion { get; set; }
    }
}
