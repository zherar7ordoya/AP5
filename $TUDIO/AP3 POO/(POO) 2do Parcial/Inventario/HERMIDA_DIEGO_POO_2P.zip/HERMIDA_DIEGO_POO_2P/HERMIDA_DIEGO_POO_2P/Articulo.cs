﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class Articulo
    {
        
        #region "Propiedades"
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string TipoCostoDes { get; set; }
        public decimal Costo { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime FechaBaja { get; set; }

        public int Stock { get; set; }

        private Costo TipoCosto { get; set; }

        #endregion
        #region "Metodos"

        public void AsignarTipoCosto(string pTC)
        {
            if (pTC == "CPP") TipoCosto = new CostoCPP ("CPP","Costo Promedio Ponderado");
            if (pTC == "CUE") TipoCosto = new CostoCUE ("CUE","Costo Último Entrado");
            if (pTC == "CP")  TipoCosto = new CostoCP  ("CP","Costo Personalizado");
        }       

        public string RetornarTipoCosto()
        {
            return TipoCosto.ID;
        }
        public string RetornarTipoCostoDesc()
        {
            return TipoCosto.Desc;
        }
        public Costo RetornarCosto()
        {
            return TipoCosto;
        }

        public int DisminuirStock(int pQuitarStock)
        {
            return Stock - pQuitarStock;
        }


        #endregion
        #region "Constructores"
        public Articulo() {}
        public Articulo(string pCodigo, string pDescripcion, string pTipoCostoDes, decimal pCosto, DateTime pFechaAlta, DateTime pFechaBaja, int pStock)
        {
            Codigo       = pCodigo;
            Descripcion  = pDescripcion;
            TipoCostoDes = pTipoCostoDes;
            Costo        = pCosto;
            FechaAlta    = pFechaAlta;
            FechaBaja    = pFechaAlta;
            Stock        = pStock;
        }
    }
    #endregion
}
