﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace HERMIDA_DIEGO_POO_2P
{
    public partial class Form1 : Form
    {

        private Empresa _empresa;// Variable privada para apuntar
        GrillaVista ListaVista = new GrillaVista();
        List<GrillaVista> _VistaAux = new List<GrillaVista>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _empresa = new Empresa();
            ConfigurarGrilla(dataGridView1);
        }



        //Alta Artículo
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Articulo _auxArticulo = new Articulo();

                ValidoCodigo(_auxArticulo);

                if (!_empresa.ExisteArticulo(_auxArticulo))
                {
                    IngresaArticulo(_auxArticulo);
                    _empresa.AgregarArticulo(_auxArticulo);
                    MostrarArticulos();
                    MostrarGrillaVista();
                    ActualizaImporteTotal();

                }
                else throw new Exception("El código de Articulo ya existe");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void MostrarGrillaVista()
        {
            try
            {
                dataGridView2.DataSource = null;
                dataGridView2.DataSource = ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos());
            }
            catch (Exception)
            { }
        }

        private void ValidoCodigo(Articulo _auxArticulo)
        {
            try
            {
                _auxArticulo.Codigo = Interaction.InputBox("Formato:\r     A00001\r     Z99999", "Código", _auxArticulo.Codigo);
                //Validar longitud
                if (!(_auxArticulo.Codigo.Length == 6)) throw new Exception("Error en la longitud del Código");
                //Validar formato
                if (!(ValidarCodigo(_auxArticulo.Codigo))) throw new Exception("Verifique el Código ingresado");
                //Pasa el primer caracter a mayuscula
                _auxArticulo.Codigo = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(_auxArticulo.Codigo);
            }
            catch (Exception ex)
            {
                //Burbujero el msj de error
                throw new Exception(ex.Message);
            }
        }

        private void IngresaArticulo(Articulo _auxArticulo)
        {
            try
            {
                _auxArticulo.Descripcion = Interaction.InputBox("", "Descripción", _auxArticulo.Descripcion);

                if (_auxArticulo.TipoCostoDes is null)
                {
                    string TipoCosto = Interaction.InputBox("CPP\rCUE\rCP ", "Tipo de Costo", "CPP");
                    //Valido Tipo de Costo
                    if (TipoCosto != "CPP" && TipoCosto != "CUE" && TipoCosto != "CP")
                    {
                        throw new Exception("Opción Tipo de Costo inválida");
                    }
                    _auxArticulo.TipoCostoDes = TipoCosto;
                    _auxArticulo.AsignarTipoCosto(TipoCosto);
                }

                _auxArticulo.Costo = Convert.ToDecimal(Interaction.InputBox("", "Costo", Convert.ToString(_auxArticulo.Costo)));
                if (_auxArticulo.FechaAlta.Year == 1)
                {
                    _auxArticulo.FechaAlta = Convert.ToDateTime(Interaction.InputBox("Fecha Alta", " Fecha Alta", DateTime.Today.ToShortDateString()));
                }
            }
            catch (Exception ex)
            {
                //Burbujero el msj de error
                throw new Exception(ex.Message);
            }
        }

        private bool EsNumero(string pvalor)
        {
            int _temp = 0;
            return int.TryParse(pvalor, out _temp);
        }

        private bool ValidarCodigo(string pValor)
        {
            return !EsNumero(pValor) && EsNumero(pValor.Substring(1));
        }


        private void ConfigurarGrilla(DataGridView pD)
        {
            pD.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            pD.MultiSelect = false;
            pD.ColumnHeadersDefaultCellStyle.ForeColor = Color.DarkBlue; // Color de Fuente del encabezado
            pD.RowHeadersDefaultCellStyle.BackColor = Color.DarkSeaGreen; // Color del encabezado de Fila    
            pD.RowHeadersWidth = 30;
            pD.DefaultCellStyle.SelectionBackColor = Color.DarkSeaGreen; // Color de fondo de Selección de la fila
            pD.DefaultCellStyle.SelectionForeColor = Color.White; // Color de la fuente de la fila seleccionada
            pD.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells; // Celdas Autoajustables
            pD.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; //Alineación del Texto
        }

        // Baja
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Articulo _auxArticulo = ((Articulo)dataGridView1.SelectedRows[0].DataBoundItem);
                if (!(_auxArticulo is null))
                {

                    //Validar Fecha baja
                    ValidarBaja(_auxArticulo);

                    if (_auxArticulo.Stock == 0)
                    {
                        DateTime _auxFechaBaja = Convert.ToDateTime(Interaction.InputBox("Seleccione la fecha", " Fecha de Baja", DateTime.Today.ToShortDateString()));
                        if (_auxFechaBaja > _auxArticulo.FechaAlta)
                        { _auxArticulo.FechaBaja = _auxFechaBaja;
                            MostrarArticulos();
                            MostrarGrillaVista();
                        }
                        else { throw new Exception("La Fecha Baja debe ser superior al Alta del Articulo"); }
                    }
                    else { throw new Exception("Para dar de baja un Articulo el Stock debe ser '0'"); }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Articulo _auxArticulo = ((Articulo)dataGridView1.SelectedRows[0].DataBoundItem);
                if (!(_auxArticulo is null))
                {
                    //Validar Fecha baja
                    ValidarBaja(_auxArticulo);

                    IngresaArticulo(_auxArticulo);
                }
                MostrarArticulos();
                MostrarGrillaVista();
                ActualizaImporteTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //Agregar stock
        private void button4_Click(object sender, EventArgs e)
        {
            Articulo _articulo;
            Costo _costo;
            decimal CostoUnit = 0;
            int Stock = 0;

            try
            {
                try
                {   //Valido articulo seleccionado
                    _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception) { throw new Exception("No hay ningun articulo seleccionado"); }

                //Validar Fecha baja
                ValidarBaja(_articulo);

                //Asignar Costo del Articulo
                _costo = _articulo.RetornarCosto();

                //Ingresar el nuevo stock
                try
                {
                    Stock = int.Parse(Interaction.InputBox("Ingrese la cantidad", "Agregar Stock"));
                }
                catch (Exception) { throw new Exception("Formato de stock incorrecto"); }

                //Ingresar importe unitario
                try
                {
                    CostoUnit = decimal.Parse(Interaction.InputBox("Ingrese el importe", "Agregar Costo Unitario"));
                }
                catch (Exception)
                {
                    throw new Exception("Formato de importe incorrecto");
                }

                //Actualizar Calculo y Stock
                try
                {
                    ActualizarArticulo(_articulo, _costo, CostoUnit, Stock);
                }
                catch (Exception) { throw new Exception("Error de calculo"); }

                MostrarArticulos();
                MostrarGrillaVista();
                ActualizaImporteTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private static void ValidarBaja(Articulo _articulo)
        {
            if (!(_articulo.FechaBaja.Year == 1))
            { throw new Exception("No se puede modificar un Articulo dado de baja"); }
        }

        //Disminuir Stock
        private void button5_Click(object sender, EventArgs e)
        {
            int Stock = 0;
            Articulo _articulo;
            try
            {
                try
                {   //Valido articulo seleccionado
                    _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay ningun articulo seleccionado");
                }

                //Validar Fecha baja
                ValidarBaja(_articulo);

                if (_articulo.Stock == 0) throw new Exception("El articulo seleccionado no posee Stock");

                //Ingresa stock a disminuir
                try
                {
                   Stock = int.Parse(Interaction.InputBox("Ingrese la cantidad", "Disminuir Stock"));
                }
                catch (Exception) { throw new Exception("Formato de stock incorrecto"); }

                try
                {
                    if (_articulo.Stock >= Stock)
                    {
                        _articulo.Stock = _articulo.DisminuirStock(Stock);
                    }
                    else { throw new Exception("El Stock disponible es inferior a la cantidad ingresada"); }

                    if (_articulo.Stock == 0) { StockCeroEventArgs(this, new StockCeroEventArgs(_articulo.Codigo, _articulo.Descripcion)); }

                    MostrarArticulos();
                    MostrarGrillaVista();
                    ActualizaImporteTotal();
                }
                catch (Exception ex) { throw new Exception(ex.Message); }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private static void ActualizarArticulo(Articulo _articulo, Costo _costo, decimal CostoUnit, int Stock)
        {
            _articulo.Costo = _costo.CalcularCosto(_articulo.Costo, _articulo.Stock, CostoUnit, Stock);
            _articulo.Stock = _articulo.Stock + Stock;
        }

        private void MostrarArticulos()
        {
            try
            {
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = _empresa.RetornaListaArticulos();
            }
            catch (Exception) { }
        }

        private void StockCeroEventArgs(object sender, StockCeroEventArgs e)
        {
            try
            {
                MessageBox.Show("El Articulo ID: " + e.Codigo + " - " + e.Desc + " se encuentra con stock '0'");
            }
            catch (Exception){}
        }

        //Listar Stock superior al valor ingresado
        private void button6_Click(object sender, EventArgs e)
        {
            int auxStock = 0;
            try
            {
                try
                {   //Valido articulo seleccionado
                   Articulo _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos disponibles");
                }

                //Ingresa stock a filtrar
                try
                {
                   auxStock = int.Parse(Interaction.InputBox("Ingrese el Stock", "Visualizar Stock superior al valor ingresado"));
                }
                catch (Exception) { throw new Exception("Formato de stock incorrecto"); }

                dataGridView2.DataSource = null;
                dataGridView2.DataSource = ListaVista.RetornaListaStockSuperior(ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos()),auxStock);
            }
            catch (Exception ex){MessageBox.Show(ex.Message);}
}

        //Ordenar por Descripción ASD
        private void button8_Click(object sender, EventArgs e)
        {

            List<GrillaVista> _VistaOrden = new List<GrillaVista>();

            ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos()).Sort(new ArticuloASD());

            dataGridView2.DataSource = null;

            _VistaAux = ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos());
            _VistaAux.Sort(new ArticuloASD());

            foreach ( var gv in _VistaAux)
            {
                _VistaOrden.Add(gv);
            }
            dataGridView2.DataSource = _VistaOrden;
        }


        //Listar Stock cero
        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {   //Valido articulo seleccionado
                    Articulo _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos disponibles");
                }
                dataGridView2.DataSource = null;
                dataGridView2.DataSource = ListaVista.RetornaListaStockCero(ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos()));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        //Ordenar por Descripción DES
        private void button9_Click(object sender, EventArgs e)
        {

            List<GrillaVista> _VistaOrden = new List<GrillaVista>();

            try
            {
                try
                {   //Valido articulo seleccionado
                    Articulo _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos disponibles");
                }

                ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos()).Sort(new ArticuloDES());

                dataGridView2.DataSource = null;

                _VistaAux = ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos());
                _VistaAux.Sort(new ArticuloDES());

                foreach (var gv in _VistaAux)
                {
                    _VistaOrden.Add(gv);
                }

                dataGridView2.DataSource = _VistaOrden;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        //Articulos de baja ordenados por meses DES
        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {   //Valido articulo seleccionado
                    Articulo _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos disponibles");
                }
                dataGridView2.DataSource = null;
                dataGridView2.DataSource = ListaVista.RetornaListaBajaMeses(ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos()));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
           
        }

        //Filtrar Stock desde hasta
        private void button11_Click(object sender, EventArgs e)
        {

            int auxStockDesde = 0;
            int auxStockHasta = 0;

            try
            {
                try
                {   //Valido articulo seleccionado
                    Articulo _articulo = (Articulo)dataGridView1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception)
                {
                    throw new Exception("No hay articulos disponibles");
                }

                //Ingresa stock a filtrar
                try
                {
                    auxStockDesde = int.Parse(Interaction.InputBox("Ingrese el Stock DESDE", "Visualizar Stock Desde-Hasta"));
                }
                catch (Exception) { throw new Exception("Formato de stock incorrecto"); }
                try
                {
                    auxStockHasta = int.Parse(Interaction.InputBox("Ingrese el Stock HASTA", "Visualizar Stock Desde-Hasta"));
                }
                catch (Exception) { throw new Exception("Formato de stock incorrecto"); }

                dataGridView2.DataSource = null;
                dataGridView2.DataSource = ListaVista.RetornaListaStockDesdeHasta(ListaVista.RetornaGrillaVista(_empresa.RetornaListaArticulos()), auxStockDesde, auxStockHasta);

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }





        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ActualizaImporteTotal();
        }
        private void ActualizaImporteTotal()
        {
            decimal auxSubtotal = 0;
            foreach (Articulo Ar in _empresa.RetornaListaArticulos())
            {
                if (Ar.Costo > 0 && Ar.Stock > 0)
                {
                    auxSubtotal = auxSubtotal + (Ar.Costo * Ar.Stock);
                }
            }
                string aux = Convert.ToString(auxSubtotal);
                textBox1.Text = aux;
        }
    }

    public class StockCeroEventArgs : EventArgs
    {
        public string Codigo { get; set; }
        public string Desc { get; set; }
        public StockCeroEventArgs(string pCodigo, string pDesc) { Codigo = pCodigo; Desc = pDesc; }
    }

}
