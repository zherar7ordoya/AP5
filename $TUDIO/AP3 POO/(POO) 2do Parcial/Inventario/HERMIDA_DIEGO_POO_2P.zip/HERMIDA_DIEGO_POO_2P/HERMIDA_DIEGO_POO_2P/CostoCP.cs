﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class CostoCP : Costo
    {
        private const decimal c_uno_diez = 1.1m;

    public CostoCP(string pID, string pDesc) { ID = pID; Desc = pDesc; }

        public override decimal CalcularCosto(decimal pCP, int pSTA, decimal pCA, int pQA)
        {
            return Math.Round(((pCP + pCA)/2)* c_uno_diez,2);
        }
    }

}
