﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class Empresa
    {

        #region "Campos"
        private List<Articulo> _ListaArticulos;
        #endregion
        #region "Constructores"

        public Empresa ()
        {
            _ListaArticulos = new List<Articulo>();
        }
        #endregion
 
        #region "Metodos"
        public List<Articulo> RetornaListaArticulos()
        {
            return _ListaArticulos;// metodo que retornara lista de trjetas
        }

        public void AgregarArticulo (Articulo pArticulo)
        {
            _ListaArticulos.Add(pArticulo);
        }

        public bool ExisteArticulo(Articulo pArticulo)
        { 
            return _ListaArticulos.Exists(x => x.Codigo == pArticulo.Codigo);
        }
        #endregion
    }
        
}
