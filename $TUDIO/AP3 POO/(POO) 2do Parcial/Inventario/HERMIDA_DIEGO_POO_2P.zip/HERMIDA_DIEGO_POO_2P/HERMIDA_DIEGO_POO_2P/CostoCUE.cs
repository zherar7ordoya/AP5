﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HERMIDA_DIEGO_POO_2P
{
    public class CostoCUE : Costo
    {
        public CostoCUE(string pID, string pDesc) { ID = pID; Desc = pDesc; }

        public override decimal CalcularCosto(decimal pCUEAnterior, int pSTA, decimal pCUA, int pQA)
        {
            return Math.Round((pCUEAnterior),2);
        }
    }
}
