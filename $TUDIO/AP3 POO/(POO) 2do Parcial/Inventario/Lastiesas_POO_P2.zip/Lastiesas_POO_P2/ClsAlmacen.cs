﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class ClsAlmacen: IDisposable
    {

        #region Campos
        private List<ClsProducto> ListaDeProducto;
        List<ClsProducto> AuxProd;

        #endregion

        #region Constructores
        public ClsAlmacen()
        {
            ListaDeProducto = new List<ClsProducto>();
            AuxProd = new List<ClsProducto>();
        }
        #endregion

        #region Metodos
        public List<ClsProducto> RetornaProductos()
        {
            return ListaDeProducto;
        }
        
        public ClsProducto RetornaProducto(ClsVistaGrilla1 pvg1)
        {
            return ListaDeProducto.Find(x => x.ID == pvg1.ID);
        }

        public ClsProducto RetornaArticulo(string pCodigo)
        {
            return ListaDeProducto.Find(x => x.ID == pCodigo);
        }

        public void AltaProducto(ClsProducto pP)
        {
            if (!ListaDeProducto.Exists(x => x.ID == pP.ID))
            {
                pP.STA = pP.QA;
                pP.QA = 0;
                ListaDeProducto.Add(pP);
            }
            else
            {
                throw new Exception("El ID " + pP.ID + " ya existe");
            }

        }

        public void BajaProducto(ClsVistaGrilla1 pVP)
        {
            ListaDeProducto.Remove(ListaDeProducto.Find(x => x.ID == pVP.ID));
        }

        public void ModificarProducto(ClsProducto pP)
        {
            ClsProducto P = ListaDeProducto.Find(x => x.ID == pP.ID);
            P.ID = pP.ID;
            P.FromDate = pP.FromDate;
            P.ToDate = pP.ToDate;
            P.Descripcion = pP.Descripcion;

        }

        public void AgregarStock(ClsProducto pP)
        {
            ClsProducto p = ListaDeProducto.Find(x => x.ID == pP.ID);
            p.STA = pP.STA;
            p.CostoProd = pP.CostoProd;
        }

        public void QuitarStock(ClsProducto pP)
        {
            ClsProducto p = ListaDeProducto.Find(x => x.ID == pP.ID);
            p.STA = pP.STA;
        }

        public List<ClsProducto> RetornaClonListaProductos()
        {
            // Con este metodo clono la lista a medida que utilizo el foreach
            // la clase Producto implementa IClonable
            List<ClsProducto> ListaClonProd = new List<ClsProducto>();
            foreach (ClsProducto P in ListaDeProducto)
            {
                ListaClonProd.Add((ClsProducto)P.Clone());
            }
            return ListaClonProd;
        } 
        private List<ClsProducto> Consulta(IEnumerable<ClsProducto> Cons)
        {
            foreach (ClsProducto A in Cons)
            {
                AuxProd.Add((ClsProducto)A.Clone());
            }
            if (AuxProd.Count == 0)
            {
                throw new Exception("Ningun producto cumple con lo requerido.");
            }
            return AuxProd;
        }
 
        public List<ClsProducto> ProductoValorMayor(int Valor)
        {
            AuxProd.Clear();// Limpio
            var Cons = from a in ListaDeProducto where a.STA > Valor select a;
            return Consulta(Cons);
        }
        public string SumatoriaStock( double D)
        {
            List<ClsProducto> Lprod = new List<ClsProducto>();
            Lprod =RetornaClonListaProductos();
            double dinero =D;
            double aux = 0;

            foreach (ClsProducto p in Lprod)
            {
                aux = (p.CostoProd * p.STA);
            }

            return (aux+dinero).ToString();
        }

        // con este metodo retorno una lista de productos que dejan de comercializarse
        //utilizo LINQ para filtrar la Lista de productos dado de baja 
        public List<ClsProducto> RetornaProductosNoVigentes()
        {
            List<ClsProducto> LP = new List<ClsProducto>();

            //solo se agregaran a la lista los productos fuera de circulacion
            var V = from P in ListaDeProducto where P.Vigente ==false select P;
            foreach (ClsProducto P in V)
            {
                LP.Add((ClsProducto)P.Clone());
            }
            return LP;
        }


        public List<ClsProducto> DevuelveSKUSinStock()
        {
            List<ClsProducto> LPS = new List<ClsProducto>();
            // se agregaran a la lista aquellos productos que de stock tengan valor cero
            var V = from P in ListaDeProducto where P.STA == 0 select P;
            foreach (ClsProducto P in V)
            {
                LPS.Add((ClsProducto)P.Clone());
            }
            return LPS;
        }
        public List<ClsProducto> ValidarRango(int V1, int V2)
        {
            var Que = ListaDeProducto.Where(x => x.STA > V1 && x.STA < V2);
            return hacerQuery(Que);
        }

        private List<ClsProducto> hacerQuery(IEnumerable<ClsProducto> Cons)
        {
            AuxProd.Clear();
            foreach (ClsProducto A in Cons)
            {
                AuxProd.Add((ClsProducto)A.Clone());
            }
            if (AuxProd.Count == 0)
            {
                throw new Exception("Ningun producto cumple con lo requerido.");
            }
            return AuxProd;
        }


        #endregion

        bool _DisposeOK = false;

        ~ClsAlmacen()
        {
            if (!_DisposeOK)
            {
                // Solo lo ejecutamos el Finaliza si no se ejecuta el Dispose
            }
        }
        public void Dispose()
        {
            _DisposeOK = true;
        }

    }
}
