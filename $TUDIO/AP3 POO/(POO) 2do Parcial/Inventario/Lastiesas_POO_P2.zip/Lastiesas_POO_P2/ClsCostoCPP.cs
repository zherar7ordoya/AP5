﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class ClsCostoCPP : ClsCosto
    {
        #region Propiedades
        public double CPP { get; set; }
        public int STA { get; set; }
        public double CUA { get; set; }
        public int QA { get; set; }
        #endregion

        #region Cosntructores
        public ClsCostoCPP(string pID, string pDescr) : base(pID, pDescr) { }

        #endregion

        #region Metodo
        public override double CalcularCosto(double pCPP, double pSTA, double pCUA, int pQA)
        {

            return CPP = ((pCPP * pSTA) + (pCUA * pQA)) / (pSTA + pQA);
        }

        public override double CalcularCosto(double a, double b) 
        {
            throw new Exception("el metodo no cumple con los parametros necesarios, este costo no corresponde a un CP y se intenta usar ese costo.");
        }

        public override double CalcularCosto(double a, int b)
        {
            throw new Exception("el metodo no cumple con los parametros necesarios, este costo no corresponde a un CUE y se intenta usar ese costo.");
        }


        #endregion
    }
}
