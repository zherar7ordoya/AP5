﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualBasic;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class ClsProducto : ICloneable
    {

        // declaracion de evento para cuando un articulo se queda sin stock
        public event EventHandler<ClsEvent0Stock> MMBE;


        #region Propiedades
        public string ID { get; set; }
        public string Descripcion { get; set; }

        public DateTime FromDate { get; set; }

        public bool Vigente { get; set; }

        public DateTime ToDate { get; set; }

        public int QA { get; set; }


        private int _STA;
        public int STA

        {
            get { return _STA; }  
            set {
                    

                if (value == 0)
                {
                    MMBE?.Invoke(this, new ClsEvent0Stock(ID, Descripcion));
                }
                _STA = value;
            }
        }

        

        private string _vigencia;

        public string Vigencia
        {
            get { return _vigencia; }
            set { _vigencia = Convert.ToString(ObtenerVigencia(FromDate, ToDate)); }
        }


        public ClsCosto tipoCosto;

        public double CostoProd;

        #endregion

        #region metodos

        public int ObtenerVigencia(DateTime dsd,DateTime hasta)
        {
            
            var Dif = hasta-dsd;
            var vigencia = Math.Floor((double)Dif.Days / 30);
            if(vigencia < 0) {return 0;}

            return (int)vigencia;
        }

        public object Clone()
        {
            ClsProducto p = (ClsProducto)MemberwiseClone();
            return p;
        }

        

      

        public class DescrAsc : IComparer<ClsProducto>
        {

            public int Compare(ClsProducto x, ClsProducto y)
            {
                return String.Compare(x.Descripcion, y.Descripcion);
            }
        }
        public class DescDesc : IComparer<ClsProducto>
        {
            public int Compare(ClsProducto x, ClsProducto y)
            {
                return String.Compare(x.Descripcion, y.Descripcion) * -1;
            }
        }

        public class DescDescPD: IComparer<ClsProducto>
        {
            public int Compare(ClsProducto x, ClsProducto y)
            {
                return String.Compare(x.Vigencia, y.Vigencia) * -1;
            }
        }


        #endregion
    }
}
