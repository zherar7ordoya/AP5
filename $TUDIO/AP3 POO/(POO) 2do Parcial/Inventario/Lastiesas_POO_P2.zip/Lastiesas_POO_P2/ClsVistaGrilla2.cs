﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class ClsVistaGrilla2
    {

        private List<ClsVistaGrilla2> Lstg2;


        public string ID { get; set; }
        public string Descripcion { get; set; }
        public DateTime fechaAlta { get; set; }
        public DateTime fechaBaja { get; set; }
        public long MesesVigentes { get; set; }
        public bool EsVigente { get; set; }
        public double Costo { get; set; }
        public string DescripcionMetodo { get; set; }
        public int Stock { get; set; }


        public ClsVistaGrilla2()
        {
            Lstg2 = new List<ClsVistaGrilla2>();

        }

        public ClsVistaGrilla2(string pId, string pDesc, DateTime pFromD, DateTime ptoD, long pMesVig, bool pVigente, double pCosto, string pdescmetod, int pstock)
        {
            ID = pId;
            Descripcion = pDesc;
            fechaAlta = pFromD;
            fechaBaja = ptoD;
            MesesVigentes = pMesVig;
            EsVigente = pVigente;
            Costo = pCosto;
            DescripcionMetodo = pdescmetod;
            Stock = pstock;
        }


        public List<ClsVistaGrilla2> RetornaListaVistaProducto(List<ClsProducto> pLista)
        {
            Lstg2.Clear();
            foreach (ClsProducto P in pLista)
            {
                ClsProducto Pro = new ClsProducto();
                Pro = (ClsProducto)P;
                Lstg2.Add(new ClsVistaGrilla2(P.ID, P.Descripcion, P.FromDate, P.ToDate, P.ObtenerVigencia(P.FromDate, P.ToDate), P.Vigente, P.CostoProd, P.tipoCosto.Descripcion, P.STA));
            }
            return Lstg2;
        }

    }
}
