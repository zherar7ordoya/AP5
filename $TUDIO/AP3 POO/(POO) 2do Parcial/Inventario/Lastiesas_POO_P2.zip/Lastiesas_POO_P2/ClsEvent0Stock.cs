﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class ClsEvent0Stock :EventArgs
    {

        public string Codigo { get; set; }
        public string Descripcion { get; set; }


        public ClsEvent0Stock(string pCod, string pDescr)
        {
            Codigo = pCod;Descripcion = pDescr;
        }

    }
}
