﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class ClsCostoCP : ClsCosto
    {

        public ClsCostoCP(string pID, string pDescr) : base(pID, pDescr) { }

        public override double CalcularCosto(double pCUA, double pCP)
        {
       

            return ((pCP + pCUA) / 2) * 1.1;
        }

        public override double CalcularCosto(double pCUA, int pCP)
        {
            return ((pCP + pCUA) / 2) * 1.1;
        }

        public override double CalcularCosto(double pCPP, double pSTA, double pCUA, int pQA)
        {
            throw new Exception("el metodo no cumple con los parametros necesarios, este costo no corresponde a un CPP y se intenta usar ese costo.");
        }


    }
}
