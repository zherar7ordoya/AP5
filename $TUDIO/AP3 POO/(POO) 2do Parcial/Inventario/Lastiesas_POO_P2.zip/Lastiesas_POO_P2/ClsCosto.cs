﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public abstract class ClsCosto
    {
        #region propiedades
        public string IdCosto { get; set; }

        public string Descripcion { get; set; }

        public ClsCosto() { }

        public ClsCosto(string pID, string pDescr)
        {
            IdCosto = pID;
            Descripcion = pDescr;

        }

        #endregion


       #region  Metodos Abstractos
        public abstract double CalcularCosto(double a, int b); 

        public abstract double CalcularCosto(double pCPP, double pSTA, double pCUA, int pQA);

        public abstract double CalcularCosto(double a, double b);

        #endregion
    }
}
