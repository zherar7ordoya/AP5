﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace Lastiesas_POO_P2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dtgw1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgw2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        public ClsAlmacen Almacen = new ClsAlmacen();
        public ClsVistaGrilla1 LVG1 = new ClsVistaGrilla1();
        public ClsVistaGrilla2 LVG2 = new ClsVistaGrilla2();
        public Clsvistagrilla2st0 LVG2ST0 = new Clsvistagrilla2st0();
        public ClsVistaGrilla1 LVG1ER = new ClsVistaGrilla1();
        IComparer<ClsProducto> PRD;
        IComparer<ClsVistaGrilla1> VPRO;


        private void Form1_Load(object sender, EventArgs e)
        {
            CostoElegido.SelectedIndex = 0;
            txtPxQ.Text = Convert.ToString(0);
            PRD = new ClsProducto.DescDesc();
        }

        #region Metodos
        private void Mostrar(DataGridView dtgv, object O)
        {
            dtgv.DataSource = null;
            dtgv.DataSource = O;

        }

        private void MostrarSKUOrdenados()
        {
            try
            {

                dtgw2.DataSource = null;
                List<ClsProducto> LP = Almacen.RetornaClonListaProductos();
                List<ClsVistaGrilla1> VLP = LVG1.RetornaListaVistaProducto(LP).ToList<ClsVistaGrilla1>();
                VLP.Sort(VPRO);
                if (LVG1.RetornaListaVistaProducto(LP).Count() > 0)
                {
                    dtgw2.DataSource = VLP;
                }
              
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void MostrarSKUOrdenadosPE()
        {
            try
            {

                dtgw2.DataSource = null;
                List<ClsProducto> LP = Almacen.RetornaClonListaProductos();

                List<ClsVistaGrilla1> VLP = LVG1.RetornaListaVistaProducto(LP).ToList<ClsVistaGrilla1>();

                var v = from P in VLP where P.MesesVigentes != 0 orderby P.MesesVigentes ascending select P;
                dtgw2.DataSource = v.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private bool IsNumero(string pvalor)
        {
            int tmp = 0;
            return int.TryParse(pvalor, out tmp);
        }

        private bool Letter5num(string pvalor)
        {
            return !IsNumero(pvalor.Substring(0, 1)) && IsNumero(pvalor.Substring(1, 5));
        }        // valido que el is de producto tenga  una letra y 5 numeros

        private void dtgw1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtCantSt.Text = "";
            txtmontoCosto.Text = "";
            ClsVistaGrilla1 vg1 = new ClsVistaGrilla1();
            vg1 = (ClsVistaGrilla1)dtgw1.SelectedRows[0].DataBoundItem;
            ClsProducto prd = (ClsProducto)Almacen.RetornaProducto(vg1).Clone();
            txtProdId.Text = prd.ID;
            txtDescripcion.Text = prd.Descripcion;
            txtFromDate.Text = prd.FromDate.ToShortDateString();
            txtToDate.Text = prd.ToDate.ToShortDateString();
        }

        private void Limpiar()
        {
            txtProdId.Text = "";
            txtCantSt.Text = "";
            txtmontoCosto.Text = "";
            txtDescripcion.Text = "";
            txtFromDate.Text = "DD/MM/AAAA";
            txtToDate.Text = "";
            txtPxQ.Text = Almacen.SumatoriaStock(Convert.ToDouble(txtPxQ.Text));


        }

        private bool ValidarFecha(ClsProducto prod)
        {
            if ((prod.FromDate > prod.ToDate) && (prod.ToDate != DateTime.MinValue))
            {
                throw new Exception("La inicio de vigencia es mayor que la de fin de vigencia");
            }
            else
            {
                if (!(prod.ToDate < prod.FromDate))
                {
                    if (prod.FromDate < DateTime.Now && prod.ToDate < DateTime.Today)
                    {
                        prod.Vigente = false;
                        MessageBox.Show("producto no vigente. no se puede editar");
                        return false;

                    }

                    prod.Vigente = true;
                    return true;
                }
                else
                {
                    prod.Vigente = true ;
                    return true;
                }
            }
        }

        private void MostraSKUStock0()
        {
            try
            {
                dtgw2.DataSource = null;
                List<ClsProducto> SKU0 = Almacen.DevuelveSKUSinStock();
                if (Almacen.DevuelveSKUSinStock().Count > 0)
                {
                    dtgw2.DataSource = LVG2ST0.RetornaProductosEn0(SKU0).ToList<Clsvistagrilla2st0>();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);}
        }

        public void MMBE0(object sender, ClsEvent0Stock e)
        {
            MessageBox.Show("El Stock del producto ID: " + e.Codigo + " Descripción: " + e.Descripcion + "\n\n llegó a 0");
        }

        #endregion

        #region Botones
        private void btnAltaProd_Click(object sender, EventArgs e)
        {
            try
            {               
                DateTime fedsd1 = Convert.ToDateTime("01/01/2018");
                var a = txtProdId.Text;
                if (!(Letter5num(a)) && !(char.IsUpper(a.First())))//valido el formato
                {
                    throw new Exception( "Formato incorrecto");

                }
                if ( Convert.ToDateTime(txtFromDate.Text) <=  fedsd1) //valido fechas
                {
                    throw new Exception("productos pueden tener ser vigentes a partir del año 2018"); 
                }
                else
                {
                    ClsProducto Auxp = new ClsProducto();
                    Auxp.MMBE += MMBE0;
                    Auxp.ID = txtProdId.Text;
                    Auxp.Descripcion = txtDescripcion.Text;
                    Auxp.FromDate = Convert.ToDateTime(txtFromDate.Text);
                    if (txtToDate.Text == "" || txtToDate.Text== DateTime.MinValue.ToShortDateString()) { txtToDate.Text = "---"; } 
                    else { Auxp.ToDate = Convert.ToDateTime(txtToDate.Text); }
                    if (ValidarFecha(Auxp)) { Auxp.Vigente = true; }
                    Auxp.QA = Convert.ToInt32(txtCantSt.Text);

                    if (CostoElegido.SelectedIndex == 0)
                    {
                        LBLFormula.Visible = true;
                        
                        Auxp.tipoCosto = new ClsCostoCPP("CCP", "Costo Promedio Ponderado");
                        Auxp.CostoProd = 0.0;
                        Auxp.CostoProd = Auxp.tipoCosto.CalcularCosto(Auxp.CostoProd, 0, Convert.ToDouble(txtmontoCosto.Text), Auxp.QA);
                    }
                    else if (CostoElegido.SelectedIndex == 1)
                    {
                        Auxp.tipoCosto = new ClsCostoCUE("CUE", "Costo ultimo Entrado");
                        Auxp.CostoProd = Auxp.tipoCosto.CalcularCosto(Convert.ToDouble(txtmontoCosto.Text), Auxp.QA);
                        MessageBox.Show("costo CUE");
                    }
                    else if (CostoElegido.SelectedIndex == 2)
                    {

                        Auxp.tipoCosto = new ClsCostoCP("CP", "Costo Personalizado");
                        Auxp.CostoProd = Auxp.tipoCosto.CalcularCosto(Convert.ToDouble(txtmontoCosto.Text), Auxp.QA);
                        MessageBox.Show("costo CP");
                        
                    }

                    Almacen.AltaProducto(Auxp);
                    Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                    Limpiar();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); 
            }
        }

        private void btnModProd_Click(object sender, EventArgs e)
        {
            try
            {
                ClsVistaGrilla1 vg1 = new ClsVistaGrilla1();
                try
                {
                    vg1 = (ClsVistaGrilla1)dtgw1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception) { throw new Exception("no hay Productos"); }
                ClsProducto prod = (ClsProducto)Almacen.RetornaProducto(vg1).Clone();

                prod.ToDate = Convert.ToDateTime(txtToDate.Text);
                prod.Descripcion = txtDescripcion.Text;
                prod.FromDate= Convert.ToDateTime(txtFromDate.Text);

                if (ValidarFecha(prod))
                {

                    Almacen.ModificarProducto(prod);
                }
                Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                Limpiar();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnDelProd_Click(object sender, EventArgs e)
        {
            
            try
            {
                ClsVistaGrilla1 vg1 = new ClsVistaGrilla1();
                try
                {
                    vg1 = dtgw1.SelectedRows[0].DataBoundItem as ClsVistaGrilla1;
                }
                catch (Exception) { throw new Exception("no hay Productos"); }
                Almacen.BajaProducto(vg1);

                Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                Limpiar();
            }
            catch (Exception ex){MessageBox.Show(ex.Message);}

        }

        private void btnAgregarStock_Click(object sender, EventArgs e)
        {
            try
            {
                ClsVistaGrilla1 vg1 = new ClsVistaGrilla1();
                try
                {
                    vg1 = (ClsVistaGrilla1)dtgw1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception) { throw new Exception("no hay Productos"); }
                ClsProducto prod = (ClsProducto)Almacen.RetornaProducto(vg1).Clone();
                if (!ValidarFecha(prod)) { throw new Exception("producto fuera de vigencia, no se puede ajustar Stock"); }

                int nuevoStock;
                double CostAdq;
                if (txtCantSt.Text != "" && txtmontoCosto.Text != "")
                {
                    nuevoStock = Convert.ToInt32(txtCantSt.Text);
                    CostAdq = Convert.ToDouble(txtmontoCosto.Text);
                }
                else throw new Exception("ingrese SOLO Números");
                if (prod.tipoCosto is ClsCostoCP)
                {
                    prod.CostoProd = prod.tipoCosto.CalcularCosto(prod.CostoProd, CostAdq);
                    prod.STA = prod.STA + nuevoStock;
                    Almacen.AgregarStock(prod);
                    Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                    MessageBox.Show("costo CP");
                }
                else if (prod.tipoCosto is ClsCostoCPP)
                {
                    prod.CostoProd = prod.tipoCosto.CalcularCosto(prod.CostoProd, prod.STA, CostAdq, nuevoStock);
                    prod.STA = prod.STA + nuevoStock;
                    Almacen.AgregarStock(prod);
                    Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                    MessageBox.Show("costo CPP");
                }
                else if (prod.tipoCosto is ClsCostoCUE)
                {
                    prod.CostoProd = prod.tipoCosto.CalcularCosto(CostAdq, prod.STA);
                    prod.STA = prod.STA + nuevoStock;

                    Almacen.AgregarStock(prod);

                    Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                    MessageBox.Show("costo CUE");
                }
                txtPxQ.Text = Almacen.SumatoriaStock(Convert.ToDouble(txtPxQ.Text));

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnQuitarStock_Click(object sender, EventArgs e)
        {
            try
            {
                ClsVistaGrilla1 vg1 = new ClsVistaGrilla1();
                try
                {
                    vg1 = (ClsVistaGrilla1)dtgw1.SelectedRows[0].DataBoundItem;
                }
                catch (Exception) { throw new Exception("no hay Productos"); }
                ClsProducto prod = Almacen.RetornaArticulo(vg1.ID);
                if (!ValidarFecha(prod)) { throw new Exception("producto fuera de vigencia, no se puede ajustar Stock"); }
                var a = txtCantSt.Text;
                var b = prod.ToDate;
                if (txtCantSt.Text == "" && txtmontoCosto.Text == "") { throw new Exception("ingrese SOLO Números"); }


                if (prod.STA > 0)
                {
                    prod.STA = prod.STA - Convert.ToInt32(a);
                    Almacen.QuitarStock(prod);
                }

                Mostrar(dtgw1, LVG1.RetornaListaVistaProducto(Almacen.RetornaClonListaProductos()));
                txtPxQ.Text = Almacen.SumatoriaStock(Convert.ToDouble(txtPxQ.Text));

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnpuntoA_Click(object sender, EventArgs e)
        {
            try
            {
                dtgw2.DataSource = null;
                int Valor = int.Parse(Interaction.InputBox("Ingrese un valor: "));
                if (Valor > 0)
                {
                    //dtgw2.DataSource = null;
                    //dtgw2.DataSource = LVG1.RetornaListaVistaProducto(Almacen.ProductoValorMayor(Valor));
                    Mostrar(dtgw2, LVG1.RetornaListaVistaProducto(Almacen.ProductoValorMayor(Valor)));
                }
                else
                    throw new Exception("El valor ingresado  no puede ser igual o menor a 0.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPuntoB_Click(object sender, EventArgs e)
        {
            MostraSKUStock0();
        }

        private void rbAscendente_CheckedChanged(object sender, EventArgs e)
        {
            VPRO = new ClsVistaGrilla1.DescrAsc();
            MostrarSKUOrdenados();
        }

        private void rbDescendente_CheckedChanged(object sender, EventArgs e)
        {
            VPRO = new ClsVistaGrilla1.DescDesc();
            MostrarSKUOrdenados();
        }

        private void btnPuntoE_Click(object sender, EventArgs e)
        {
            try
            {
                int aux1 = int.Parse(Interaction.InputBox("Ingrese un valor: "));
                int aux2 = int.Parse(Interaction.InputBox("Ingrese otro valor: "));
                if (aux1 > 0 && aux2 > 0 && aux2 > aux1)
                {
                    var p = Almacen.ValidarRango(aux1, aux2);
                    Mostrar(dtgw2, p);
                }
                else
                    throw new Exception("El primer valor ingresado no debe superar el segundo ni ser cero ");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnpuntoD_Click(object sender, EventArgs e)
        {
            try
            {
                PRD = new ClsProducto.DescDescPD();
                MostrarSKUOrdenadosPE();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }

    #endregion



}
