﻿namespace Lastiesas_POO_P2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dtgw1 = new System.Windows.Forms.DataGridView();
            this.dtgw2 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbDescendente = new System.Windows.Forms.RadioButton();
            this.rbAscendente = new System.Windows.Forms.RadioButton();
            this.btnPuntoE = new System.Windows.Forms.Button();
            this.btnpuntoD = new System.Windows.Forms.Button();
            this.btnPuntoB = new System.Windows.Forms.Button();
            this.btnpuntoA = new System.Windows.Forms.Button();
            this.txtPxQ = new System.Windows.Forms.TextBox();
            this.btnAltaProd = new System.Windows.Forms.Button();
            this.btnModProd = new System.Windows.Forms.Button();
            this.btnDelProd = new System.Windows.Forms.Button();
            this.btnAgregarStock = new System.Windows.Forms.Button();
            this.btnQuitarStock = new System.Windows.Forms.Button();
            this.txtCantSt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProdId = new System.Windows.Forms.TextBox();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFechafin = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.CostoElegido = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtmontoCosto = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFromDate = new System.Windows.Forms.TextBox();
            this.txtToDate = new System.Windows.Forms.TextBox();
            this.LBLFormula = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgw1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgw2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgw1
            // 
            this.dtgw1.AllowUserToDeleteRows = false;
            this.dtgw1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgw1.Location = new System.Drawing.Point(11, 14);
            this.dtgw1.Name = "dtgw1";
            this.dtgw1.ReadOnly = true;
            this.dtgw1.Size = new System.Drawing.Size(321, 177);
            this.dtgw1.TabIndex = 0;
            this.dtgw1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgw1_CellMouseClick);
            // 
            // dtgw2
            // 
            this.dtgw2.AllowUserToAddRows = false;
            this.dtgw2.AllowUserToDeleteRows = false;
            this.dtgw2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgw2.Location = new System.Drawing.Point(11, 267);
            this.dtgw2.Name = "dtgw2";
            this.dtgw2.ReadOnly = true;
            this.dtgw2.Size = new System.Drawing.Size(556, 171);
            this.dtgw2.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbDescendente);
            this.groupBox1.Controls.Add(this.rbAscendente);
            this.groupBox1.Controls.Add(this.btnPuntoE);
            this.groupBox1.Controls.Add(this.btnpuntoD);
            this.groupBox1.Controls.Add(this.btnPuntoB);
            this.groupBox1.Controls.Add(this.btnpuntoA);
            this.groupBox1.Location = new System.Drawing.Point(573, 260);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(205, 178);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "puntos de LinQ";
            // 
            // rbDescendente
            // 
            this.rbDescendente.AutoSize = true;
            this.rbDescendente.Location = new System.Drawing.Point(99, 80);
            this.rbDescendente.Name = "rbDescendente";
            this.rbDescendente.Size = new System.Drawing.Size(89, 17);
            this.rbDescendente.TabIndex = 6;
            this.rbDescendente.TabStop = true;
            this.rbDescendente.Text = "Descendente";
            this.rbDescendente.UseVisualStyleBackColor = true;
            this.rbDescendente.CheckedChanged += new System.EventHandler(this.rbDescendente_CheckedChanged);
            // 
            // rbAscendente
            // 
            this.rbAscendente.AutoSize = true;
            this.rbAscendente.Location = new System.Drawing.Point(7, 80);
            this.rbAscendente.Name = "rbAscendente";
            this.rbAscendente.Size = new System.Drawing.Size(82, 17);
            this.rbAscendente.TabIndex = 5;
            this.rbAscendente.TabStop = true;
            this.rbAscendente.Text = "Ascendente";
            this.rbAscendente.UseVisualStyleBackColor = true;
            this.rbAscendente.CheckedChanged += new System.EventHandler(this.rbAscendente_CheckedChanged);
            // 
            // btnPuntoE
            // 
            this.btnPuntoE.Location = new System.Drawing.Point(7, 133);
            this.btnPuntoE.Name = "btnPuntoE";
            this.btnPuntoE.Size = new System.Drawing.Size(192, 23);
            this.btnPuntoE.TabIndex = 4;
            this.btnPuntoE.Text = "mostrar Art. C/ Stock e/ Rango";
            this.btnPuntoE.UseVisualStyleBackColor = true;
            this.btnPuntoE.Click += new System.EventHandler(this.btnPuntoE_Click);
            // 
            // btnpuntoD
            // 
            this.btnpuntoD.Location = new System.Drawing.Point(7, 108);
            this.btnpuntoD.Name = "btnpuntoD";
            this.btnpuntoD.Size = new System.Drawing.Size(192, 23);
            this.btnpuntoD.TabIndex = 3;
            this.btnpuntoD.Text = "Mostrar articulos con fecha de baja";
            this.btnpuntoD.UseVisualStyleBackColor = true;
            this.btnpuntoD.Click += new System.EventHandler(this.btnpuntoD_Click);
            // 
            // btnPuntoB
            // 
            this.btnPuntoB.Location = new System.Drawing.Point(7, 50);
            this.btnPuntoB.Name = "btnPuntoB";
            this.btnPuntoB.Size = new System.Drawing.Size(192, 23);
            this.btnPuntoB.TabIndex = 1;
            this.btnPuntoB.Text = "Mostrar Stock en 0";
            this.btnPuntoB.UseVisualStyleBackColor = true;
            this.btnPuntoB.Click += new System.EventHandler(this.btnPuntoB_Click);
            // 
            // btnpuntoA
            // 
            this.btnpuntoA.Location = new System.Drawing.Point(7, 20);
            this.btnpuntoA.Name = "btnpuntoA";
            this.btnpuntoA.Size = new System.Drawing.Size(192, 23);
            this.btnpuntoA.TabIndex = 0;
            this.btnpuntoA.Text = "mostrar Stock mayor a num";
            this.btnpuntoA.UseVisualStyleBackColor = true;
            this.btnpuntoA.Click += new System.EventHandler(this.btnpuntoA_Click);
            // 
            // txtPxQ
            // 
            this.txtPxQ.Location = new System.Drawing.Point(128, 201);
            this.txtPxQ.Name = "txtPxQ";
            this.txtPxQ.Size = new System.Drawing.Size(203, 20);
            this.txtPxQ.TabIndex = 3;
            // 
            // btnAltaProd
            // 
            this.btnAltaProd.Location = new System.Drawing.Point(527, 11);
            this.btnAltaProd.Name = "btnAltaProd";
            this.btnAltaProd.Size = new System.Drawing.Size(111, 27);
            this.btnAltaProd.TabIndex = 4;
            this.btnAltaProd.Text = "Alta Producto";
            this.btnAltaProd.UseVisualStyleBackColor = true;
            this.btnAltaProd.Click += new System.EventHandler(this.btnAltaProd_Click);
            // 
            // btnModProd
            // 
            this.btnModProd.Location = new System.Drawing.Point(527, 44);
            this.btnModProd.Name = "btnModProd";
            this.btnModProd.Size = new System.Drawing.Size(111, 27);
            this.btnModProd.TabIndex = 5;
            this.btnModProd.Text = "Modificar Producto";
            this.btnModProd.UseVisualStyleBackColor = true;
            this.btnModProd.Click += new System.EventHandler(this.btnModProd_Click);
            // 
            // btnDelProd
            // 
            this.btnDelProd.Location = new System.Drawing.Point(527, 77);
            this.btnDelProd.Name = "btnDelProd";
            this.btnDelProd.Size = new System.Drawing.Size(111, 27);
            this.btnDelProd.TabIndex = 6;
            this.btnDelProd.Text = "Borrar Producto";
            this.btnDelProd.UseVisualStyleBackColor = true;
            this.btnDelProd.Click += new System.EventHandler(this.btnDelProd_Click);
            // 
            // btnAgregarStock
            // 
            this.btnAgregarStock.Location = new System.Drawing.Point(644, 12);
            this.btnAgregarStock.Name = "btnAgregarStock";
            this.btnAgregarStock.Size = new System.Drawing.Size(92, 27);
            this.btnAgregarStock.TabIndex = 7;
            this.btnAgregarStock.Text = "Agregar Stock";
            this.btnAgregarStock.UseVisualStyleBackColor = true;
            this.btnAgregarStock.Click += new System.EventHandler(this.btnAgregarStock_Click);
            // 
            // btnQuitarStock
            // 
            this.btnQuitarStock.Location = new System.Drawing.Point(644, 45);
            this.btnQuitarStock.Name = "btnQuitarStock";
            this.btnQuitarStock.Size = new System.Drawing.Size(92, 27);
            this.btnQuitarStock.TabIndex = 8;
            this.btnQuitarStock.Text = "Quitar Stock";
            this.btnQuitarStock.UseVisualStyleBackColor = true;
            this.btnQuitarStock.Click += new System.EventHandler(this.btnQuitarStock_Click);
            // 
            // txtCantSt
            // 
            this.txtCantSt.Location = new System.Drawing.Point(742, 33);
            this.txtCantSt.Name = "txtCantSt";
            this.txtCantSt.Size = new System.Drawing.Size(54, 20);
            this.txtCantSt.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(742, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Cantidad";
            // 
            // txtProdId
            // 
            this.txtProdId.Location = new System.Drawing.Point(348, 21);
            this.txtProdId.Name = "txtProdId";
            this.txtProdId.Size = new System.Drawing.Size(157, 20);
            this.txtProdId.TabIndex = 11;
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(348, 63);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(157, 20);
            this.txtDescripcion.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(345, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Id Producto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(345, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Descripcion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(345, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Fecha Inicio Validez";
            // 
            // lblFechafin
            // 
            this.lblFechafin.AutoSize = true;
            this.lblFechafin.Location = new System.Drawing.Point(345, 129);
            this.lblFechafin.Name = "lblFechafin";
            this.lblFechafin.Size = new System.Drawing.Size(91, 13);
            this.lblFechafin.TabIndex = 18;
            this.lblFechafin.Text = "Fecha Fin Validez";
            // 
            // CostoElegido
            // 
            this.CostoElegido.FormattingEnabled = true;
            this.CostoElegido.Items.AddRange(new object[] {
            "CCP",
            "CUE",
            "CP"});
            this.CostoElegido.Location = new System.Drawing.Point(644, 90);
            this.CostoElegido.Name = "CostoElegido";
            this.CostoElegido.Size = new System.Drawing.Size(66, 21);
            this.CostoElegido.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(644, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "calculo costo";
            // 
            // txtmontoCosto
            // 
            this.txtmontoCosto.Location = new System.Drawing.Point(742, 91);
            this.txtmontoCosto.Name = "txtmontoCosto";
            this.txtmontoCosto.Size = new System.Drawing.Size(54, 20);
            this.txtmontoCosto.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(742, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "monto";
            // 
            // txtFromDate
            // 
            this.txtFromDate.Location = new System.Drawing.Point(348, 105);
            this.txtFromDate.Name = "txtFromDate";
            this.txtFromDate.Size = new System.Drawing.Size(159, 20);
            this.txtFromDate.TabIndex = 23;
            this.txtFromDate.Text = "DD/MM/AAAA";
            // 
            // txtToDate
            // 
            this.txtToDate.Location = new System.Drawing.Point(348, 145);
            this.txtToDate.Name = "txtToDate";
            this.txtToDate.Size = new System.Drawing.Size(159, 20);
            this.txtToDate.TabIndex = 24;
            // 
            // LBLFormula
            // 
            this.LBLFormula.AutoSize = true;
            this.LBLFormula.Location = new System.Drawing.Point(37, 235);
            this.LBLFormula.Name = "LBLFormula";
            this.LBLFormula.Size = new System.Drawing.Size(640, 13);
            this.LBLFormula.TabIndex = 25;
            this.LBLFormula.Text = "La formula de promedio ponderado estaba mal y dividia por 0. revise y es el sigui" +
    "ente formato:  ((CPP * STA) + (CUA * QA)) / (STA+QA)";
            this.LBLFormula.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LBLFormula);
            this.Controls.Add(this.txtToDate);
            this.Controls.Add(this.txtFromDate);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtmontoCosto);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.CostoElegido);
            this.Controls.Add(this.lblFechafin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.txtProdId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCantSt);
            this.Controls.Add(this.btnQuitarStock);
            this.Controls.Add(this.btnAgregarStock);
            this.Controls.Add(this.btnDelProd);
            this.Controls.Add(this.btnModProd);
            this.Controls.Add(this.btnAltaProd);
            this.Controls.Add(this.txtPxQ);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dtgw2);
            this.Controls.Add(this.dtgw1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgw1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgw2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgw1;
        private System.Windows.Forms.DataGridView dtgw2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPuntoE;
        private System.Windows.Forms.Button btnpuntoD;
        private System.Windows.Forms.Button btnPuntoB;
        private System.Windows.Forms.Button btnpuntoA;
        private System.Windows.Forms.TextBox txtPxQ;
        private System.Windows.Forms.Button btnAltaProd;
        private System.Windows.Forms.Button btnModProd;
        private System.Windows.Forms.Button btnDelProd;
        private System.Windows.Forms.Button btnAgregarStock;
        private System.Windows.Forms.Button btnQuitarStock;
        private System.Windows.Forms.TextBox txtCantSt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProdId;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblFechafin;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.ComboBox CostoElegido;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtmontoCosto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFromDate;
        private System.Windows.Forms.TextBox txtToDate;
        private System.Windows.Forms.Label LBLFormula;
        private System.Windows.Forms.RadioButton rbDescendente;
        private System.Windows.Forms.RadioButton rbAscendente;
    }
}

