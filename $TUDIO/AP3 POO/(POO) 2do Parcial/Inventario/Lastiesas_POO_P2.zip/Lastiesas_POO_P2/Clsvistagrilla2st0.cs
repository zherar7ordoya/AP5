﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
    public class Clsvistagrilla2st0
    {

        private List<Clsvistagrilla2st0> LstProdVal0;
        private List<Clsvistagrilla2st0> LstValores;

        public int ID { get; set; }
        public string descripcion { get; set; }
        public int STA { get; set; }


        public Clsvistagrilla2st0() { LstProdVal0 = new List<Clsvistagrilla2st0>(); LstValores = new List<Clsvistagrilla2st0>(); }
        public Clsvistagrilla2st0(string pdescripcion)
        {
            descripcion = pdescripcion;

        }

        public List<Clsvistagrilla2st0> RetornaProductosEn0(List<ClsProducto> pLista)
        {
            LstProdVal0.Clear();
            foreach (ClsProducto P in pLista)
            {
                ClsProducto Pro0 = new ClsProducto();
                Pro0 = (ClsProducto)P;
                LstProdVal0.Add(new Clsvistagrilla2st0(P.Descripcion));
            }
            return LstProdVal0;
        }


    }
}
