﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lastiesas_POO_P2
{
   public class ClsCostoCUE: ClsCosto
    {

        public int sta { get; set; }
        public double cst { get; set; }

        public ClsCostoCUE(string pID, string pDescr) : base(pID, pDescr) { }

        public ClsCostoCUE(string pID, string pDescr, int psta, double pcst): base( pID, pDescr)
        {
            sta = psta;
            cst = pcst;

        }

        public ClsProducto producto { get; set; }
        public override double CalcularCosto(double pCUA, int pSTA)
        {


            return pCUA;
        }

        public override double CalcularCosto(double pCPP, double pSTA, double pCUA, int pQA)
        {
            throw new Exception("el metodo no cumple con los parametros necesarios, este costo no corresponde a un CPP y se intenta usar ese costo.");
        }

        public override double CalcularCosto(double a, double b)
        {
            throw new Exception("el metodo no cumple con los parametros necesarios, este costo no corresponde a un CP y se intenta usar ese costo.");
        }
    }
}
