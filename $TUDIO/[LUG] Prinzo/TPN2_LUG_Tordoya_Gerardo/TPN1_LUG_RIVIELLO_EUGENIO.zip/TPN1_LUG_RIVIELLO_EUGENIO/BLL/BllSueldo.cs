﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using MPP;
using Abstraccion;

namespace BLL
{
    public class BllSueldo : IGestor<BeSueldo>
    {
        public BllSueldo()
        {
            mpp = new MPPSueldo();
        }

        MPPSueldo mpp;

        public bool Guardar(BeSueldo be)
        {
            return mpp.Guardar(be);
        }


        public List<BeSueldo> ListarTodo()
        {
            return mpp.ListarTodo();
        }

        public bool Modificar(BeEmpleado be)
        {
            throw new NotImplementedException();
        }

        public bool Borrar(BeSueldo be)
        {
            throw new NotImplementedException();
        }
        public bool GuardarTablaIntermedia(BeSueldo bs, BeEmpleado be)
        {
            return mpp.GuardarTablaIntermedia(bs, be);
        }
    }
}
