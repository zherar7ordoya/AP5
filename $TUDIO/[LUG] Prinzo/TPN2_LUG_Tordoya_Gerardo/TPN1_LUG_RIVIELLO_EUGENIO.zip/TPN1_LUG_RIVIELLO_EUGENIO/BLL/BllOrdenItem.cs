﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using MPP;
using Abstraccion;

namespace BLL
{
    public class BllOrdenItem
    {

        public BllOrdenItem()
        {
            bll = new BllEmpleado();
            bllp = new BllProducto();
            be = new BeEmpleado();
        }
        BllEmpleado bll;
        BllProducto bllp;
        BeEmpleado be;
       
        public List<BeProducto> ListaProduct()
        {
            be.ListaProductos = new List<BeProducto>();
            foreach (BeEmpleado emp in bll.ListarTodo())
            {
                if (emp.NumCodigo != 0)
                {
                    foreach (BeProducto prod in bllp.ListarTodo())
                    {
                        if (prod.Codigo == emp.NumCodigo)
                        {
                            prod.Nombre = emp.Nombre;
                            be.ListaProductos.Add(prod);
                        }
                    }
                }
            }
            return be.ListaProductos;
        }
      
    }
}
