﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using MPP;
using Abstraccion;

namespace BLL
{
    public class BllJefeDepartamento : BllEmpleado,  IGestor<BeEmpleado>
    {
        public override int Sueldo(int horas, int extras)
        {
            int valorHora = 1100;
            return (valorHora * horas) + extras;
        }

        public BllJefeDepartamento()
        {
            mpp = new MPPJefeDepartamento();
        }

        MPPJefeDepartamento mpp;

        public bool Guardar(BeJefeDepartamento be)
        {
            return mpp.Guardar(be);
        }


        public List<BeEmpleado> ListarTodo()
        {
            return mpp.ListarTodo();
        }

        public bool Modificar(BeJefeDepartamento be)
        {
            return mpp.Guardar(be);
        }

        public bool Borrar(BeEmpleado be)
        {
            return mpp.Borrar(be);
        }
    }
}
