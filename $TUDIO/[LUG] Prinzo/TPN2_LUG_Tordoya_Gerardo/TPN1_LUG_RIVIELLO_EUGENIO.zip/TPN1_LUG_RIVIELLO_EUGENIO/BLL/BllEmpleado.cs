﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using MPP;
using Abstraccion;
using System.Text.RegularExpressions;

namespace BLL
{
    public class BllEmpleado : IGestor<BeEmpleado>
    {

         public virtual int Sueldo(int horas, int extras) 
        {
            int valorHora = 500;
            return (valorHora * horas) + extras;
        }

        public BllEmpleado()
        {
            mpp = new MPPEmpleado();
        }

        MPPEmpleado mpp;
        List<BllEmpleado> list = new List<BllEmpleado>();
        
        public bool Guardar(BeEmpleado be)
        {
            return mpp.Guardar(be);
        }


        public List<BeEmpleado> ListarTodo()
        {
            return mpp.ListarTodo();
        }

        public bool Modificar(BeEmpleado be)
        {
            return mpp.Guardar(be);
        }

        public bool Borrar(BeEmpleado be)
        {
            return mpp.Borrar(be);
        }
               
        public Boolean email_bien_escrito(string email)
        {
            string expresion;
            expresion = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            if (Regex.IsMatch(email, expresion))
            {
                if (Regex.Replace(email, expresion, string.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }       
    }
}
