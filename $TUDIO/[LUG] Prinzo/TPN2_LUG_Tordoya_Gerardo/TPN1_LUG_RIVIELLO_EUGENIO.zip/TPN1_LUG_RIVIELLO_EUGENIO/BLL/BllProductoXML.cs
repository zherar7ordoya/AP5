﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using MPP;
using Abstraccion;
using System.Windows.Forms;

namespace BLL
{
    public class BllProductoXML : IGestor<BeProducto>
    {
        public BllProductoXML()
        {
            mpp = new MPPProductoXML();
        }
        MPPProductoXML mpp;

        public bool Guardar(BeProducto bp)
        {
            return mpp.Guardar(bp);
        }
        public List<BeProducto> ListarTodo()
        {
            return mpp.ListarTodos();
        }

        public bool Modificar(BeProducto bp)
        {
            return mpp.Modificar(bp);
        }
        public bool Borrar(BeProducto bp)
        {
            return mpp.Borrar(bp);
        }

        public List<BeProducto> ListaProducto(string nomProp)
        {
            return mpp.BuscarXNombre(nomProp);
        }


        public bool Comparar(TextBox text)
        {
            foreach (BeProducto auxbp in ListarTodo())
            {
                if (auxbp.Codigo.ToString().Contains(text.Text))
                {
                    MessageBox.Show("El numero de codigo " + text.Text + " ya exise. Ingrese uno nuevo");
                    return true;
                }
            }
            return false;
        }
    }
}
