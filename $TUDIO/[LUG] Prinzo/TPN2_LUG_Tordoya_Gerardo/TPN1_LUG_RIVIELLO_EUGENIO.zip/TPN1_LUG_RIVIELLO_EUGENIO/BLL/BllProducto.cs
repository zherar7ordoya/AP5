﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using MPP;
using Abstraccion;

namespace BLL
{
    public class BllProducto : IGestor<BeProducto>
    {
        public BllProducto()
        {
            mpp = new MPPProducto();
        }
        MPPProducto mpp;
      
        public bool Guardar(BeProducto bp)
        {
            return mpp.Guardar(bp);
        }
        public List<BeProducto> ListarTodo()
        {
            return mpp.ListarTodo();
        }

        public bool Modificar(BeProducto bp)
        {
            return mpp.Guardar(bp);
        }
        public bool Borrar(BeProducto bp)
        {
            return mpp.Borrar(bp);
        }

        
        
        public bool Comparar(TextBox text)
        {
            foreach (BeProducto auxbp in ListarTodo())
            {
                if (auxbp.NumeroProducto.ToString().Contains(text.Text))
                {
                    MessageBox.Show("El numero de producto " + text.Text + " ya exise. Ingrese uno nuevo");
                    return true;
                }
            }
            return false;
        }
    }
}
