﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using MPP;
using Abstraccion;

namespace BLL
{
    public class BllJefeCompra : BllEmpleado, IGestor<BeEmpleado>
    {
        public override int Sueldo(int horas, int extras)
        {
            int valorHora = 800;
            return (valorHora * horas) + extras;
        }

        public BllJefeCompra()
        {
            mpp = new MPPJefeCompra();
        }

       
        MPPJefeCompra mpp;

        public bool Guardar(BeJefeCompra be)
        {
            return mpp.Guardar(be);
        }


        public List<BeEmpleado> ListarTodo()
        {
            return mpp.ListarTodo();
        }

        public bool Modificar(BeJefeCompra be)
        {
            return mpp.Guardar(be);
        }

        public bool Borrar(BeEmpleado be)
        {
            return mpp.Borrar(be);
        }
    }
}
