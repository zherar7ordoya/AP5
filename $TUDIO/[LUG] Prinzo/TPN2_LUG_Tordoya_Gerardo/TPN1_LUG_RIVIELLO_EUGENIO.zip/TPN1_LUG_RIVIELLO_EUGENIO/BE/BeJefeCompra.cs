﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BeJefeCompra : BeEmpleado
    {
       public string Titulo { get; set; }

        public BeJefeCompra()
        {

        }
        public BeJefeCompra(string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento, string pEmail,
                          string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, string pTitulo)
        {
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            Titulo = pTitulo;
        }

        public BeJefeCompra(int pCodigo, string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento,
                          string pEmail, string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, string pTitulo)
        {
            Codigo = pCodigo;
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            Titulo = pTitulo;
        }

        public BeJefeCompra(int pCodigo, string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento,
                          string pEmail, string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, int pCodProducto, string pTitulo)
        {
            Codigo = pCodigo;
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            NumCodigo = pCodProducto;
            Titulo = pTitulo;
        }
    }
}
