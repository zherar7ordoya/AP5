﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BeSueldo : Entidad
    {
       

        public BeEmpleado oEmpleado { get; set; }

        public BeSueldo() { }

        public BeSueldo(string pNombre, int pSueldo)
        {
            oEmpleado = new BeEmpleado();
            oEmpleado.Nombre = pNombre;
            oEmpleado.Sueldo = pSueldo;
        }

        public BeSueldo(int pCodSueldo, string pNombre, int pSueldo)
        {
            oEmpleado = new BeEmpleado();
            Codigo = pCodSueldo;
            oEmpleado.Nombre = pNombre;
            oEmpleado.Sueldo = pSueldo;
        }
    }
}
