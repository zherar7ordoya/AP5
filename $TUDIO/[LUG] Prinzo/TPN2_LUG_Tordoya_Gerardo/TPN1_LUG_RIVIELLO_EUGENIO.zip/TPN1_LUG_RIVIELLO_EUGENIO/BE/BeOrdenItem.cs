﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BeOrdenItem : Entidad
    {
        
        public string NombreEmpleado { get; set; }
        public int NumeroOrden { get; set; }
        public DateTime FechaOrden { get; set; }
        public string Estado { get; set; }
        public int NumeroProducto { get; set; }
        public int Cantidad { get; set; }
        public int PrecioUnitario { get; set; }

        public BeOrdenItem() { }

        public BeOrdenItem(String pNombreEmpleado, int pNumeroOrden, DateTime pFechaOrden, string pEstado, int pNumeroProducto, int pCantidad,
                           int pPrecioUnitario)
        {
            NombreEmpleado = pNombreEmpleado;
            NumeroOrden = pNumeroOrden;
            FechaOrden = pFechaOrden;
            Estado = pEstado;
            NumeroProducto = pNumeroProducto;
            Cantidad = pCantidad;
            PrecioUnitario = pPrecioUnitario;
        }

        public BeOrdenItem(int pCodigo, string pNombreEmpleado, int pNumeroOrden, DateTime pFechaOrden, string pEstado, int pNumeroProducto, int pCantidad,
                          int pPrecioUnitario)
        {
            Codigo = pCodigo;
            NombreEmpleado = pNombreEmpleado;
            NumeroOrden = pNumeroOrden;
            FechaOrden = pFechaOrden;
            Estado = pEstado;
            NumeroProducto = pNumeroProducto;
            Cantidad = pCantidad;
            PrecioUnitario = pPrecioUnitario;
        }
    }
}
