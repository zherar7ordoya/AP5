﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BeJefeDepartamento : BeEmpleado
    {        
        public string Departamento { get; set; }

        public BeJefeDepartamento()
        {

        }
        public BeJefeDepartamento(string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento, string pEmail,
                          string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, string pDepartamento)
        {
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            Departamento = pDepartamento;
        }

        public BeJefeDepartamento(int pCodigo, string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento,
                          string pEmail, string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, string pDepartamento)
        {
            Codigo = pCodigo;
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            Departamento = pDepartamento;
        }

        public BeJefeDepartamento(int pCodigo, string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento,
                          string pEmail, string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, int pCodProducto, string pDepartamento)
        {
            Codigo = pCodigo;
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            NumCodigo = pCodProducto;
            Departamento = pDepartamento;
        }
    }
}
