﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BeEmpleado : Entidad
    {       
        
        public BeUsuario oUsu { get; set; }
        public string Nombre { get; set; }
        public int Dni { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public  string Email { get; set; }       
        public string NombreDepartamento { get; set; }
        public string Calle { get; set; }
        public int NumeroAltura { get; set; }
        public string Localidad { get; set; }
        public string Provincia { get; set; }
        public int CodigoPostal { get; set; }
        public string Puesto { get; set; }
        public int NumCodigo { get; set; }
        public int Sueldo { get; set; }

        public List<BeProducto> ListaProductos { get; set; }



        public BeEmpleado()
        {

        }
        public BeEmpleado(string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento, string pEmail,
                          string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto)
        {            
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;            
            NombreDepartamento = pNombreDepartamento;           
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
        }

        public BeEmpleado(int pCodigo, string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento, 
                          string pEmail, string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto)
        {
            Codigo = pCodigo;           
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
        }

        public BeEmpleado(int pCodigo, string pUsuario, string pPassword, string pNombre, int pDni, DateTime pFechaNacimiento, 
                          string pEmail, string pNombreDepartamento, string pCalle, int pNumeroAltura, string pLocalidad,
                          string pProvincia, int pCodigoPostal, string pPuesto, int pCodProducto)
        {
            Codigo = pCodigo;
            oUsu = new BeUsuario(pUsuario, pPassword);
            Nombre = pNombre;
            Dni = pDni;
            FechaNacimiento = pFechaNacimiento;
            Email = pEmail;
            NombreDepartamento = pNombreDepartamento;
            Calle = pCalle;
            NumeroAltura = pNumeroAltura;
            Localidad = pLocalidad;
            Provincia = pProvincia;
            CodigoPostal = pCodigoPostal;
            Puesto = pPuesto;
            NumCodigo = pCodProducto;           
        }

        public override string ToString()
        {
            return Nombre + " " + Sueldo.ToString();
        }

    }
}
