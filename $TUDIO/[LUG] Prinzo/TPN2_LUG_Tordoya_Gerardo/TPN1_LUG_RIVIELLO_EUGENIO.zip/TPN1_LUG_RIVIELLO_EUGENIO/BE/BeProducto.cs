﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BeProducto : Entidad
    {

        public int NumeroProducto { get; set; }
        public string NombreProducto { get; set; }
        public string Categoria { get; set; }
        public string Descripcion { get; set; }
        public double PrecioUnitario { get; set; }
        public int CodigoVendedor { get; set; }
        public string Nombre { get; set; }

        public BeProducto() { }

        public BeProducto(int pNumeroProducto)
        {
            NumeroProducto = pNumeroProducto;
        } 

        public BeProducto(int pNumeroProducto, string pNombreProducto, string pCategoria, string pDescripcion, double pPrecioUnitario, int pCodigoVendedor) 
        {
            NumeroProducto = pNumeroProducto;
            NombreProducto = pNombreProducto;
            Categoria = pCategoria;
            Descripcion = pDescripcion;
            PrecioUnitario = pPrecioUnitario;
            CodigoVendedor = pCodigoVendedor;
        }

        public BeProducto(int pCodigo, int pNumeroProducto, string pNombreProducto, string pCategoria, string pDescripcion, double pPrecioUnitario, int pCodigoVendedor)
        {
            Codigo = pCodigo;
            NumeroProducto = pNumeroProducto;
            NombreProducto = pNombreProducto;
            Categoria = pCategoria;
            Descripcion = pDescripcion;
            PrecioUnitario = pPrecioUnitario;
            CodigoVendedor = pCodigoVendedor;
        }

        public override string ToString()
        {
            return Codigo + " " + NumeroProducto + " " + NombreProducto + " " + Categoria + " " + Descripcion + " " + PrecioUnitario + " " + CodigoVendedor;
        }
    }
}
