﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using BLL;

namespace IU
{
    public partial class UIAbmEmpleado : Form
    {
        public UIAbmEmpleado()
        {
            InitializeComponent();
            be = new BeEmpleado();
            bll = new BllEmpleado();
            blljc = new BllJefeCompra();
            blljd = new BllJefeDepartamento();
            bejc = new BeJefeCompra();
            bejd = new BeJefeDepartamento();
            rdgv = new RefreshDgv();
            bllUsu = new BllUsuario();
           
        }
        
        BeEmpleado be;
        BllEmpleado bll;
        RefreshDgv rdgv;
        BllUsuario bllUsu;
        BllJefeCompra blljc;
        BllJefeDepartamento blljd;
        BeJefeCompra bejc;
        BeJefeDepartamento bejd;

        private void btnEmpleadoAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                string pass = BllUsuario.GetSHA256(txtPassword.Text);

                BeUsuario user = new BeUsuario();
                user.NombreUsuario = txtNomUser.Text;
                user.Password = pass;


                if (PuestoEmpleado().ToString() == "Empleado")
                {
                    be = new BeEmpleado(user.NombreUsuario, user.Password, txtNomApe.Text, int.Parse(txtDni.Text), dtpFechaNacimineto.Value,
                                   txtEmail.Text, txtNombreDepart.Text, txtCalle.Text, int.Parse(txtNumero.Text), txtLocalidad.Text,
                                   userControlProvincia1.ToString(), int.Parse(txtCodigoPostal.Text), PuestoEmpleado());

                    if (bll.email_bien_escrito(txtEmail.Text) == true)
                    {
                        bll.Guardar(be);
                        VaciarTextBox();
                        rdgv.Refresh(dgvEmpleados, bll.ListarTodo());
                        dgvEmpleados.Columns["oUsu"].Visible = false;
                        dgvEmpleados.Columns["Codigo"].Visible = false;
                        dgvEmpleados.Columns["NumCodigo"].Visible = false;
                        dgvEmpleados.Columns["Sueldo"].Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Ese no es una cuenta de mail");
                        txtEmail.Text = null;
                    }
                }
                else if (PuestoEmpleado() == "Jefe de compras")
                {
                    bejc = new BeJefeCompra(user.NombreUsuario, user.Password, txtNomApe.Text, int.Parse(txtDni.Text), dtpFechaNacimineto.Value,
                                   txtEmail.Text, txtNombreDepart.Text, txtCalle.Text, int.Parse(txtNumero.Text), txtLocalidad.Text,
                                    userControlProvincia1.ToString(), int.Parse(txtCodigoPostal.Text), PuestoEmpleado(),
                                    txtAux.Text);

                    if (blljc.email_bien_escrito(txtEmail.Text) == true)
                    {
                        blljc.Guardar(bejc);
                        VaciarTextBox();
                        rdgv.Refresh(dgvEmpleados, blljc.ListarTodo());
                        dgvEmpleados.Columns["oUsu"].Visible = false;
                        dgvEmpleados.Columns["Codigo"].Visible = false;
                        dgvEmpleados.Columns["NumCodigo"].Visible = false;
                        dgvEmpleados.Columns["Sueldo"].Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Ese no es una cuenta de mail");
                        txtEmail.Text = null;
                    }
                }
                else if(PuestoEmpleado() == "Jefe de departamentos")
                {
                    bejd = new BeJefeDepartamento(user.NombreUsuario, user.Password, txtNomApe.Text, int.Parse(txtDni.Text), dtpFechaNacimineto.Value,
                                  txtEmail.Text, txtNombreDepart.Text, txtCalle.Text, int.Parse(txtNumero.Text), txtLocalidad.Text,
                                   userControlProvincia1.ToString(), int.Parse(txtCodigoPostal.Text), PuestoEmpleado(),
                                   txtAux.Text);

                    if (blljd.email_bien_escrito(txtEmail.Text) == true)
                    {
                        blljd.Guardar(bejd);
                        VaciarTextBox();
                        rdgv.Refresh(dgvEmpleados, blljd.ListarTodo());
                        dgvEmpleados.Columns["oUsu"].Visible = false;
                        dgvEmpleados.Columns["Codigo"].Visible = false;
                        dgvEmpleados.Columns["NumCodigo"].Visible = false;
                        dgvEmpleados.Columns["Sueldo"].Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Ese no es una cuenta de mail");
                        txtEmail.Text = null;
                    }
                }

               
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message + " o quedo un casillero vacio");
            }
            lblAux.Visible = false;
            txtAux.Visible = false;
        }
        public void VaciarTextBox()
        {
            txtNomUser.Text = null;
            txtPassword.Text = null;
            txtNomApe.Text = null;
            txtDni.Text = null;
            dtpFechaNacimineto.Value = DateTime.Now;
            txtEmail.Text = null;
            txtNombreDepart.Text = null;
            txtCalle.Text = null;
            txtNumero.Text = null;
            txtLocalidad.Text = null;
            userControlProvincia1.LimpiarCb();            
            txtCodigoPostal.Text = null;
            rbJefeCompra.Checked = true;
        }

        private void btnEmpleadoBorrar_Click(object sender, EventArgs e)
        {
            try
            {
                BeEmpleado auxEmpleado = (BeEmpleado)dgvEmpleados.SelectedRows[0].DataBoundItem;
               

                if(auxEmpleado.Puesto == "Empleado")
                {
                    bll.Borrar(auxEmpleado);
                    rdgv.Refresh(dgvEmpleados, bll.ListarTodo());
                }
                else if(auxEmpleado.Puesto == "Jefe de compras")
                {
                    blljc.Borrar(auxEmpleado);
                    rdgv.Refresh(dgvEmpleados, blljc.ListarTodo());
                }else if (auxEmpleado.Puesto == "Jefe de departamentos")
                {
                    blljd.Borrar(auxEmpleado);
                    rdgv.Refresh(dgvEmpleados, blljd.ListarTodo());
                }
                
                dgvEmpleados.Columns["oUsu"].Visible = false;
                dgvEmpleados.Columns["Codigo"].Visible = false;
                dgvEmpleados.Columns["NumCodigo"].Visible = false;
                dgvEmpleados.Columns["Sueldo"].Visible = false;

                VaciarTextBox();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            rbEmpleado.Checked = true;
            lblAux.Visible = false;
            txtAux.Visible = false;
        }

        private void btnEmpleadoModificar_Click(object sender, EventArgs e)
        {
            try
            {
                BeEmpleado auxEmpleado = (BeEmpleado)dgvEmpleados.SelectedRows[0].DataBoundItem;
                BeUsuario OBeUsu = new BeUsuario(txtNomUser.Text, txtPassword.Text);
               
                if (PuestoEmpleado() == "Empleado")
                {
                    be = new BeEmpleado(auxEmpleado.Codigo, OBeUsu.NombreUsuario, OBeUsu.Password, txtNomApe.Text, int.Parse(txtDni.Text), dtpFechaNacimineto.Value,
                                   txtEmail.Text, txtNombreDepart.Text, txtCalle.Text, int.Parse(txtNumero.Text), txtLocalidad.Text,
                                    userControlProvincia1.ToString(), int.Parse(txtCodigoPostal.Text), PuestoEmpleado());

                    if (bll.email_bien_escrito(txtEmail.Text) == true)
                    {
                        bll.Guardar(be);
                        VaciarTextBox();
                        rdgv.Refresh(dgvEmpleados, bll.ListarTodo());
                        dgvEmpleados.Columns["oUsu"].Visible = false;
                        dgvEmpleados.Columns["Codigo"].Visible = false;
                        dgvEmpleados.Columns["NumCodigo"].Visible = false;
                        dgvEmpleados.Columns["Sueldo"].Visible = false;
                        txtNomUser.Enabled = true;
                        txtPassword.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Ese no es una cuenta de mail");
                        txtEmail.Text = null;
                    }
                }

                 else if (PuestoEmpleado() == "Jefe de compras")
                {
                    bejc = new BeJefeCompra(auxEmpleado.Codigo, OBeUsu.NombreUsuario, OBeUsu.Password, txtNomApe.Text, int.Parse(txtDni.Text), dtpFechaNacimineto.Value,
                                   txtEmail.Text, txtNombreDepart.Text, txtCalle.Text, int.Parse(txtNumero.Text), txtLocalidad.Text,
                                    userControlProvincia1.ToString(), int.Parse(txtCodigoPostal.Text), PuestoEmpleado(), txtAux.Text);

                    if (blljd.email_bien_escrito(txtEmail.Text) == true)
                    {
                        blljd.Modificar(bejc);
                        VaciarTextBox();
                        rdgv.Refresh(dgvEmpleados, blljd.ListarTodo());
                        dgvEmpleados.Columns["oUsu"].Visible = false;
                        dgvEmpleados.Columns["Codigo"].Visible = false;
                        dgvEmpleados.Columns["NumCodigo"].Visible = false;
                        dgvEmpleados.Columns["Sueldo"].Visible = false;
                        txtNomUser.Enabled = true;
                        txtPassword.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Ese no es una cuenta de mail");
                        txtEmail.Text = null;
                    }
                }
                else if (PuestoEmpleado() == "Jefe de departamentos")
                {
                    bejd = new BeJefeDepartamento(auxEmpleado.Codigo, OBeUsu.NombreUsuario, OBeUsu.Password, txtNomApe.Text, int.Parse(txtDni.Text), dtpFechaNacimineto.Value,
                                  txtEmail.Text, txtNombreDepart.Text, txtCalle.Text, int.Parse(txtNumero.Text), txtLocalidad.Text,
                                   userControlProvincia1.ToString(), int.Parse(txtCodigoPostal.Text), PuestoEmpleado(), txtAux.Text);

                    if (blljd.email_bien_escrito(txtEmail.Text) == true)
                    {
                        blljd.Modificar(bejc);
                        VaciarTextBox();
                        rdgv.Refresh(dgvEmpleados, blljd.ListarTodo());
                        dgvEmpleados.Columns["oUsu"].Visible = false;
                        dgvEmpleados.Columns["Codigo"].Visible = false;
                        dgvEmpleados.Columns["NumCodigo"].Visible = false;
                        dgvEmpleados.Columns["Sueldo"].Visible = false;
                        txtNomUser.Enabled = true;
                        txtPassword.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Ese no es una cuenta de mail");
                        txtEmail.Text = null;
                    }
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " o quedo vacio algun casillero");
            }
            lblAux.Visible = false;
            txtAux.Visible = false;
            rbEmpleado.Checked = true;
        }

        private void UIAbmEmpleado_Load(object sender, EventArgs e)
        {
            dgvEmpleados.MultiSelect = false;
            dgvEmpleados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            
            rdgv.Refresh(dgvEmpleados, blljd.ListarTodo());
            dgvEmpleados.Columns["oUsu"].Visible = false;
            dgvEmpleados.Columns["Codigo"].Visible = false;
            dgvEmpleados.Columns["NumCodigo"].Visible = false;
            dgvEmpleados.Columns["Sueldo"].Visible = false;
            rbEmpleado.Checked = true;
        }

        private void dgvEmpleados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            BeEmpleado auxEmpleado = (BeEmpleado)dgvEmpleados.SelectedRows[0].DataBoundItem;
            
               
                txtNomUser.Text = auxEmpleado.oUsu.NombreUsuario.ToString();
                txtPassword.Text = auxEmpleado.oUsu.Password.ToString();
                txtNomUser.Enabled = false;
                txtPassword.Enabled = false;
                txtNomApe.Text = auxEmpleado.Nombre.ToString();
                txtDni.Text = auxEmpleado.Dni.ToString();
                dtpFechaNacimineto.Value = auxEmpleado.FechaNacimiento;
                txtEmail.Text = auxEmpleado.Email.ToString();
                txtNombreDepart.Text = auxEmpleado.NombreDepartamento.ToString();
                txtCalle.Text = auxEmpleado.Calle.ToString();
                txtNumero.Text = auxEmpleado.NumeroAltura.ToString();
                txtLocalidad.Text = auxEmpleado.Localidad.ToString();                
                userControlProvincia1.Cabecera(auxEmpleado.Provincia.ToString()) ;
                txtCodigoPostal.Text = auxEmpleado.CodigoPostal.ToString();               
            
        }

        public string PuestoEmpleado()
        {
            if (rbEmpleado.Checked == true)
            {
                rbJefeCompra.Checked = false;
                rbJefeDto.Checked = false;
                
                return "Empleado";
            }
            else if (rbJefeCompra.Checked == true)
            {
                rbEmpleado.Checked = false;
                rbJefeDto.Checked = false;
                
                return "Jefe de compras";
            }
            else if(rbJefeDto.Checked == true)
            {
                rbEmpleado.Checked = false;
                rbJefeCompra.Checked = false;
               
                return "Jefe de departamentos";
            }
            return null;
        }

        private void rbEmpleado_CheckedChanged(object sender, EventArgs e)
        {
            lblAux.Visible = false;
            txtAux.Visible = false;
        }

        private void rbJefeCompra_CheckedChanged(object sender, EventArgs e)
        {
            lblAux.Text = "Ingrese su titulo";
            lblAux.Visible = true;
            txtAux.Visible = true;
        }

        private void rbJefeDto_CheckedChanged(object sender, EventArgs e)
        {
            lblAux.Text = "Ingrese su departamento";
            lblAux.Visible = true;
            txtAux.Visible = true;
        }
    }
}
