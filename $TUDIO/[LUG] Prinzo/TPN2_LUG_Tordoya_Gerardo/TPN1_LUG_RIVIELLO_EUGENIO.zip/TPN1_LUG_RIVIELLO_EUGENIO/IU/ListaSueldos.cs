﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using BLL;

namespace IU
{
    public partial class ListaSueldos : Form
    {
        public ListaSueldos()
        {
            InitializeComponent();
            bll = new BllSueldo();
            rdgv = new RefreshDgv();
        }
        BllSueldo bll;
        RefreshDgv rdgv;
        private void ListaSueldos_Load(object sender, EventArgs e)
        {
            rdgv.Refresh(dgvSueldosEmpleados, bll.ListarTodo());
            dgvSueldosEmpleados.Columns["Codigo"].Visible = false;
        }
    }
}
