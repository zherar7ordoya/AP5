﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using BLL;

namespace IU
{
    public partial class UIOrden : Form
    {
        public UIOrden()
        {
            InitializeComponent();
            rdgv = new RefreshDgv();
            boi = new BllOrdenItem();
            blle = new BllEmpleado();
        }
        BllOrdenItem boi;
        RefreshDgv rdgv;
        BllEmpleado blle;
        BeEmpleado be;

        private void UIOrden_Load(object sender, EventArgs e)
        {
            dgbAsignados.MultiSelect = false;
            dgbAsignados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            rdgv.Refresh(dgbAsignados, boi.ListaProduct());
            dgbAsignados.Columns["Codigo"].Visible = false;
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            BeProducto auxProd = (BeProducto)dgbAsignados.SelectedRows[0].DataBoundItem;
            foreach (BeEmpleado item in blle.ListarTodo())
            {
                if(item.Nombre == auxProd.Nombre && item.NumCodigo == auxProd.Codigo)
                {
                    be = new BeEmpleado(item.Codigo, item.oUsu.NombreUsuario, item.oUsu.Password, item.Nombre, item.Dni,
                                        item.FechaNacimiento, item.Email, item.NombreDepartamento, item.Calle, item.NumeroAltura,
                                        item.Localidad, item.Provincia, item.CodigoPostal, item.Puesto, 0);
                    blle.Modificar(be);
                    MessageBox.Show("Se ha desasignado con exito");
                    rdgv.Refresh(dgbAsignados, boi.ListaProduct());
                    dgbAsignados.Columns["Codigo"].Visible = false;
                }
            }
        }
               
    }
}
