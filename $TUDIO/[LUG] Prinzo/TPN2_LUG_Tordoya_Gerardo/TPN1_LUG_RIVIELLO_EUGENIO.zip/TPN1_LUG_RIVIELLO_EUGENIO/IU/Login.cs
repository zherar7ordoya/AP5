﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using BE;

namespace IU
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            BllUsuario bllUsuario = new BllUsuario();
            string pass = BllUsuario.GetSHA256(txtPassword.Text);
            BeUsuario beUsuario = new BeUsuario(txtNombreUsuario.Text, pass);

            if (bllUsuario.BllLogin(beUsuario) == true)
            {
                Menu menu = new Menu();
                this.Hide();
                menu.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Usuario o password incorrectos");
            }
        }
    }
}
