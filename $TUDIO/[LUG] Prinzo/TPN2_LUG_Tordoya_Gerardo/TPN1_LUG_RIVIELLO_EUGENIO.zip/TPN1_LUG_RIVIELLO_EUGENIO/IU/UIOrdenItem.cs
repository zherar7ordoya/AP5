﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using BLL;

namespace IU
{
    public partial class UIOrdenItem : Form
    {
        public UIOrdenItem()
        {
            InitializeComponent();
            ble = new BllEmpleado();
            blp = new BllProducto();
            rdgv = new RefreshDgv();
            bloi = new BllOrdenItem();
        }

        BllEmpleado ble;
        BllProducto blp;
        RefreshDgv rdgv;
        BeEmpleado auxEmpleado;
        BeProducto auxProducto;
        BllOrdenItem bloi;
        int num;
        private void UIOrdenItem_Load(object sender, EventArgs e)
        {
            dgvEmpleadoAux.MultiSelect = false;
            dgvEmpleadoAux.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductoAux.MultiSelect = false;
            dgvProductoAux.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            rdgv.Refresh(dgvEmpleadoAux, ble.ListarTodo());
            rdgv.Refresh(dgvProductoAux, blp.ListarTodo());
            dgvEmpleadoAux.Columns["oUsu"].Visible = false;
            dgvEmpleadoAux.Columns["Codigo"].Visible = false;
            dgvEmpleadoAux.Columns["NumCodigo"].Visible = false;
            dgvProductoAux.Columns["Codigo"].Visible = false;
            dgvProductoAux.Columns["Nombre"].Visible = false;
        }

        private void btnAsignarOrden_Click(object sender, EventArgs e)
        {
            if(auxEmpleado != null && auxProducto != null)
            {
                
                auxEmpleado = new BeEmpleado(auxEmpleado.Codigo, auxEmpleado.oUsu.NombreUsuario, auxEmpleado.oUsu.Password,
                                        auxEmpleado.Nombre, auxEmpleado.Dni, auxEmpleado.FechaNacimiento, auxEmpleado.Email,
                                        auxEmpleado.NombreDepartamento, auxEmpleado.Calle, auxEmpleado.NumeroAltura,
                                        auxEmpleado.Localidad, auxEmpleado.Provincia, auxEmpleado.CodigoPostal,
                                        auxEmpleado.Puesto, num);
                
                ble.Modificar(auxEmpleado);
                MessageBox.Show("Se ha asignado con exito");
            }
            else
            {
                MessageBox.Show("Debe seleccionar un empleado y una producto para poder asignar");
            }

           
        }

        private void dgvEmpleadoAux_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            auxEmpleado = (BeEmpleado)dgvEmpleadoAux.SelectedRows[0].DataBoundItem;
                        
            int p = e.RowIndex;
            if(auxEmpleado != null)
            {
                foreach (DataGridViewRow rp in dgvEmpleadoAux.Rows)
                {
                    int k = rp.Index;
                    if(k == p)
                    {
                        dgvEmpleadoAux.Rows[p].DefaultCellStyle.BackColor = Color.DarkOrange;
                    }
                    else if(k != p)
                    {
                        dgvEmpleadoAux.Rows[k].DefaultCellStyle.BackColor = Color.White;
                    }
                }
              
            }
        }

        private void dgvProductoAux_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            auxProducto = (BeProducto)dgvProductoAux.SelectedRows[0].DataBoundItem;
           
            int p = e.RowIndex;
            if (auxProducto != null)
            {
                foreach (DataGridViewRow rp in dgvProductoAux.Rows)
                {
                    int k = rp.Index;
                    if (k == p)
                    {
                        dgvProductoAux.Rows[p].DefaultCellStyle.BackColor = Color.DarkOrange;
                    }
                    else if (k != p)
                    {
                        dgvProductoAux.Rows[k].DefaultCellStyle.BackColor = Color.White;
                    }
                }
            }
            num = auxProducto.Codigo;
        }
              
    }
}
