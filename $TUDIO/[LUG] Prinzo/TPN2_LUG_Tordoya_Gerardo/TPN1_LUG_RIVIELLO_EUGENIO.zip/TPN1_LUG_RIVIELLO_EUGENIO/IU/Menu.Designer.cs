﻿
namespace IU
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asignarOrdenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asignarOrdenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.listaAsignadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizarSueldosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadorSueldosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aBMProductoXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarReporteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarReporteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.listaSueldosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivosToolStripMenuItem,
            this.gestionarToolStripMenuItem,
            this.asignarOrdenToolStripMenuItem,
            this.visualizarSueldosToolStripMenuItem,
            this.consultasXMLToolStripMenuItem,
            this.generarReporteToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(990, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivosToolStripMenuItem
            // 
            this.archivosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salirToolStripMenuItem});
            this.archivosToolStripMenuItem.Name = "archivosToolStripMenuItem";
            this.archivosToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.archivosToolStripMenuItem.Text = "Archivos";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(96, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // gestionarToolStripMenuItem
            // 
            this.gestionarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empleadosToolStripMenuItem,
            this.productoToolStripMenuItem});
            this.gestionarToolStripMenuItem.Name = "gestionarToolStripMenuItem";
            this.gestionarToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.gestionarToolStripMenuItem.Text = "Gestionar";
            // 
            // empleadosToolStripMenuItem
            // 
            this.empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
            this.empleadosToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.empleadosToolStripMenuItem.Text = "Empleados";
            this.empleadosToolStripMenuItem.Click += new System.EventHandler(this.empleadosToolStripMenuItem_Click);
            // 
            // productoToolStripMenuItem
            // 
            this.productoToolStripMenuItem.Name = "productoToolStripMenuItem";
            this.productoToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.productoToolStripMenuItem.Text = "Producto";
            this.productoToolStripMenuItem.Click += new System.EventHandler(this.productoToolStripMenuItem_Click);
            // 
            // asignarOrdenToolStripMenuItem
            // 
            this.asignarOrdenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asignarOrdenToolStripMenuItem1,
            this.listaAsignadosToolStripMenuItem});
            this.asignarOrdenToolStripMenuItem.Name = "asignarOrdenToolStripMenuItem";
            this.asignarOrdenToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
            this.asignarOrdenToolStripMenuItem.Text = "Asignar orden";
            // 
            // asignarOrdenToolStripMenuItem1
            // 
            this.asignarOrdenToolStripMenuItem1.Name = "asignarOrdenToolStripMenuItem1";
            this.asignarOrdenToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
            this.asignarOrdenToolStripMenuItem1.Text = "Asignar orden";
            this.asignarOrdenToolStripMenuItem1.Click += new System.EventHandler(this.asignarOrdenToolStripMenuItem1_Click);
            // 
            // listaAsignadosToolStripMenuItem
            // 
            this.listaAsignadosToolStripMenuItem.Name = "listaAsignadosToolStripMenuItem";
            this.listaAsignadosToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.listaAsignadosToolStripMenuItem.Text = "Lista asignados";
            this.listaAsignadosToolStripMenuItem.Click += new System.EventHandler(this.listaAsignadosToolStripMenuItem_Click);
            // 
            // visualizarSueldosToolStripMenuItem
            // 
            this.visualizarSueldosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculadorSueldosToolStripMenuItem,
            this.listaSueldosToolStripMenuItem});
            this.visualizarSueldosToolStripMenuItem.Name = "visualizarSueldosToolStripMenuItem";
            this.visualizarSueldosToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.visualizarSueldosToolStripMenuItem.Text = "Visualizar sueldos";
            // 
            // calculadorSueldosToolStripMenuItem
            // 
            this.calculadorSueldosToolStripMenuItem.Name = "calculadorSueldosToolStripMenuItem";
            this.calculadorSueldosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.calculadorSueldosToolStripMenuItem.Text = "Calculador sueldos";
            this.calculadorSueldosToolStripMenuItem.Click += new System.EventHandler(this.calculadorSueldosToolStripMenuItem_Click);
            // 
            // consultasXMLToolStripMenuItem
            // 
            this.consultasXMLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aBMProductoXMLToolStripMenuItem});
            this.consultasXMLToolStripMenuItem.Name = "consultasXMLToolStripMenuItem";
            this.consultasXMLToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.consultasXMLToolStripMenuItem.Text = "Consultas XML";
            // 
            // aBMProductoXMLToolStripMenuItem
            // 
            this.aBMProductoXMLToolStripMenuItem.Name = "aBMProductoXMLToolStripMenuItem";
            this.aBMProductoXMLToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.aBMProductoXMLToolStripMenuItem.Text = "ABM Producto XML";
            this.aBMProductoXMLToolStripMenuItem.Click += new System.EventHandler(this.aBMProductoXMLToolStripMenuItem_Click);
            // 
            // generarReporteToolStripMenuItem
            // 
            this.generarReporteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.generarReporteToolStripMenuItem1});
            this.generarReporteToolStripMenuItem.Name = "generarReporteToolStripMenuItem";
            this.generarReporteToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.generarReporteToolStripMenuItem.Text = "Generar Reporte";
            // 
            // generarReporteToolStripMenuItem1
            // 
            this.generarReporteToolStripMenuItem1.Name = "generarReporteToolStripMenuItem1";
            this.generarReporteToolStripMenuItem1.Size = new System.Drawing.Size(156, 22);
            this.generarReporteToolStripMenuItem1.Text = "Generar reporte";
            this.generarReporteToolStripMenuItem1.Click += new System.EventHandler(this.generarReporteToolStripMenuItem1_Click);
            // 
            // listaSueldosToolStripMenuItem
            // 
            this.listaSueldosToolStripMenuItem.Name = "listaSueldosToolStripMenuItem";
            this.listaSueldosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listaSueldosToolStripMenuItem.Text = "Lista Sueldos";
            this.listaSueldosToolStripMenuItem.Click += new System.EventHandler(this.listaSueldosToolStripMenuItem_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 529);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empleadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asignarOrdenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asignarOrdenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listaAsignadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizarSueldosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadorSueldosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aBMProductoXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generarReporteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generarReporteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listaSueldosToolStripMenuItem;
    }
}