﻿
namespace IU
{
    partial class UIOrdenItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvEmpleadoAux = new System.Windows.Forms.DataGridView();
            this.dgvProductoAux = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAsignarOrden = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleadoAux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductoAux)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvEmpleadoAux
            // 
            this.dgvEmpleadoAux.AllowUserToAddRows = false;
            this.dgvEmpleadoAux.AllowUserToDeleteRows = false;
            this.dgvEmpleadoAux.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleadoAux.Location = new System.Drawing.Point(0, 34);
            this.dgvEmpleadoAux.Name = "dgvEmpleadoAux";
            this.dgvEmpleadoAux.ReadOnly = true;
            this.dgvEmpleadoAux.Size = new System.Drawing.Size(886, 173);
            this.dgvEmpleadoAux.TabIndex = 0;
            this.dgvEmpleadoAux.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmpleadoAux_CellDoubleClick);
            // 
            // dgvProductoAux
            // 
            this.dgvProductoAux.AllowUserToAddRows = false;
            this.dgvProductoAux.AllowUserToDeleteRows = false;
            this.dgvProductoAux.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductoAux.Location = new System.Drawing.Point(0, 241);
            this.dgvProductoAux.Name = "dgvProductoAux";
            this.dgvProductoAux.ReadOnly = true;
            this.dgvProductoAux.Size = new System.Drawing.Size(886, 173);
            this.dgvProductoAux.TabIndex = 1;
            this.dgvProductoAux.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProductoAux_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Lista de empleados";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-6, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(254, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Lista de productos";
            // 
            // btnAsignarOrden
            // 
            this.btnAsignarOrden.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsignarOrden.Location = new System.Drawing.Point(344, 420);
            this.btnAsignarOrden.Name = "btnAsignarOrden";
            this.btnAsignarOrden.Size = new System.Drawing.Size(145, 45);
            this.btnAsignarOrden.TabIndex = 16;
            this.btnAsignarOrden.Text = "Asignar orden";
            this.btnAsignarOrden.UseVisualStyleBackColor = true;
            this.btnAsignarOrden.Click += new System.EventHandler(this.btnAsignarOrden_Click);
            // 
            // UIOrdenItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 472);
            this.Controls.Add(this.btnAsignarOrden);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvProductoAux);
            this.Controls.Add(this.dgvEmpleadoAux);
            this.Name = "UIOrdenItem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UIOrdenItem";
            this.Load += new System.EventHandler(this.UIOrdenItem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleadoAux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductoAux)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmpleadoAux;
        private System.Windows.Forms.DataGridView dgvProductoAux;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAsignarOrden;
    }
}