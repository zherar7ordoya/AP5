﻿namespace IU
{
    partial class UserControlProvincia
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbProvincia = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // cbProvincia
            // 
            this.cbProvincia.FormattingEnabled = true;
            this.cbProvincia.Items.AddRange(new object[] {
            "Buenos Aires\t",
            "Catamarca",
            "Chaco",
            "Chubut",
            "Cordoba",
            "Corrientes",
            "Entre Rios",
            "Formosa",
            "Jujuy",
            "La Pampa",
            "La RIoja",
            "Mendoza",
            "Misiones",
            "Neuquen",
            "Rio Negro",
            "Salta",
            "San Juan",
            "San Luis",
            "Santa Cruz",
            "Santa Fe",
            "Santiago del Estero",
            "Tierra del Fuego",
            "Tucuman"});
            this.cbProvincia.Location = new System.Drawing.Point(3, 3);
            this.cbProvincia.Name = "cbProvincia";
            this.cbProvincia.Size = new System.Drawing.Size(130, 21);
            this.cbProvincia.TabIndex = 0;
            this.cbProvincia.SelectedIndexChanged += new System.EventHandler(this.cbProvincia_SelectedIndexChanged);
            // 
            // UserControlProvincia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbProvincia);
            this.Name = "UserControlProvincia";
            this.Size = new System.Drawing.Size(135, 26);
            this.Load += new System.EventHandler(this.UserControlProvincia_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbProvincia;
    }
}
