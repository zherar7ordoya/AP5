﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IU
{
    public partial class UserControlProvincia : UserControl
    {
        public UserControlProvincia()
        {
            InitializeComponent();
        }
        //public string provincia = "";

        public string provincia { get; set; }
        private void UserControlProvincia_Load(object sender, EventArgs e)
        {
            
        }
        public void LimpiarCb()
        {
            cbProvincia.Text = null;
        }
        public void Cabecera(string cabeza)
        {
            cbProvincia.Text = cabeza;
        }

        public override string ToString()
        {
            return provincia;
        }

        private void cbProvincia_SelectedIndexChanged(object sender, EventArgs e)
        {
           provincia = cbProvincia.Text;
        }
    }
}
