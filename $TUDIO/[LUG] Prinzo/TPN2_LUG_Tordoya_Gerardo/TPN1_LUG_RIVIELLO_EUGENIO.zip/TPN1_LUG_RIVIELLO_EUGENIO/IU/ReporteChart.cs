﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using BE;
using BLL;


namespace IU
{
    public partial class ReporteChart : Form
    {
        public ReporteChart()
        {
            InitializeComponent();
            bllproduc = new BllProducto();
        }
        BllProducto bllproduc;


        public void GenerarGrafico()
        {
            Dictionary<string, double> ListaGrafica = new Dictionary<string, double>();

            foreach (BeProducto producto in bllproduc.ListarTodo())
            {
                BeProducto bp = new BeProducto();
                bp = producto;
                ListaGrafica.Add(bp.NombreProducto, bp.PrecioUnitario);
               
            }

            chartEstadisc.Series[0].Points.DataBindXY(ListaGrafica.Keys, ListaGrafica.Values);
           
            chartEstadisc.Series[0].ChartType = SeriesChartType.Pie;
            
            chartEstadisc.ChartAreas[0].Area3DStyle.Enable3D = true;
        }

        private void ReporteChart_Load(object sender, EventArgs e)
        {
            GenerarGrafico();
        }
    }
}
