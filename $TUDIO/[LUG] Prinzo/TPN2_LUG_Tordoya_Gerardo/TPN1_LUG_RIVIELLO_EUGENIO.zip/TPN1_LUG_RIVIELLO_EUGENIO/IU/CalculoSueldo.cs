﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using BLL;

namespace IU
{
    public partial class btnCalculoSueldo : Form
    {
        public btnCalculoSueldo()
        {
            InitializeComponent(); 
            be = new BeEmpleado();
            bll = new BllEmpleado();
            blljc = new BllJefeCompra();
            blljd = new BllJefeDepartamento();
            bejc = new BeJefeCompra();
            bejd = new BeJefeDepartamento();
            rdgv = new RefreshDgv();
            bls = new BllSueldo();
            bs = new BeSueldo();
            
        }
        BeSueldo bs;
        BeEmpleado be;
        BllEmpleado bll;
        BllSueldo bls;
        RefreshDgv rdgv;       
        BllJefeCompra blljc;
        BllJefeDepartamento blljd;
        BeJefeCompra bejc;
        BeJefeDepartamento bejd;
       
        private void btnCalculoSueldo_Load(object sender, EventArgs e)
        {
            dgvEmpleadoAux.MultiSelect = false;
            dgvEmpleadoAux.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            rdgv.Refresh(dgvEmpleadoAux, bll.ListarTodo());
            dgvEmpleadoAux.Columns["oUsu"].Visible = false;
            dgvEmpleadoAux.Columns["Codigo"].Visible = false;
            dgvEmpleadoAux.Columns["NumCodigo"].Visible = false;
            dgvEmpleadoAux.Columns["Sueldo"].Visible = false;
        }

        private void btnCalcularSueldo_Click(object sender, EventArgs e)
        {
            BeEmpleado auxEmpleado = (BeEmpleado)dgvEmpleadoAux.SelectedRows[0].DataBoundItem;

            int cod = 0;
            
            if (auxEmpleado.Puesto == "Empleado")
            {
                if (bls.ListarTodo() != null)
                {
                    foreach (BeSueldo item in bls.ListarTodo())
                    {
                        if (item.oEmpleado.Nombre == auxEmpleado.Nombre)
                        {
                            cod = item.Codigo;
                        }
                    }
                }

                if (txtExtras != null && txtHoras != null)
                {
                   int sueldo = bll.Sueldo(int.Parse(txtHoras.Text), int.Parse(txtExtras.Text));
                   bs = new BeSueldo(cod, auxEmpleado.Nombre, sueldo);
                   bls.Guardar(bs);
                   bls.GuardarTablaIntermedia(bs, auxEmpleado);
                   MessageBox.Show("El sueldo del " +auxEmpleado.Puesto +" "+ auxEmpleado.Nombre + " es de " + sueldo + " pesos");
                    VaciarTxt();
                }
                else
                {
                    MessageBox.Show("Debe de completar las casillas");
                }
            }
            else if (auxEmpleado.Puesto == "Jefe de compras")
            {
                if (bls.ListarTodo() != null)
                {
                    foreach (BeSueldo item in bls.ListarTodo())
                    {
                        if (item.oEmpleado.Nombre == auxEmpleado.Nombre)
                        {
                            cod = item.Codigo;
                        }
                    }
                }
                if (txtExtras != null && txtHoras != null)
                {
                    int sueldo = blljc.Sueldo(int.Parse(txtHoras.Text), int.Parse(txtExtras.Text));
                    bs = new BeSueldo(cod, auxEmpleado.Nombre, sueldo);
                    bls.Guardar(bs);
                    bls.GuardarTablaIntermedia(bs, auxEmpleado);
                    MessageBox.Show("El sueldo del " + auxEmpleado.Puesto + " " + auxEmpleado.Nombre + " es de " + sueldo + " pesos");
                    VaciarTxt();
                }
                else
                {
                    MessageBox.Show("Debe de completar las casillas");
                }
            }
            else if (auxEmpleado.Puesto == "Jefe de departamentos")
            {
                if (bls.ListarTodo() != null)
                {
                    foreach (BeSueldo item in bls.ListarTodo())
                    {
                        if (item.oEmpleado.Nombre == auxEmpleado.Nombre)
                        {
                            cod = item.Codigo;
                        }
                    }
                }
                if (txtExtras != null && txtHoras != null)
                {
                    int sueldo = blljd.Sueldo(int.Parse(txtHoras.Text), int.Parse(txtExtras.Text));
                    bs = new BeSueldo(cod, auxEmpleado.Nombre, sueldo);
                    bls.Guardar(bs);
                    bls.GuardarTablaIntermedia(bs, auxEmpleado);
                    MessageBox.Show("El sueldo del " + auxEmpleado.Puesto + " " + auxEmpleado.Nombre + " es de " + sueldo + " pesos");
                    VaciarTxt();
                }
                else
                {
                    MessageBox.Show("Debe de completar las casillas");
                }
            }
        }
        public void VaciarTxt()
        {
            txtExtras.Text = null;
            txtHoras.Text = null;
        }
    }
}
