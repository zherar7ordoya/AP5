﻿
namespace IU
{
    partial class UIAbmEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNomUser = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomApe = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNombreDepart = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCalle = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtLocalidad = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCodigoPostal = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnEmpleadoAgregar = new System.Windows.Forms.Button();
            this.btnEmpleadoBorrar = new System.Windows.Forms.Button();
            this.btnEmpleadoModificar = new System.Windows.Forms.Button();
            this.dgvEmpleados = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpFechaNacimineto = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.rbJefeCompra = new System.Windows.Forms.RadioButton();
            this.rbJefeDto = new System.Windows.Forms.RadioButton();
            this.rbEmpleado = new System.Windows.Forms.RadioButton();
            this.txtAux = new System.Windows.Forms.TextBox();
            this.lblAux = new System.Windows.Forms.Label();
            this.userControlProvincia1 = new IU.UserControlProvincia();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "ABM Empleado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre de usuario";
            // 
            // txtNomUser
            // 
            this.txtNomUser.Location = new System.Drawing.Point(34, 78);
            this.txtNomUser.Name = "txtNomUser";
            this.txtNomUser.Size = new System.Drawing.Size(134, 20);
            this.txtNomUser.TabIndex = 2;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(34, 120);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(134, 20);
            this.txtPassword.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Password";
            // 
            // txtNomApe
            // 
            this.txtNomApe.Location = new System.Drawing.Point(34, 164);
            this.txtNomApe.Name = "txtNomApe";
            this.txtNomApe.Size = new System.Drawing.Size(134, 20);
            this.txtNomApe.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(31, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nombre y Apellido";
            // 
            // txtDni
            // 
            this.txtDni.Location = new System.Drawing.Point(34, 207);
            this.txtDni.Name = "txtDni";
            this.txtDni.Size = new System.Drawing.Size(134, 20);
            this.txtDni.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Dni";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(34, 301);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(134, 20);
            this.txtEmail.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 285);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Email";
            // 
            // txtNombreDepart
            // 
            this.txtNombreDepart.Location = new System.Drawing.Point(214, 78);
            this.txtNombreDepart.Name = "txtNombreDepart";
            this.txtNombreDepart.Size = new System.Drawing.Size(134, 20);
            this.txtNombreDepart.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(211, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Nombre de departamento";
            // 
            // txtCalle
            // 
            this.txtCalle.Location = new System.Drawing.Point(214, 120);
            this.txtCalle.Name = "txtCalle";
            this.txtCalle.Size = new System.Drawing.Size(134, 20);
            this.txtCalle.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(211, 104);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Calle";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(214, 164);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(134, 20);
            this.txtNumero.TabIndex = 20;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(211, 148);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Numero";
            // 
            // txtLocalidad
            // 
            this.txtLocalidad.Location = new System.Drawing.Point(214, 207);
            this.txtLocalidad.Name = "txtLocalidad";
            this.txtLocalidad.Size = new System.Drawing.Size(134, 20);
            this.txtLocalidad.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(211, 191);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "Localidad";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(211, 238);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "Provincia";
            // 
            // txtCodigoPostal
            // 
            this.txtCodigoPostal.Location = new System.Drawing.Point(214, 302);
            this.txtCodigoPostal.Name = "txtCodigoPostal";
            this.txtCodigoPostal.Size = new System.Drawing.Size(134, 20);
            this.txtCodigoPostal.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(211, 286);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Codigo postal";
            // 
            // btnEmpleadoAgregar
            // 
            this.btnEmpleadoAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpleadoAgregar.Location = new System.Drawing.Point(368, 335);
            this.btnEmpleadoAgregar.Name = "btnEmpleadoAgregar";
            this.btnEmpleadoAgregar.Size = new System.Drawing.Size(134, 66);
            this.btnEmpleadoAgregar.TabIndex = 27;
            this.btnEmpleadoAgregar.Text = "Agregar";
            this.btnEmpleadoAgregar.UseVisualStyleBackColor = true;
            this.btnEmpleadoAgregar.Click += new System.EventHandler(this.btnEmpleadoAgregar_Click);
            // 
            // btnEmpleadoBorrar
            // 
            this.btnEmpleadoBorrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpleadoBorrar.Location = new System.Drawing.Point(584, 335);
            this.btnEmpleadoBorrar.Name = "btnEmpleadoBorrar";
            this.btnEmpleadoBorrar.Size = new System.Drawing.Size(134, 66);
            this.btnEmpleadoBorrar.TabIndex = 28;
            this.btnEmpleadoBorrar.Text = "Borrar";
            this.btnEmpleadoBorrar.UseVisualStyleBackColor = true;
            this.btnEmpleadoBorrar.Click += new System.EventHandler(this.btnEmpleadoBorrar_Click);
            // 
            // btnEmpleadoModificar
            // 
            this.btnEmpleadoModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpleadoModificar.Location = new System.Drawing.Point(800, 335);
            this.btnEmpleadoModificar.Name = "btnEmpleadoModificar";
            this.btnEmpleadoModificar.Size = new System.Drawing.Size(134, 66);
            this.btnEmpleadoModificar.TabIndex = 29;
            this.btnEmpleadoModificar.Text = "Modificar";
            this.btnEmpleadoModificar.UseVisualStyleBackColor = true;
            this.btnEmpleadoModificar.Click += new System.EventHandler(this.btnEmpleadoModificar_Click);
            // 
            // dgvEmpleados
            // 
            this.dgvEmpleados.AllowUserToAddRows = false;
            this.dgvEmpleados.AllowUserToDeleteRows = false;
            this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleados.Location = new System.Drawing.Point(368, 78);
            this.dgvEmpleados.Name = "dgvEmpleados";
            this.dgvEmpleados.ReadOnly = true;
            this.dgvEmpleados.Size = new System.Drawing.Size(566, 251);
            this.dgvEmpleados.TabIndex = 30;
            this.dgvEmpleados.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmpleados_CellDoubleClick);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(487, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(330, 39);
            this.label15.TabIndex = 31;
            this.label15.Text = "Lista de empleados";
            // 
            // dtpFechaNacimineto
            // 
            this.dtpFechaNacimineto.Location = new System.Drawing.Point(34, 254);
            this.dtpFechaNacimineto.Name = "dtpFechaNacimineto";
            this.dtpFechaNacimineto.Size = new System.Drawing.Size(134, 20);
            this.dtpFechaNacimineto.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(31, 238);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 13);
            this.label16.TabIndex = 35;
            this.label16.Text = "Fecha de nacimiento";
            // 
            // rbJefeCompra
            // 
            this.rbJefeCompra.AutoSize = true;
            this.rbJefeCompra.Location = new System.Drawing.Point(34, 363);
            this.rbJefeCompra.Name = "rbJefeCompra";
            this.rbJefeCompra.Size = new System.Drawing.Size(103, 17);
            this.rbJefeCompra.TabIndex = 37;
            this.rbJefeCompra.Text = "Jefe de compras";
            this.rbJefeCompra.UseVisualStyleBackColor = true;
            this.rbJefeCompra.CheckedChanged += new System.EventHandler(this.rbJefeCompra_CheckedChanged);
            // 
            // rbJefeDto
            // 
            this.rbJefeDto.AutoSize = true;
            this.rbJefeDto.Location = new System.Drawing.Point(34, 390);
            this.rbJefeDto.Name = "rbJefeDto";
            this.rbJefeDto.Size = new System.Drawing.Size(113, 17);
            this.rbJefeDto.TabIndex = 38;
            this.rbJefeDto.Text = "Jefe departamento";
            this.rbJefeDto.UseVisualStyleBackColor = true;
            this.rbJefeDto.CheckedChanged += new System.EventHandler(this.rbJefeDto_CheckedChanged);
            // 
            // rbEmpleado
            // 
            this.rbEmpleado.AutoSize = true;
            this.rbEmpleado.Checked = true;
            this.rbEmpleado.Location = new System.Drawing.Point(31, 336);
            this.rbEmpleado.Name = "rbEmpleado";
            this.rbEmpleado.Size = new System.Drawing.Size(72, 17);
            this.rbEmpleado.TabIndex = 39;
            this.rbEmpleado.TabStop = true;
            this.rbEmpleado.Text = "Empleado";
            this.rbEmpleado.UseVisualStyleBackColor = true;
            this.rbEmpleado.CheckedChanged += new System.EventHandler(this.rbEmpleado_CheckedChanged);
            // 
            // txtAux
            // 
            this.txtAux.Location = new System.Drawing.Point(197, 362);
            this.txtAux.Name = "txtAux";
            this.txtAux.Size = new System.Drawing.Size(134, 20);
            this.txtAux.TabIndex = 41;
            this.txtAux.Visible = false;
            // 
            // lblAux
            // 
            this.lblAux.AutoSize = true;
            this.lblAux.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAux.Location = new System.Drawing.Point(194, 346);
            this.lblAux.Name = "lblAux";
            this.lblAux.Size = new System.Drawing.Size(0, 13);
            this.lblAux.TabIndex = 40;
            this.lblAux.Visible = false;
            // 
            // userControlProvincia1
            // 
            this.userControlProvincia1.Location = new System.Drawing.Point(214, 254);
            this.userControlProvincia1.Name = "userControlProvincia1";
            this.userControlProvincia1.provincia = null;
            this.userControlProvincia1.Size = new System.Drawing.Size(135, 26);
            this.userControlProvincia1.TabIndex = 42;
            // 
            // UIAbmEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 457);
            this.Controls.Add(this.userControlProvincia1);
            this.Controls.Add(this.txtAux);
            this.Controls.Add(this.lblAux);
            this.Controls.Add(this.rbEmpleado);
            this.Controls.Add(this.rbJefeDto);
            this.Controls.Add(this.rbJefeCompra);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.dtpFechaNacimineto);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dgvEmpleados);
            this.Controls.Add(this.btnEmpleadoModificar);
            this.Controls.Add(this.btnEmpleadoBorrar);
            this.Controls.Add(this.btnEmpleadoAgregar);
            this.Controls.Add(this.txtCodigoPostal);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtLocalidad);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtCalle);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtNombreDepart);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDni);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNomApe);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNomUser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UIAbmEmpleado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UIAbmEmpleado";
            this.Load += new System.EventHandler(this.UIAbmEmpleado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNomUser;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomApe;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDni;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNombreDepart;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCalle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtLocalidad;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCodigoPostal;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnEmpleadoAgregar;
        private System.Windows.Forms.Button btnEmpleadoBorrar;
        private System.Windows.Forms.Button btnEmpleadoModificar;
        private System.Windows.Forms.DataGridView dgvEmpleados;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimineto;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton rbJefeCompra;
        private System.Windows.Forms.RadioButton rbJefeDto;
        private System.Windows.Forms.RadioButton rbEmpleado;
        private System.Windows.Forms.TextBox txtAux;
        private System.Windows.Forms.Label lblAux;
        private UserControlProvincia userControlProvincia1;
    }
}