﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using BLL;

namespace IU
{
    public partial class UIAbmProducto : Form
    {
        public UIAbmProducto()
        {
            InitializeComponent();
            bll = new BllProducto();
            rdgv = new RefreshDgv();
        }

        BllProducto bll;
        RefreshDgv rdgv; 
        
        private void btnProductoAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                BeProducto bp = new BeProducto(int.Parse(txtNumProduc.Text), txtNombProduct.Text, txtCategoria.Text, txtDescripcion.Text,
                    double.Parse(txtPrecioUnitario.Text), int.Parse(txtCodigoVendedor.Text));
                               
                if (bll.Comparar(txtNumProduc) == false)
                {
                    bll.Guardar(bp);
                    rdgv.Refresh(dgvProducto, bll.ListarTodo());
                    dgvProducto.Columns["Nombre"].Visible = false;
                    dgvProducto.Columns["Codigo"].Visible = false;
                    VaciarTextBox();
                }
                else
                {
                    txtNumProduc.Text = null;
                    return;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message + " o esta vacio algun casillero");
            }            
        }

        private void VaciarTextBox()
        {
            txtNumProduc.Text = null;
            txtNombProduct.Text = null;
            txtCategoria.Text = null;
            txtDescripcion.Text = null;
            txtPrecioUnitario.Text = null;
            txtCodigoVendedor.Text = null;
        }

        private void btnProductoBorrar_Click(object sender, EventArgs e)
        {
            try
            {
                BeProducto auxProducto = (BeProducto)dgvProducto.SelectedRows[0].DataBoundItem;
              
                bll.Borrar(auxProducto);
                rdgv.Refresh(dgvProducto, bll.ListarTodo());
                dgvProducto.Columns["Nombre"].Visible = false;
                dgvProducto.Columns["Codigo"].Visible = false;
                VaciarTextBox();
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private void UIAbmProducto_Load(object sender, EventArgs e)
        {
            dgvProducto.MultiSelect = false;
            dgvProducto.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            rdgv.Refresh(dgvProducto, bll.ListarTodo());
            dgvProducto.Columns["Nombre"].Visible = false;
            dgvProducto.Columns["Codigo"].Visible = false;

        }

        private void btnProductoModificar_Click(object sender, EventArgs e)
        {
            try
            {
                BeProducto auxProducto = (BeProducto)dgvProducto.SelectedRows[0].DataBoundItem;
                BeProducto bp = new BeProducto(auxProducto.Codigo, int.Parse(txtNumProduc.Text), txtNombProduct.Text, txtCategoria.Text, txtDescripcion.Text, double.Parse(txtPrecioUnitario.Text), int.Parse(txtCodigoVendedor.Text));
                bll.Modificar(bp);
                rdgv.Refresh(dgvProducto, bll.ListarTodo());
                dgvProducto.Columns["Nombre"].Visible = false;
                dgvProducto.Columns["Codigo"].Visible = false;
                VaciarTextBox();
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }            
        }

        private void dgvProducto_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                BeProducto auxProducto = (BeProducto)dgvProducto.SelectedRows[0].DataBoundItem;
                txtNumProduc.Text = auxProducto.NumeroProducto.ToString();
                txtNombProduct.Text = auxProducto.NombreProducto.ToString();
                txtCategoria.Text = auxProducto.Categoria.ToString();
                txtDescripcion.Text = auxProducto.Descripcion.ToString();
                txtPrecioUnitario.Text = auxProducto.PrecioUnitario.ToString();
                txtCodigoVendedor.Text = auxProducto.CodigoVendedor.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
