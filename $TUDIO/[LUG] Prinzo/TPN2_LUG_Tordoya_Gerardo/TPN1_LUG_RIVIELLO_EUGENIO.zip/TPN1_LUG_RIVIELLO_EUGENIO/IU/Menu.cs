﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;

namespace IU
{
    public partial class Menu : Form
    {

        public Menu()
        {
            InitializeComponent();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIAbmEmpleado uiae = new UIAbmEmpleado();
            uiae.MdiParent = this;
            uiae.Show();
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIAbmProducto uiap = new UIAbmProducto();
            uiap.MdiParent = this;
            uiap.Show();
        }

        private void asignarOrdenToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            UIOrdenItem uioi = new UIOrdenItem();
            uioi.MdiParent = this;
            uioi.Show();
        }

        private void listaAsignadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIOrden uio = new UIOrden();
            uio.MdiParent = this;
            uio.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void calculadorSueldosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnCalculoSueldo cal = new btnCalculoSueldo();
            cal.MdiParent = this;
            cal.Show();
        }

        private void aBMProductoXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIAbmProductoXML uiapXml = new UIAbmProductoXML();
            uiapXml.MdiParent = this;
            uiapXml.Show();
        }

        private void generarReporteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ReporteChart rc = new ReporteChart();
            rc.MdiParent = this;
            rc.Show();
        }

        private void listaSueldosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListaSueldos ls = new ListaSueldos();
            ls.MdiParent = this;
            ls.Show();
        }
    }
}
