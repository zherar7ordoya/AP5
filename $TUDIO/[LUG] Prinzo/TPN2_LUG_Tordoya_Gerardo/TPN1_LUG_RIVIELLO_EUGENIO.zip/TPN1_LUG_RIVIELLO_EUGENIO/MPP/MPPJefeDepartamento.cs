﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abstraccion;
using BE;
using DAL;

namespace MPP
{
    public class MPPJefeDepartamento
    {
        Conexion Oc;
        ArrayList ArrList;
        Hashtable hash;
        public MPPJefeDepartamento()
        {
            Oc = new Conexion();
        }

        public bool Guardar(BeJefeDepartamento be)
        {

            ArrList = new ArrayList();
            string Consulta = "JefeDepartamento_Crear";
            hash = new Hashtable();
            hash = new Hashtable();

            if (be.Codigo != 0)
            {
                hash.Add("@Codigo", be.Codigo);
                Consulta = "JefeDepartamento_Modificar";
            }
            hash.Add("@LoginNombre", be.oUsu.NombreUsuario);
            hash.Add("@EncritPassword", be.oUsu.Password);
            hash.Add("@Nombre", be.Nombre);
            hash.Add("@Dni", be.Dni);
            hash.Add("@FechaNacimiento", be.FechaNacimiento);
            hash.Add("@Email", be.Email);
            hash.Add("@NombreDto", be.NombreDepartamento);
            hash.Add("@Calle", be.Calle);
            hash.Add("@Numeracion", be.NumeroAltura);
            hash.Add("@Localidad", be.Localidad);
            hash.Add("@Provincia", be.Provincia);
            hash.Add("@CodigoPostal", be.CodigoPostal);
            hash.Add("@Cargo", be.Puesto);
            hash.Add("@CodProduc", be.NumCodigo);
            hash.Add("@Departamento", be.Departamento);

            return Oc.EscribirGenerico(Consulta, hash);

        }

        public List<BeEmpleado> ListarTodo()
        {
            List<BeEmpleado> ListaEmpleados = new List<BeEmpleado>();

            DataTable dt = Oc.Leer("Empleado_ListarT", null);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow fila in dt.Rows)
                {
                    BeEmpleado aux = new BeEmpleado();
                    aux.Codigo = int.Parse(fila["Codigo"].ToString());
                    BeUsuario oU = new BeUsuario();
                    oU.NombreUsuario = fila["LoginNombre"].ToString();
                    oU.Password = fila["EncritPassword"].ToString();
                    aux.oUsu = oU;
                    aux.Nombre = fila["Nombre"].ToString();
                    aux.Dni = int.Parse(fila["Dni"].ToString());
                    aux.FechaNacimiento = DateTime.Parse(fila["FechaNacimiento"].ToString());
                    aux.Email = fila["Email"].ToString();
                    aux.NombreDepartamento = fila["NombreDto"].ToString();
                    aux.Calle = fila["Calle"].ToString();
                    aux.NumeroAltura = int.Parse(fila["Numeracion"].ToString());
                    aux.Localidad = fila["Localidad"].ToString();
                    aux.Provincia = fila["Provincia"].ToString();
                    aux.CodigoPostal = int.Parse(fila["CodigoPostal"].ToString());
                    aux.Puesto = fila["Cargo"].ToString();
                    aux.NumCodigo = int.Parse(fila["CodProduc"].ToString());
                    
                    ListaEmpleados.Add(aux);
                }
            }
            else
            {
                ListaEmpleados = null;
            }
            return ListaEmpleados;
        }

        public bool Borrar(BeEmpleado be)
        {
            ArrList = new ArrayList();
            SqlParameter Param1 = new SqlParameter();
            Param1.ParameterName = "@Codigo";
            Param1.Value = be.Codigo;
            Param1.SqlDbType = SqlDbType.Int;
            ArrList.Add(Param1);
            return Oc.EscribirGenerico("Empleado_Borrar", ArrList);
        }
    }
}
