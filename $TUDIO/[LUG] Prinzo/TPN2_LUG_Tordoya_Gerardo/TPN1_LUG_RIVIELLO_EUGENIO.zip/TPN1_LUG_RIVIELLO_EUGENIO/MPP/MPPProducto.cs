﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;
using Abstraccion;
using System.Collections;
using System.Data.SqlClient;

namespace MPP
{
    public class MPPProducto
    {
        Conexion oc;
        ArrayList ArrList;

        public MPPProducto()
        {
            oc = new Conexion();
        }
      
        public bool Guardar(BeProducto bp)
        {
            
            ArrList = new ArrayList();
            string Consulta = "Producto_Crear";
           
            if (bp.Codigo != 0)
            {
                SqlParameter Param7 = new SqlParameter("@Codigo", bp.Codigo);                
                ArrList.Add(Param7);
                Consulta = "Producto_Modificar";
            }

            SqlParameter Param1 = new SqlParameter("@NumeroProducto", bp.NumeroProducto);
            ArrList.Add(Param1);

            SqlParameter Param2 = new SqlParameter("@NombreProducto", bp.NombreProducto);
            ArrList.Add(Param2);

            SqlParameter Param3 = new SqlParameter("@Categoria", bp.Categoria);
            ArrList.Add(Param3);

            SqlParameter Param4 = new SqlParameter("@Descripcion", bp.Descripcion);
            ArrList.Add(Param4);

            SqlParameter Param5 = new SqlParameter("@PrecioUnitario", bp.PrecioUnitario);
            ArrList.Add(Param5);

            SqlParameter Param6 = new SqlParameter("@CodigoVendedor", bp.CodigoVendedor);
            ArrList.Add(Param6);

            return oc.EscribirGenerico(Consulta, ArrList);
        }

        public List<BeProducto> ListarTodo()
        {
            List<BeProducto> ListaProductos = new List<BeProducto>();

            DataTable dt = oc.Leer("Producto_ListarT", null);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow fila in dt.Rows)
                {
                    BeProducto aux = new BeProducto();
                    aux.Codigo = int.Parse(fila["Codigo"].ToString());
                    aux.NumeroProducto = int.Parse(fila["NumeroProducto"].ToString());
                    aux.NombreProducto = fila["NombreProducto"].ToString();
                    aux.Categoria = fila["Categoria"].ToString();
                    aux.Descripcion = fila["Descripcion"].ToString();
                    aux.PrecioUnitario = int.Parse(fila["PrecioUnitario"].ToString());
                    aux.CodigoVendedor = int.Parse(fila["CodigoVendedor"].ToString());
                    ListaProductos.Add(aux);
                }
            }
            else
            {
                ListaProductos = null;
            }
            return ListaProductos;
        }        

        public bool Borrar(BeProducto bp)
        {
            
            ArrList = new ArrayList();
            SqlParameter Param1 = new SqlParameter("@Codigo", bp.Codigo);
            ArrList.Add(Param1);
            return oc.EscribirGenerico("Producto_Borrar", ArrList);
        }
    }  
    
}

