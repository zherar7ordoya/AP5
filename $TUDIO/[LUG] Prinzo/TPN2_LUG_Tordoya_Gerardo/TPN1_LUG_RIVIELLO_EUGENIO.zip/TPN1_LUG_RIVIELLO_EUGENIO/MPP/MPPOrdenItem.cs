﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;

namespace MPP
{
    public class MPPOrdenItem
    {
        Conexion oc;
        public bool Guardar(BeOrdenItem boi)
        {
            string ConsultaSql;
            if (boi.Codigo == 0)
            {
                ConsultaSql = "INSERT INTO OrdenItem(NombreEmpleado, NumeroOrden, FechaOrden, Estado, NumeroProducto, Cantidad, PrecioUnitario) values('"+ boi.NombreEmpleado +"', '"+ boi.NumeroOrden +"', '"+ boi.FechaOrden.ToString() +"', '"+ boi.Estado +"', '"+ boi.NumeroProducto +"', '"+ boi.Cantidad +"', '"+ boi.PrecioUnitario +"')";
            }
            else
            {
                ConsultaSql = "UPDATE OrdenItem SET NombreEmpleado = '"+ boi.NombreEmpleado +"', NumeroOrden = '"+ boi.NumeroOrden +"', FechaOrden = '"+ boi.FechaOrden.ToString() +"', Estado = '"+ boi.Estado +"', NumeroProducto = '"+ boi.NumeroProducto +"', Cantidad = '"+ boi.Cantidad +"', PrecioUnitario = '"+ boi.PrecioUnitario +"";
            }
            oc = new Conexion();
            return oc.EscribirGenerico(ConsultaSql);
        }

        public List<BeOrdenItem> ListarTodo()
        {
            List<BeOrdenItem> ListaOrdenes = new List<BeOrdenItem>();
            DataSet ds;
            string ConsultaSql = "SELECT * FROM OrdenItem";
            oc = new Conexion();
            ds = oc.Leer(ConsultaSql);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow fila in ds.Tables[0].Rows)
                {
                    BeOrdenItem aux = new BeOrdenItem();
                    aux.Codigo = int.Parse(fila[0].ToString());
                    aux.NombreEmpleado = fila[1].ToString();
                    aux.NumeroOrden = int.Parse(fila[2].ToString());                   
                    aux.FechaOrden = DateTime.Parse(fila[3].ToString());
                    aux.Estado = fila[4].ToString();
                    aux.NumeroProducto = int.Parse(fila[5].ToString());
                    aux.Cantidad = int.Parse(fila[6].ToString());
                    aux.PrecioUnitario = int.Parse(fila[7].ToString());
                    ListaOrdenes.Add(aux);
                }
            }
            else
            {
                ListaOrdenes = null;
            }
            return ListaOrdenes;
        }

        public bool Borrar(BeOrdenItem be)
        {
            string ConsultaSql = "DELETE FROM OrdenItem where Codigo = " + be.Codigo + "";
            oc = new Conexion();
            return oc.EscribirGenerico(ConsultaSql);
        }
    }
}
