﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Abstraccion;
using BE;
using DAL;
using System.Collections;

namespace MPP
{
    public class MPPSueldo
    {
        Conexion Oc;       

        public MPPSueldo()
        {
            Oc = new Conexion();
        }
        Hashtable hash;
        public bool Guardar(BeSueldo be)
        {
            string Consulta = "Sueldo_Crear";
            hash = new Hashtable();

            if (be.Codigo != 0)
            {
                hash.Add("@CodSueldo", be.Codigo);
                Consulta = "Sueldo_Modificar";
            }
            hash.Add("@Nombre", be.oEmpleado.Nombre);
            hash.Add("@Sueldo", be.oEmpleado.Sueldo);           

            return Oc.EscribirGenerico(Consulta, hash);
        }
        public List<BeSueldo> ListarTodo()
        {
            List<BeSueldo> ListaSueldos = new List<BeSueldo>();

            DataTable dt = Oc.Leer("Sueldo_ListarT", null);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow fila in dt.Rows)
                {
                    BeEmpleado aux = new BeEmpleado();
                    BeSueldo bs = new BeSueldo();
                    bs.Codigo = int.Parse(fila["CodSueldo"].ToString());
                    aux.Nombre = fila["Nombre"].ToString();
                    aux.Sueldo = int.Parse(fila["Sueldo"].ToString());
                    bs.oEmpleado = aux;
                    ListaSueldos.Add(bs);
                }
            }
            else
            {
                ListaSueldos = null;
            }
            return ListaSueldos;
        }

        public bool GuardarTablaIntermedia(BeSueldo bs, BeEmpleado be)
        {

            
                    string Consulta = "Empleado_Sueldo_Crear";
                    hash = new Hashtable();
                    //if (bbs.Codigo != 0)
                    //{
                    //    hash.Add("@Codigo", bbs.Codigo);
                    //    Consulta = "Empleado_Sueldo_Modificar";
                    //}

                    hash.Add("@CodigoEmp", be.Codigo);
                    hash.Add("@CodSueldo", bs.Codigo);

                    return Oc.EscribirGenerico(Consulta, hash);
            }

        
    }
    
}
