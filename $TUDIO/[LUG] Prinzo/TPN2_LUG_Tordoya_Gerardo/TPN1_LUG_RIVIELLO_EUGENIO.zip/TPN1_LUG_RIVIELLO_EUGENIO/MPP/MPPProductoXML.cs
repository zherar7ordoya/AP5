﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BE;

namespace MPP
{
    public class MPPProductoXML
    {
        public bool Guardar(BeProducto beXML)
        {
            try
            {
                XDocument guardar = XDocument.Load(@"Productos.XML");
                guardar.Element("produccion").Add(new XElement("producto",
                                                new XAttribute("Codigo", beXML.Codigo),
                                                new XElement("NumeroProducto", beXML.NumeroProducto),
                                                new XElement("NombreProducto", beXML.NombreProducto),
                                                new XElement("Categoria", beXML.Categoria),
                                                new XElement("Descripcion", beXML.Descripcion),
                                                new XElement("PrecioUnitario", beXML.PrecioUnitario),
                                                new XElement("CodigoVendedor", beXML.CodigoVendedor)));
                guardar.Save("Productos.XML");
                return true;
            }

            catch (Exception)
            {

                return false;
            }
        
        }

        public List<BeProducto> ListarTodos()
        {
            var consulta = from producto in XElement.Load("Productos.XML").Elements("producto")
                           select new BeProducto
                           {
                               Codigo = Convert.ToInt32(Convert.ToString(producto.Attribute("Codigo").Value).Trim()),
                               NumeroProducto = Convert.ToInt32(Convert.ToString(producto.Element("NumeroProducto").Value).Trim()),
                               NombreProducto = Convert.ToString(producto.Element("NombreProducto").Value).Trim(),
                               Categoria = Convert.ToString(producto.Element("Categoria").Value).Trim(),
                               Descripcion = Convert.ToString(producto.Element("Descripcion").Value).Trim(),
                               PrecioUnitario = Convert.ToInt32(Convert.ToString(producto.Element("PrecioUnitario").Value).Trim()),
                               CodigoVendedor = Convert.ToInt32(Convert.ToString(producto.Element("CodigoVendedor").Value).Trim())                                                        

                           };
            List<BeProducto> listaProductos = consulta.ToList<BeProducto>();
            return listaProductos;
        }

        public bool Borrar(BeProducto be)
        {
            try
            {
                XDocument documento = XDocument.Load("Productos.XML");

                var consulta = from producto in documento.Descendants("producto")
                               where producto.Attribute("Codigo").Value == be.Codigo.ToString()
                               select producto;
                consulta.Remove();

                documento.Save("Productos.XML");
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool Modificar(BeProducto be)
        {
            try
            {
                XDocument documento = XDocument.Load("Productos.XML");

                var consulta = from producto in documento.Descendants("producto")
                               where producto.Attribute("Codigo").Value == Convert.ToString(be.Codigo)
                               select producto;

                foreach (XElement mod in consulta)
                {
                    mod.Element("Codigo").Value = Convert.ToString(be.Codigo);
                    mod.Element("NumeroProducto").Value = Convert.ToString(be.NumeroProducto);
                    mod.Element("NombreProducto").Value = be.NombreProducto;                    
                    mod.Element("Categoria").Value = be.Categoria;
                    mod.Element("Descripcion").Value = be.Descripcion;
                    mod.Element("PrecioUnitario").Value = Convert.ToString(be.PrecioUnitario);
                    mod.Element("CodigoVendedor").Value = Convert.ToString(be.CodigoVendedor);
                    
                }

                documento.Save("Productos.XML");
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<BeProducto> BuscarXNombre(string nomProduc)
        {
            var consulta = from producto in XElement.Load("Productos.XML").Elements("producto")
                           where (string)producto.Element("NombreProducto") == nomProduc.ToString()
                           select new BeProducto
                           {
                               Codigo = Convert.ToInt32(Convert.ToString(producto.Attribute("Codigo").Value).Trim()),
                               NumeroProducto = Convert.ToInt32(Convert.ToString(producto.Element("NumeroProducto").Value).Trim()),
                               NombreProducto = Convert.ToString(producto.Element("NombreProducto").Value).Trim(),
                               Categoria = Convert.ToString(producto.Element("Categoria").Value).Trim(),
                               Descripcion = Convert.ToString(producto.Element("Descripcion").Value).Trim(),
                               PrecioUnitario = Convert.ToInt32(Convert.ToString(producto.Element("PrecioUnitario").Value).Trim()),
                               CodigoVendedor = Convert.ToInt32(Convert.ToString(producto.Element("CodigoVendedor").Value).Trim())

                           };

            List<BeProducto> buscados = consulta.ToList<BeProducto>();
            return buscados;
        }

    }
}
