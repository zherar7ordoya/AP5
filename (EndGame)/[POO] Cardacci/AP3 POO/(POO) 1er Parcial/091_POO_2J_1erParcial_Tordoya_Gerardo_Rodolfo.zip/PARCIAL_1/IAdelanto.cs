﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARCIAL_1
{
    interface IAdelanto
    {
        void AsignarEmpleado(CEmpleado empleado);
    }
}
