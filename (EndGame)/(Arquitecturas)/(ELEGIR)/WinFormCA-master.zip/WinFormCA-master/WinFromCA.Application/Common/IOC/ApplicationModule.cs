﻿using Autofac;

namespace WinFromCA.Application.Common.IOC
{
    public class ApplicationModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);
        }
    }
}
