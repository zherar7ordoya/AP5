﻿
using System;

namespace WinFromCA.Application.Interfaces
{
    public interface IDateTimeService
    {
        DateTime GetTodayDate();
    }
}
