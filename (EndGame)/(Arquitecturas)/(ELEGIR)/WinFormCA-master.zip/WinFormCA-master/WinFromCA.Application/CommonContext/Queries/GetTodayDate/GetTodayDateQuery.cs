﻿

using MediatR;
using System;

namespace WinFromCA.Application.CommonContext.Queries.GetTodayDate
{
    public class GetTodayDateQuery : IRequest<DateTime>
    {
    }
}
