﻿

namespace WinFormCA.Domain.Form2
{
    public class Form2Model
    {
        public string Date { get; set; }
    }
}
