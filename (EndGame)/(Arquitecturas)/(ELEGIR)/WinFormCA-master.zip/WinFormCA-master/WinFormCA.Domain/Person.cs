﻿
namespace WinFormCA.Domain
{
    public class Person
    {
        public string Name { get; set; }
    }
}
