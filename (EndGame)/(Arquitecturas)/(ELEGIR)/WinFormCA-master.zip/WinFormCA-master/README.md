# WinFormCA
WinForm Clean Architecture Baseline with Telerik Form as an Example
