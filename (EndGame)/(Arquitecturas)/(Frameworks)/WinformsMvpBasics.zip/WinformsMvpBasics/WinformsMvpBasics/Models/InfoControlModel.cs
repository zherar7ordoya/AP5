﻿namespace WinformsMvpBasics.Models
{
    public class InfoControlModel
    {
        public string Message { get; set; }
    }
}
